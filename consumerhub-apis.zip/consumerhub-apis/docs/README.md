# Pipelines Status

[![Java CI with Gradle](https://github.com/NZTA/consumerhub-apis/actions/workflows/backend-apis-ci.yml/badge.svg)](https://github.com/NZTA/consumerhub-apis/actions/workflows/backend-apis-ci.yml)

# Published API(s)
[Swagger UI](https://api.dev.consumerhub.nzta.govt.nz/swagger-ui/index.html)

# Consumed API(s)
[Driving Licence by Unisys](../licence/src/main/resources/apis-dlz-licence.json)

[Vehicle Screening System by Unisys](../vehicle/src/main/resources/apis-vss-vehicle.json)

# Getting Started

# Java
```shell
java --version
```
- openjdk 17.0.3 2022-04-19 LTS
- OpenJDK Runtime Environment Corretto-17.0.3.6.1 (build 17.0.3+6-LTS)
- OpenJDK 64-Bit Server VM Corretto-17.0.3.6.1 (build 17.0.3+6-LTS, mixed mode, sharing)

# Gradle
```shell
./gradlew --version
```
- Gradle:               7.6
- Ant:                  Apache Ant(TM) version 1.10.11 compiled on July 10 2021
- JVM:                  17.0.3 (Amazon.com Inc. 17.0.3+6-LTS)

# Gradle | IntelliJ Plugin
To set up gradle wrapper, watch
[IntelliJ Gradle Wrapper](https://www.jetbrains.com/idea/guide/tutorials/working-with-gradle/gradle-wrapper/)

<img src="intellij-plugins-gradle.png" width="50%" />

# Lock Dependencies
To lock project dependencies, execute following on project root directory
```shell
./gradlew dependencies --write-locks
```

# Run App
To run app locally,
- Install Azure CLI https://learn.microsoft.com/en-us/cli/azure/install-azure-cli
- Authorize Azure CLI `az login`, use your Azure AD account and make sure you have the read access of https://dev-chub-api-kv.vault.azure.net/
```shell
./gradlew bootRun
```

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.7.1/gradle-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.7.1/gradle-plugin/reference/html/#build-image)
* [Spring Boot Externalized Configuration](https://docs.spring.io/spring-boot/docs/current/reference/html/features.html#features.external-config)
* [Jersey](https://docs.spring.io/spring-boot/docs/2.7.0/reference/htmlsingle/#web.servlet.jersey)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)
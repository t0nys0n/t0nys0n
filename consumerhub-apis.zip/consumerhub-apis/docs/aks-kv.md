## To use Azure Kubernetes Service a.k.a AKS with Azure KeyVault, following Kubernetes primitives are required:
- Secrets store CSI driver
- Secrets store provider

### Secrets store CSI driver
Used for
- mounting secrets, keys, and certificates to a pod by using a CSI volume, 
- syncing of kubernetes secrets
- etc

### Secrets store provider
Used for
- fetching secrets from store
- store specific implementations are available for AWS, Azure, HarshiCorp etc
- in our case Azure KeyVault secrets provider is used

### Installation
To upgrade an existing AKS cluster with Azure Key Vault Provider for Secrets Store CSI Driver capability, use the az aks enable-addons command with the azure-keyvault-secrets-provider add-on:
```shell
az aks enable-addons --addons azure-keyvault-secrets-provider --name myAKSCluster --resource-group myResourceGroup
```

### Verify Installation
The preceding command installs the Secrets Store CSI Driver and the Azure KeyVault Provider on your nodes. Verify that the installation is finished by listing all pods that have the secrets-store-csi-driver and secrets-store-provider-azure labels in the kube-system namespace, and ensure that your output looks similar to the output shown here:
```shell
kubectl get pods -n kube-system -l 'app in (secrets-store-csi-driver, secrets-store-provider-azure)'

NAME                                     READY   STATUS    RESTARTS   AGE
aks-secrets-store-csi-driver-2sqpj       3/3     Running   0          3d21h
aks-secrets-store-provider-azure-l5qdq   1/1     Running   0          3d21h
```
A user-assigned managed identity, named azurekeyvaultsecretsprovider-*, is created by the add-on for the purpose of accessing Azure resources. This identity is assigned to  your AKS cluster's VMs or scale sets.

### Usage
#### Authentication
Use one of the following identity methods for authentication: 
- user-assigned managed identity, we can use above created identity by querying or create new one
```shell
- az aks show -g <aks-resource-group> -n <aks-cluster-name> --query addonProfiles.azureKeyvaultSecretsProvider.identity.clientId -o tsv
```
- system-assigned managed identity, before you begin with this, enable system-assigned managed identity in your AKS cluster's VMs or scale sets. To verify system-assigned identity run following, output must contain type: SystemAssigned
```shell
az vmss identity show -g <vmss resource group>  -n <vmss scalset name> -o yaml
az vm identity show -g <vm resource group> -n <vm name> -o yaml
```
- pod-managed identity, **recommended** but in preview
#### Authorization
To grant your identity, permissions that enable it to read your key vault and view its contents, run the following commands:
```shell
# set policy to access keys in your key vault
az keyvault set-policy -n <keyvault-name> --key-permissions get --spn <identity-principal-id>
# set policy to access secrets in your key vault
az keyvault set-policy -n <keyvault-name> --secret-permissions get --spn <identity-principal-id>
# set policy to access certs in your key vault
az keyvault set-policy -n <keyvault-name> --certificate-permissions get --spn <identity-principal-id>
```
#### Secret provider class
[SecretProviderClass is used for:](https://secrets-store-csi-driver.sigs.k8s.io/getting-started/usage.html)
- which identity and provider to use
- which secrets to pull
- whether to create secret manifest from fetched secrets
- sync secrets
- enable auto rotation
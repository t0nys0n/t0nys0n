plugins {
    id("org.openapi.generator") version "7.6.0"
}

dependencies {
    implementation(project(":shared"))
    testImplementation(testFixtures(project(":shared")))
}

tasks.compileJava {
    dependsOn("generateClientLicenceDlz")
}

val openApiGenerateOutputDir =  "$buildDir/generated"
val openApiGenerateConfigFile = "$projectDir/src/main/resources/openapi-configuration.json"

tasks.register<org.openapitools.generator.gradle.plugin.tasks.GenerateTask>("generateClientLicenceDlz") {
    outputDir.set(openApiGenerateOutputDir)
    configFile.set(openApiGenerateConfigFile)
    generatorName.set("java")
    library.set("webclient")
    inputSpec.set("$projectDir/src/main/resources/apis-dlz-licence.json")
    configOptions.put("apiPackage", "org.generated.apis.dlz.licence.client")
    configOptions.put("modelPackage", "org.generated.apis.dlz.licence.model")
    typeMappings.put("string+date-time", "LocalDateTime")
    importMappings.put("LocalDateTime", "java.time.LocalDateTime")
}

java.sourceSets["main"].java.srcDir("$buildDir/generated/src/main/java")
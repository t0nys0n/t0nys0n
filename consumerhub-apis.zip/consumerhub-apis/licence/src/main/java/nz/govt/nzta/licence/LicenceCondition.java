package nz.govt.nzta.licence;

import lombok.NonNull;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.DateFormats;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@Value
@Slf4j
public class LicenceCondition {

    @NonNull ConditionType type;
    @NonNull String description;
    @NonNull String applicableTo;
    @NonNull String issueDate;
    @NonNull String expiryDate;

    public boolean isNotExpired() {
        if (noExpiry()) {
            return true;
        }
        try {
            LocalDate expiry = LocalDate.parse(expiryDate, DateFormats.MEDIUM_DATE_FORMATTER);
            return expiry.isAfter(LocalDate.now());
        } catch (DateTimeParseException e) {
            log.error(e.getMessage());
            return true;
        }
    }

    private boolean noExpiry() {
        return expiryDate.isBlank();
    }

    public enum ConditionType {
        NOTSET("NotSet"),
        SUPERVISORREQUIRED("SupervisorRequired"),
        DISPLAYLPLATE("DisplayLPlate"),
        DISPLAYRPLATE("DisplayRPlate"),
        NONIGHTDRIVING("NoNightDriving"),
        SPEEDLIMIT70KPH("SpeedLimit70Kph"),
        MAXMOTORCYCLE250CC("MaxMotorCycle250Cc"),
        NOPILIONORSIDECAR("NoPilionOrSidecar"),
        SUPERVISORREQUIREDWHENCARRYINGPASSENGERS("SupervisorRequiredWhenCarryingPassengers"),
        SUPERVISORREQUIREDWHENNIGHTDRIVING("SupervisorRequiredWhenNightDriving"),
        DISQUALIFIEDFROMGOODSTRANSPORTSERVICEDRIVING("DisqualifiedFromGoodsTransportServiceDriving"),
        DISQUALIFIEDFROMPASSENGERTRANSPORTSERVICEDRIVING(
                "DisqualifiedFromPassengerTransportServiceDriving"),
        DISQUALIFIEDFROMRECOVERYTRANSPORTSERVICEDRIVING(
                "DisqualifiedFromRecoveryTransportServiceDriving"),
        DISQUALIFIEDFROMTRANSPORTSERVICEDRIVING("DisqualifiedFromTransportServiceDriving"),
        A("A"),
        AL("AL"),
        B("B"),
        C("C"),
        D("D"),
        E("E"),
        F("F"),
        G("G"),
        H("H"),
        I("I"),
        J("J"),
        K("K"),
        L("L"),
        M("M"),
        M1("M1"),
        N("N"),
        O("O"),
        P("P"),
        Q("Q"),
        R("R"),
        S("S"),
        T("T"),
        U("U"),
        V("V"),
        W("W"),
        X("X"),
        Y("Y"),
        Z("Z"),
        ZL("ZL"),
        OTHER("Other"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;

        ConditionType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}

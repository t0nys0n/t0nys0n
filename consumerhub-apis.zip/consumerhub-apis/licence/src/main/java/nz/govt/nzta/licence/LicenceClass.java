package nz.govt.nzta.licence;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Value;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

import static nz.govt.nzta.licence.Licence.ExpiryCompliance;

@Value
public class LicenceClass {

    static final int EXPIRY_COUNTDOWN = 30;
    static final int EXPIRY_SUPPRESS_YEAR = 5;

    @NonNull
    Licence.GraduatedStage stage;

    @NonNull
    ClassStatus status;

    @NonNull
    ClassType type;

    @NonNull
    String description;

    @NonNull
    String issueDate;

    @NonNull
    LocalDate expiryDate;

    public String getName() {
        return String.format("%s%s", getNumber(), stage.getInitial());
    }

    public boolean isSuppressed(LocalDate today) {
        return status.equals(ClassStatus.EXPIRED) && ChronoUnit.YEARS.between(expiryDate, today) >= EXPIRY_SUPPRESS_YEAR;
    }

    public Optional<ExpiryCompliance> computeExpiryCompliance(LocalDate today) {
        return ExpiryCompliance.compute(today, expiryDate, EXPIRY_COUNTDOWN);
    }

    private int getNumber() {
        return type.getNumber();
    }


    @AllArgsConstructor
    @Getter
    public enum ClassType {
        NOTSET("NotSet", "", -1),
        MOTORCARLIGHTMOTORVEHICLE("MotorCarLightMotorVehicle", "Car licence (class 1)", 1),
        MEDIUMRIGIDVEHICLES("MediumRigidVehicles", "Medium rigid vehicle (class 2)", 2),
        MEDIUMCOMBINATIONVEHICLES("MediumCombinationVehicles", "Medium combination vehicle (class 3)", 3),
        HEAVYRIGIDVEHICLES("HeavyRigidVehicles", "Heavy rigid vehicle (class 4)", 4),
        HEAVYCOMBINATIONVEHICLES("HeavyCombinationVehicles", "Heavy combination vehicle (class 5)", 5),
        MOTORCYCLESMOPEDORATV("MotorCyclesMopedOrATV", "Motorcycles (class 6)", 6),
        UNKNOWN("Unknown", "", -1),
        EMPTY("Empty", "", -1);

        private final String value;
        private final String title;
        private final int number;
    }

    @AllArgsConstructor
    @Getter
    public enum ClassStatus {
        NOTSET("NotSet"),
        CANCELLED("Cancelled"),
        CURRENT("Current"),
        DISQUALIFIED("Disqualified"),
        EXPIRED("Expired"),
        INACTIVE("Inactive"),
        LIMITED("Limited"),
        REQUALIFY("Requalify"),
        REVOKED("Revoked"),
        SUSPENDED("Suspended"),
        VOLUNTARY_SURRENDER("Voluntary surrender"),
        REINSTATE("Reinstate"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;
    }

}

package nz.govt.nzta.licence;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Value;
import nz.govt.nzta.licence.Licence.ExpiryCompliance;
import nz.govt.nzta.licence.LicenceClass.ClassType;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

@Value
public class LicenceEndorsement {

    static final int EXPIRY_SUPPRESS_YEAR = 5;

    @NonNull
    String description;

    @NonNull
    ClassType classType;

    @NonNull
    EndorsementStatus status;

    @NonNull
    EndorsementType type;

    @NonNull
    String issueDate;

    @NonNull
    LocalDate expiryDate;

    public String getName() {
        String classNumber = getClassNumber();
        return String.format("%s%s", type, classNumber);
    }

    public boolean isSuppressed(LocalDate today) {
        return status.equals(EndorsementStatus.EXPIRED) && ChronoUnit.YEARS.between(expiryDate, today) >= EXPIRY_SUPPRESS_YEAR;
    }

    public Optional<ExpiryCompliance> computeExpiryCompliance(LocalDate today) {
        return ExpiryCompliance.compute(today, expiryDate, getDaysToExpireCountdown());
    }

    public boolean isProhibitStatus() {
        return this.status == EndorsementStatus.PROHIBIT_P_ENDORSEMENT;
    }

    private String getClassNumber() {
        return isAppliedToLicence() ? "" : String.valueOf(classType.getNumber());
    }

    private boolean isAppliedToLicence() {
        return classType == LicenceClass.ClassType.NOTSET;
    }

    private int getDaysToExpireCountdown() {
        return switch (type) {
            case P, V, I, O, D -> 42;
            default -> 30;
        };
    }

    @AllArgsConstructor
    @Getter
    public enum EndorsementType {
        P("Passenger"),
        V("Vehicle recovery service"),
        I("Driving instructor"),
        O("Testing officer"),
        D("Dangerous goods"),
        F("Forklift"),
        R("Roller"),
        T("Tracks"),
        W("Wheels"),
        EMPTY("Empty");

        private final String value;
    }

    @AllArgsConstructor
    @Getter
    public enum EndorsementStatus {
        NOTSET("NotSet"),
        CANCELLED("Cancelled"),
        CURRENT("Current"),
        DISQUALIFIED("Disqualified"),
        EXPIRED("Expired"),
        INACTIVE("Inactive"),
        LIMITED("Limited"),
        REQUALIFY("Requalify"),
        REVOKED("Revoked"),
        SUSPENDED("Suspended"),
        VOLUNTARY_SURRENDER("Voluntary surrender"),
        INACTIVE_REQUALIFICATION("Inactive requalification"),
        PROHIBIT_P_ENDORSEMENT("Prohibit P endorsement"),
        REINSTATE("Reinstate"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;
    }
}

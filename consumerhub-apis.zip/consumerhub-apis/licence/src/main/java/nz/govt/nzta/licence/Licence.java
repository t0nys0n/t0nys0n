package nz.govt.nzta.licence;

import jakarta.validation.Valid;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.NonNull;
import lombok.Value;

import java.time.Clock;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Value
public class Licence {

    @NonNull String driverId;
    @NonNull String firstName;
    @NonNull String otherNames;
    @NonNull String familyName;
    @NonNull String dateOfBirth;
    boolean isDonor;
    String mobilePhone;
    String emailAddress;
    @NonNull String number;
    @NonNull String issueDate;
    @NonNull Licence.Status status;
    @NonNull Licence.Type type;
    @NonNull @Valid DemeritSummary demerit;
    @NonNull LicenceCards cards;
    @NonNull LicenceClasses classes;
    @NonNull LicenceEndorsements endorsements;
    @NonNull LicenceConditions conditions;

    public String getCardVersion() {
        return cards.getCardVersion();
    }

    public Optional<AddressFormatted> getAddressOnCard() {
        return cards.getAddressOnCard();
    }

    public Licence.GraduatedStage getStage() {
        return classes.computeLicenceStage();
    }

    public List<LicenceClass> getClasses() {
        return classes.list();
    }

    public List<LicenceEndorsement> getEndorsements() {
        return endorsements.list();
    }

    public List<LicenceCondition> getConditions() {
        return conditions.list();
    }

    public List<LicenceClass> getExpiryComplianceClasses(Clock clock) {
        return classes.withExpiryCompliance(clock);
    }

    public List<LicenceEndorsement> getExpiryComplianceEndorsements(Clock clock) {
        return endorsements.withExpiryCompliance(clock);
    }

    public enum DemeritStatus {
        NOTSET("NotSet"),
        NOSTATUS("NoStatus"),
        WARNING("Warning"),
        SUSPENDED("Suspended"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;

        DemeritStatus(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum Type {
        NOTSET("NotSet"),
        STANDARD("Standard"),
        DIPLOMATIC("Diplomatic"),
        PSEUDO("Pseudo"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;

        Type(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum GraduatedStage {
        NOTSET("NotSet", "NotSet"),
        FULL("Full", ""),
        LEARNER("Learner", "L"),
        RESTRICTED("Restricted", "R"),
        UNKNOWN("Unknown", "Unknown"),
        EMPTY("Empty", "Empty");
        private final String value;
        private final String initial;

        GraduatedStage(String value, String initial) {
            this.value = value;
            this.initial = initial;
        }

        public String getValue() {
            return value;
        }

        public String getInitial() {
            return initial;
        }

    }

    public enum Status {
        NOTSET("NotSet"),
        CANCELLED("Cancelled"),
        CURRENT("Current"),
        DISQUALIFIED("Disqualified"),
        EXPIRED("Expired"),
        INACTIVE("Inactive"),
        LIMITED("Limited"),
        PROHIBITED("Prohibited"),
        REQUALIFY("Requalify"),
        REVOKED("Revoked"),
        SUSPENDED("Suspended"),
        SURRENDERED("Surrendered"),
        REINSTATE("Reinstate"),
        UNKNOWN("Unknown"),
        EMPTY("Empty");

        private final String value;

        Status(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }

    @Value
    public static class DemeritSummary {

        @PositiveOrZero int totalPoints;
        @NonNull String nextRecalculationDate;
        @NonNull Licence.DemeritStatus status;
    }

    public record ExpiryCompliance(Level level, long daysToExpire) {

        public static Optional<ExpiryCompliance> compute(LocalDate today, LocalDate expiry, int daysCountdown) {
            long daysToExpire = computeDaysBetween(today, expiry);
            ExpiryCompliance compliance = null;
            if (expiry.isBefore(today)) {
                compliance = new ExpiryCompliance(ExpiryCompliance.Level.EXPIRED, daysToExpire);
            } else if (expiry.equals(today)) {
                compliance = new ExpiryCompliance(ExpiryCompliance.Level.EXPIRES_TODAY, daysToExpire);
            } else if (expiry.isAfter(today) && daysToExpire <= daysCountdown) {
                compliance = new ExpiryCompliance(ExpiryCompliance.Level.EXPIRES_SOON, daysToExpire);
            }
            return Optional.ofNullable(compliance);
        }

        public static long computeDaysBetween(LocalDate today, LocalDate expiry) {
            return ChronoUnit.DAYS.between(today, expiry);
        }

        public enum Level {
            EXPIRED, EXPIRES_SOON, EXPIRES_TODAY
        }
    }

}

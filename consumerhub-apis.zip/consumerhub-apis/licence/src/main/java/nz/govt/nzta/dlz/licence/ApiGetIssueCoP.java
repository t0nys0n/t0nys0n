package nz.govt.nzta.dlz.licence;


import nz.govt.nzta.clients.api.ApiGet;
import org.generated.apis.dlz.licence.ApiClient;
import org.generated.apis.dlz.licence.client.DriversApi;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversRequestIssueDriverCoPRequest;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * R is response type Q is query type
 */
public class ApiGetIssueCoP implements ApiGet<Void, String> {

    private final DriversApi api;
    private final Float version;
    private final String key;

    public ApiGetIssueCoP(final WebClient oAuthClient, final ApiProperties properties) {
        api = createApiClient(oAuthClient, properties.getApiUri());
        version = properties.getApiVersion();
        key = properties.getApiKey();
    }

    @Override
    public Void get(String driverId) {
        var requestBody = new NZTADLRAPIDriverLicencingModelsDriversRequestIssueDriverCoPRequest();
        requestBody.setDriverId(driverId);

        return api.apiDriversIssueCoPPost(version, key, getRequestIdentifier(), getCurrentTimestamp(), requestBody)
                .block();
    }

    private DriversApi createApiClient(WebClient webClient, String basePath) {
        var apiClient = new ApiClient(webClient);
        apiClient.setBasePath(basePath);
        return new DriversApi(apiClient);
    }
}

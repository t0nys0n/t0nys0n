package nz.govt.nzta.licence;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NonNull;
import lombok.Value;
import nz.govt.nzta.licence.Licence.GraduatedStage;
import nz.govt.nzta.licence.LicenceClass.ClassType;

import java.util.List;

@Value
public class LicenceResponse {

    // licence holder details
    String firstName;
    String otherNames;
    String familyName;
    String dateOfBirth;
    String donorStatus;
    String mobilePhone;
    String emailAddress;

    // licence details
    String number;
    String issueDate;
    String cardVersion;
    Licence.Status status;
    GraduatedStage stage;
    Licence.Type type;
    Demerits demerit;
    List<Class> classes;
    List<Endorsement> endorsements;
    List<Condition> conditions;
    List<ComplianceMessage> classEndorsementComplianceMessages;

    @Data
    public static class Demerits {

        /**
         * @deprecated
         */
        @Deprecated(forRemoval = true)
        @Schema(deprecated = true, description = "Use field `points` instead of this")
        private int totalPoints;
        private @NonNull DemeritsNextRecalculationDate nextRecalculationDate;
        private @NonNull DemeritsStatus status;
        private @NonNull DemeritsPoint points;
    }

    @Data
    public static class DemeritsNextRecalculationDate {

        private @NonNull String date;
        private boolean hidden;
    }

    @Data
    public static class DemeritsStatus {

        private @NonNull LicenceResponse.DemeritsStatus.Type type;
        private boolean hidden;

        public enum Type {
            NOTSET("NotSet"),
            NOSTATUS("NoStatus"),
            WARNING("Warning"),
            SUSPENDED("Suspended"),
            UNKNOWN("Unknown");
            private final String value;

            Type(String value) {
                this.value = value;
            }

            public String getValue() {
                return value;
            }
        }
    }

    @Data
    public static class DemeritsPoint {
        int total;
        @NonNull
        Level level;

        public enum Level {
            OK, WARN, CRITICAL
        }
    }

    @Value
    public static class Class {

        String name;
        ClassType type;
        ClassStatus status;
        String issueDate;
        String expiryDate;
        ComplianceMessage expiryComplianceMessage;

    }

    @Value
    public static class ClassStatus {

        @NonNull
        LicenceClass.ClassStatus value;

        public String getText() {
            return this.value.getValue();
        }
    }

    @Value
    public static class Endorsement {

        String name;
        String description;
        EndorsementStatus status;
        String issueDate;
        String expiryDate;
        ComplianceMessage expiryComplianceMessage;
    }

    @Value
    public static class EndorsementStatus {

        @NonNull
        LicenceEndorsement.EndorsementStatus value;

        public String getText() {
            return this.value.getValue();
        }
    }

    @Value
    public static class Condition {

        String description;
        String applicableTo;
        String issueDate;
        String expiryDate;
    }

    @Value
    public static class ComplianceMessage {
        private static String messageTemplate = "%s %s %s";
        Level level;
        String text;
        Code code;

        public static ComplianceMessage compose(Licence.ExpiryCompliance compliance, String name, Code code) {
            Level level = null;
            String message = null;
            var expiryLevel = compliance.level();
            switch (expiryLevel) {
                case EXPIRED -> {
                    level = Level.CRITICAL;
                    message = messageTemplate.formatted(name, "has", "expired");
                }
                case EXPIRES_TODAY -> {
                    level = Level.WARN;
                    message = messageTemplate.formatted(name, "expires", "today");
                }
                case EXPIRES_SOON -> {
                    level = Level.WARN;
                    message = messageTemplate.formatted(name, "expires in", "%d days".formatted(compliance.daysToExpire()));
                }
            }
            return new ComplianceMessage(level, message, code);
        }

        public enum Level {
            CRITICAL, WARN, INFO
        }

        public enum Code {
            //class types
            MOTORCARLIGHTMOTORVEHICLE, MEDIUMRIGIDVEHICLES, MEDIUMCOMBINATIONVEHICLES, HEAVYRIGIDVEHICLES, HEAVYCOMBINATIONVEHICLES, MOTORCYCLESMOPEDORATV,
            //endorsement types
            P, V, I, O, D, F, R, T, W,
            //multi class/endorsement type
            MULTICLASSENDORSEMENT,
            //unknown types
            NOTSET, UNKNOWN, EMPTY;
        }
    }

}

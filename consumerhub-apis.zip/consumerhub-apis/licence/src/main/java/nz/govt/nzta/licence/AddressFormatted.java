package nz.govt.nzta.licence;

import java.util.function.Predicate;
import java.util.stream.Stream;

public record AddressFormatted(String line1, String line2, String line3, String line4, String line5) {

    public boolean isEmpty() {
        Predicate<String> p1 = e -> e == null;
        Predicate<String> p2 = String::isBlank;
        return Stream.of(line1, line2, line3, line4, line5)
                .allMatch(p1.or(p2));
    }
}

package nz.govt.nzta.licence;

import lombok.NonNull;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public record LicenceCards(@NonNull List<LicenceCard> list) {

    public LicenceCards {
        Objects.requireNonNull(list, "list is marked non-null but is null");
        list = Collections.unmodifiableList(list);
    }

    public String getCardVersion() {
        return getFirstCard()
                .map(LicenceCard::getVersion)
                .orElse("");
    }

    public Optional<AddressFormatted> getAddressOnCard() {
        return getFirstCard()
                .map(LicenceCard::getAddress)
                .orElse(Optional.empty());

    }

    private Optional<LicenceCard> getFirstCard() {
        return list.stream()
                   .findFirst();
    }
}

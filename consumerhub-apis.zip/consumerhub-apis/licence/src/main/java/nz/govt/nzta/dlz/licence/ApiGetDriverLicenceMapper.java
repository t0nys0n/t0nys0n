package nz.govt.nzta.dlz.licence;


import nz.govt.nzta.DateFormats;
import nz.govt.nzta.licence.*;
import nz.govt.nzta.licence.LicenceClass;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementType;
import org.generated.apis.dlz.licence.model.*;
import org.mapstruct.*;

@Mapper(componentModel = "spring",
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT
)
public interface ApiGetDriverLicenceMapper {

    default String map(String v) {
        return v == null ? "" : v;
    }

    @Named("mapDonorStatus")
    default boolean mapDonorStatus(String donorStatus) {
        return switch (donorStatus) {
            case "Yes", "Y", "yes", "y" -> true;
            default -> false;
        };
    }

    @Named("mapApplicableTo")
    default String mapApplicableTo(String applicableTo) {
        return String.valueOf(applicableTo).isBlank() ? "All" : map(applicableTo);
    }

    @Mapping(target = ".", source = "driverDetails.driver")
    @Mapping(target = "driverId", source = "driverDetails.driver.driverId")
    @Mapping(target = "isDonor", source = "driverDetails.driver.isDonor", qualifiedByName = "mapDonorStatus", defaultValue = "")

    @Mapping(target = ".", source = "licenceDetails.licence")
    @Mapping(target = "stage", ignore = true)
    @Mapping(target = "number", source = "licenceDetails.licence.id")
    @Mapping(target = "status", source = "licenceDetails.licence.licenceStatus", defaultValue = "EMPTY")
    @Mapping(target = "type", source = "licenceDetails.licence.licenceType", defaultValue = "EMPTY")
    @Mapping(target = "demerit", source = "licenceDetails.licence.demeritSummary")
    @Mapping(target = "demerit.status", source = "licenceDetails.licence.demeritSummary.status", defaultValue = "EMPTY")
    @Mapping(target = "demerit.nextRecalculationDate", source = "licenceDetails.licence.demeritSummary.nextRecalculationDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN, defaultValue = "")
    @Mapping(target = "demerit.totalPoints", source = "licenceDetails.licence.demeritSummary.totalPoints")
    @Mapping(target = "cards.list", source = "licenceDetails.licence.cards")
    @Mapping(target = "classes.list", source = "licenceDetails.licence.classes")
    @Mapping(target = "endorsements.list", source = "licenceDetails.licence.endorsements")
    @Mapping(target = "conditions.list", source = "licenceDetails.licence.conditions")
    Licence map(NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse driverDetails,
                NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse licenceDetails);

    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "stage", defaultValue = "EMPTY")
    @Mapping(target = "status", defaultValue = "EMPTY")
    @Mapping(target = "expiryDate", source = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN)
    LicenceClass map(NZTADLRAPIDriverLicencingModelsDriversClass clazz);

    @ValueMapping(source = "VOLUNTARYSURRENDER", target = "VOLUNTARY_SURRENDER")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = "UNKNOWN")
    LicenceClass.ClassStatus map (NZTADLRAPIDriverLicencingEnumsClassStatus classStatus);

    @Mapping(target = "classType", source = "propertyClass", defaultValue = "EMPTY")
    @Mapping(target = "type", source = "description", defaultValue = "EMPTY")
    @Mapping(target = "status", defaultValue = "EMPTY")
    @Mapping(target = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN)
    LicenceEndorsement map(NZTADLRAPIDriverLicencingModelsDriversEndorsement endorsement);

    @ValueMapping(source = "VOLUNTARYSURRENDER", target = "VOLUNTARY_SURRENDER")
    @ValueMapping(source = "INACTIVEREQUALIFICATION", target = "INACTIVE_REQUALIFICATION")
    @ValueMapping(source = "PROHIBITPENDORSEMENT", target = "PROHIBIT_P_ENDORSEMENT")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = "UNKNOWN")
    LicenceEndorsement.EndorsementStatus map (NZTADLRAPIDriverLicencingEnumsEndorsementStatus endorsementStatus);

    @Mapping(target = "description", source = "typeDisplayAs")
    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "applicableTo", source = "applicableTo", qualifiedByName = "mapApplicableTo")
    LicenceCondition map(NZTADLRAPIDriverLicencingModelsDriversCondition condition);

    @ValueMapping(source = "Passenger", target = "P")
    @ValueMapping(source = "Dangerous Goods", target = "D")
    @ValueMapping(source = "Driving Instructor", target = "I")
    @ValueMapping(source = "Vehicle Recovery", target = "V")
    @ValueMapping(source = "Testing Officer", target = "O")
    @ValueMapping(source = "Forklift", target = "F")
    @ValueMapping(source = "Roller", target = "R")
    @ValueMapping(source = "Tracks", target = "T")
    @ValueMapping(source = "Wheels", target = "W")
    @ValueMapping(source = MappingConstants.ANY_UNMAPPED, target = "EMPTY")
    EndorsementType mapEndorsementType(String description);

    @Mapping(target = "line1", source = "addressLine1")
    @Mapping(target = "line2", source = "addressLine2")
    @Mapping(target = "line3", source = "addressLine3")
    @Mapping(target = "line4", source = "addressLine4")
    @Mapping(target = "line5", source = "addressLine5")
    AddressFormatted map(NZTADLRAPIDriverLicencingModelsCommonFormattedAddress value);
}

package nz.govt.nzta.licence;


import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;


@Service
@RequiredArgsConstructor
@Validated
public class LicenceService {

    private final LicenceRepository repository;

    @Valid
    public Licence getLicence(String driverId) throws ConstraintViolationException {
        return repository.getLicence(driverId);
    }

    public void issueCoP(String driverId) {
        repository.issueCoP(driverId);
    }
}

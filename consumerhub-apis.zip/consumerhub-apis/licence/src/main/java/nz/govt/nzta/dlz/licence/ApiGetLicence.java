package nz.govt.nzta.dlz.licence;


import nz.govt.nzta.clients.ApiClient4xxException;
import nz.govt.nzta.clients.api.ApiGet;
import org.generated.apis.dlz.licence.ApiClient;
import org.generated.apis.dlz.licence.client.DriversApi;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * R is response type Q is query type
 */
public class ApiGetLicence implements ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse, String> {

    private final DriversApi api;
    private final Float version;
    private final String key;

    public ApiGetLicence(WebClient oAuthClient, ApiProperties properties) {
        api = createApiClient(oAuthClient, properties.getApiUri());
        version = properties.getApiVersion();
        key = properties.getApiKey();
    }

    @Override
    public NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse get(String driverId) throws ApiClient4xxException {
        return api.apiDriversDriverIdLicenceGet(driverId, "false", version, key, getRequestIdentifier(), getCurrentTimestamp())
                  .block();
    }

    private DriversApi createApiClient(WebClient webClient, String basePath) {
        var apiClient = new ApiClient(webClient);
        apiClient.setBasePath(basePath);
        return new DriversApi(apiClient);
    }

}

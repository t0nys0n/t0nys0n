package nz.govt.nzta.licence;

public interface LicenceRepository {

    Licence getLicence(String driverId);

    String getLicenceNumberOnly(String driverId);

    void issueCoP(String driverId);
}

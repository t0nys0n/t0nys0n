package nz.govt.nzta.licence;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.ReturnValueConstraintViolationException;
import nz.govt.nzta.server.api.ResourcePath;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.Clock;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@RestController
@RequestMapping(ResourcePath.LICENCES) //version
@RequiredArgsConstructor
@Slf4j
@Validated
@Tag(name = "licences")
public class LicenceController {

    private final LicenceService service;
    private final LicenceMapper mapper;
    private final Clock clock;

    @Operation(operationId = "getLicenceDetails", responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", description = "Invalid driver id format", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "404", description = "Driver id not found", content = @Content),
            @ApiResponse(responseCode = "429", description = "Too many requests", content = @Content),
            @ApiResponse(responseCode = "502", description = "Upstream service failure", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LicenceResponse> get(@RequestAttribute("driverId") @Pattern(regexp = "^[1-9]\\d{0,8}$", message = "{validation.messages.driver.id.format}") String driverId) throws ReturnValueConstraintViolationException {
        try {
            var licence = service.getLicence(driverId);
            var response = mapper.map(licence, clock);
            return ResponseEntity.ok(response);
        } catch (ConstraintViolationException cve) {
            throw new ReturnValueConstraintViolationException(cve.getMessage(), cve.getConstraintViolations());
        }
    }

    @Operation(operationId = "issue Certificate of Particulars", responses = {
            @ApiResponse(responseCode = "202"),
            @ApiResponse(responseCode = "400", description = "Invalid driver id format", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "502", description = "Upstream service failure", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @PostMapping("/issueCoP")
    public ResponseEntity<Void> issueCoP(@RequestAttribute("driverId") @Pattern(regexp = "^[1-9]\\d{0,8}$", message = "{validation.messages.driver.id.format}") String driverId, @RequestBody Object object) {
        try {
            service.issueCoP(driverId);
            return ResponseEntity.accepted().body(null);
        } catch (ConstraintViolationException cve) {
            throw new ReturnValueConstraintViolationException(cve.getMessage(), cve.getConstraintViolations());
        }
    }

    @ExceptionHandler(ReturnValueConstraintViolationException.class)
    public void handleConstraintViolation(
            ReturnValueConstraintViolationException ex,
            HttpServletResponse response) throws IOException {
        log.error(ex.getMessage());
        response.sendError(INTERNAL_SERVER_ERROR.value(), ex.getMessage());
    }
}

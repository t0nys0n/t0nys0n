package nz.govt.nzta.dlz.licence;


import nz.govt.nzta.clients.api.ApiGet;
import org.generated.apis.dlz.licence.ApiClient;
import org.generated.apis.dlz.licence.client.DriversApi;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * R is response type Q is query type
 */
public class ApiGetDriver implements ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse, String> {

    private final DriversApi api;
    private final Float version;
    private final String key;

    public ApiGetDriver(final WebClient oAuthClient, final ApiProperties properties) {
        api = createApiClient(oAuthClient, properties.getApiUri());
        version = properties.getApiVersion();
        key = properties.getApiKey();
    }

    @Override
    public NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse get(String licenceNumber) {
        return api.apiDriversGet(licenceNumber, "false", version, key, getRequestIdentifier(), getCurrentTimestamp())
                  .block();
    }

    private DriversApi createApiClient(WebClient webClient, String basePath) {
        var apiClient = new ApiClient(webClient);
        apiClient.setBasePath(basePath);
        return new DriversApi(apiClient);
    }
}

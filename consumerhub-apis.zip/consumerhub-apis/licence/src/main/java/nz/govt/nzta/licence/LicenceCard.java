package nz.govt.nzta.licence;

import lombok.NonNull;
import lombok.Value;

import java.util.Objects;
import java.util.Optional;

@Value
public class LicenceCard {

    @NonNull String version;
    AddressFormatted address;

    public Optional<AddressFormatted> getAddress() {
        if (Objects.nonNull(address) && !address.isEmpty()) {
            return Optional.of(address);
        }
        return Optional.empty();
    }
}

package nz.govt.nzta.dlz.licence;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import nz.govt.nzta.clients.OAuthClientProperties;
import nz.govt.nzta.clients.OAuthFilter;
import nz.govt.nzta.clients.SslUtils;
import nz.govt.nzta.clients.SslWebClient;
import nz.govt.nzta.clients.api.ApiGet;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

@Configuration
@ConditionalOnProperty(prefix = "client.registration.dlz-licence", name = "enabled", matchIfMissing = false)
public class ApiClientConfiguration {

    @Bean("mutualTrustDlz")
    @ConditionalOnProperty(prefix = "client.registration.dlz-licence", name = "ssl-enabled", havingValue = "true", matchIfMissing = false)
    io.netty.handler.ssl.SslContext mutualTrustDlz(@Value("${dlz-mtls-cert}") String tlsClientCert) throws UnrecoverableKeyException, CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException {
        return SslUtils.initSslContextFromPfx(tlsClientCert, "");
    }

    @Bean("mutualTrustDlz")
    @ConditionalOnProperty(prefix = "client.registration.dlz-licence", name = "ssl-enabled", havingValue = "false", matchIfMissing = true)
    io.netty.handler.ssl.SslContext sslContextDefault() throws IOException {
        return SslContextBuilder.forClient()
                .build();
    }

    @Bean("oAuthPropertiesDlz")
    @ConfigurationProperties(prefix = "spring.security.oauth2.client.registration.dlz-licence", ignoreUnknownFields = false)
    @Value("${spring.security.oauth2.client.provider.dlz-licence.token-uri}")
    OAuthClientProperties oAuthPropertiesDlz(String tokenUri) {
        OAuthClientProperties properties = new OAuthClientProperties();
        properties.setTokenUri(tokenUri);
        return properties;
    }

    @Bean("apiPropertiesDlz")
    @ConfigurationProperties(prefix = "client.registration.dlz-licence")
    ApiProperties apiPropertiesDlz() {
        return new ApiProperties();
    }

    @Bean("oAuthClientDlz")
    WebClient oAuthClientDlz(@Qualifier("mutualTrustDlz") final SslContext sslContext, @Qualifier("oAuthPropertiesDlz") final OAuthClientProperties oAuthClientProperties, OAuthFilter oAuthFilter) {
        var oAuthClientFiler = oAuthFilter.buildFor(oAuthClientProperties.getClientName())
                .ssl(sslContext)
                .build();
        return SslWebClient.builder()
                .ssl(sslContext)
                .oAuth(oAuthClientFiler)
                .build();
    }

    @Bean
    ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse, String> apiGetDriver(@Qualifier("oAuthClientDlz") final WebClient oAuthClientDlz, @Qualifier("apiPropertiesDlz") final ApiProperties apiProperties) {
        return new ApiGetDriver(oAuthClientDlz, apiProperties);
    }

    @Bean
    ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse, String> apiGetLicence(@Qualifier("oAuthClientDlz") final WebClient oAuthClientDlz, @Qualifier("apiPropertiesDlz") final ApiProperties apiProperties) {
        return new ApiGetLicence(oAuthClientDlz, apiProperties);
    }

    @Bean
    ApiGet<Void, String> apiGetIssueCoP(@Qualifier("oAuthClientDlz") final WebClient oAuthClientDlz, @Qualifier("apiPropertiesDlz") final ApiProperties apiProperties) {
        return new ApiGetIssueCoP(oAuthClientDlz, apiProperties);
    }
}

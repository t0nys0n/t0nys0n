package nz.govt.nzta.licence;

import lombok.NonNull;

import java.time.Clock;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import static nz.govt.nzta.licence.Licence.GraduatedStage.*;
import static nz.govt.nzta.licence.LicenceClass.ClassStatus.CURRENT;


public record LicenceClasses(@NonNull List<LicenceClass> list) {

    public LicenceClasses {
        Objects.requireNonNull(list, "list is marked non-null but is null");
        list = Collections.unmodifiableList(list);
    }

    public static int sortByStage(LicenceClass classX, LicenceClass classY) {
        if (classX.getStage() == LEARNER) {
            return -1;
        }
        if (classY.getStage() == LEARNER) {
            return 1;
        }
        if (classX.getStage() == RESTRICTED) {
            return -1;
        }
        if (classY.getStage() == RESTRICTED) {
            return 1;
        }
        if (classX.getStage() == FULL) {
            return -1;
        }
        if (classY.getStage() == FULL) {
            return 1;
        }
        return 0;
    }

    public List<LicenceClass> list() {
        return list.stream()
                .filter(c -> !c.getIssueDate().isEmpty())
                .sorted(Comparator.comparing(LicenceClass::getType))
                .toList();
    }

    public Licence.GraduatedStage computeLicenceStage() {
        return list.stream()
                .filter(c -> c.getStatus() == CURRENT)
                .min(LicenceClasses::sortByStage)
                .map(LicenceClass::getStage)
                .orElse(EMPTY);
    }

    public List<LicenceClass> withExpiryCompliance(Clock clock) {
        var today = LocalDate.now(clock);
        return list.stream()
                .filter(c -> !c.isSuppressed(today))
                .filter(c -> c.computeExpiryCompliance(today).isPresent())
                .sorted(Comparator.comparing(LicenceClass::getExpiryDate))
                .toList();
    }
}

package nz.govt.nzta.licence;

import nz.govt.nzta.licence.LicenceResponse.DemeritsPoint;
import org.mapstruct.*;

@Mapper(componentModel = "spring",
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT
)
interface DemeritResponseMapper {

    @Mapping(target = "nextRecalculationDate.date", source = "nextRecalculationDate")
    @Mapping(target = "status.type", source = "status")
    @Mapping(target = "points.total", source = "totalPoints")
    @Mapping(target = "points.level", source = "totalPoints")
    LicenceResponse.Demerits map(Licence.DemeritSummary demeritSummary);

    @ValueMapping(target = "NOSTATUS", source = "EMPTY")
    LicenceResponse.DemeritsStatus.Type map(Licence.DemeritStatus demeritStatus);

    default DemeritsPoint.Level map(int totalPoints) {
        if (totalPoints >= 100) {
            return DemeritsPoint.Level.CRITICAL;
        } else if (totalPoints > 0) {
            return DemeritsPoint.Level.WARN;
        } else {
            return DemeritsPoint.Level.OK;
        }
    }

    default boolean nextRecalculationDateShouldBeHidden(int totalPoints) {
        return totalPoints == 0 || totalPoints >= 100;
    }

    default boolean statusShouldBeHidden(LicenceResponse.DemeritsStatus.Type type) {
        return type == LicenceResponse.DemeritsStatus.Type.NOSTATUS;
    }

    @AfterMapping
    default void map(@MappingTarget LicenceResponse licence) {
        var demerit = licence.getDemerit();
        var dateHidden = nextRecalculationDateShouldBeHidden(demerit.getPoints()
                                                                    .getTotal());
        var statusHidden = statusShouldBeHidden(demerit.getStatus()
                                                       .getType());
        demerit.getNextRecalculationDate()
               .setHidden(dateHidden);
        demerit.getStatus()
               .setHidden(statusHidden);
    }

}

package nz.govt.nzta.licence;


import nz.govt.nzta.licence.LicenceResponse.ComplianceMessage;
import org.mapstruct.*;

import java.time.Clock;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface LicenceComplianceMapper {

    default List<ComplianceMessage> map(Licence licence, @Context Clock clock) {
        var classComplianceMessages = collectClassExpiryCompliances(licence, clock);
        var endorsementComplianceMessages = collectEndorsementExpiryCompliances(licence, clock);
        List<ComplianceMessage> allSortedComplianceMessages = mergeAndSortAll(classComplianceMessages, endorsementComplianceMessages);
        addTopSummaryMessageIfRequires(allSortedComplianceMessages);
        return allSortedComplianceMessages;
    }

    default List<ComplianceMessage> collectClassExpiryCompliances(Licence licence, Clock clock) {
        var expiryComplianceClasses = licence.getExpiryComplianceClasses(clock);
        return expiryComplianceClasses.stream()
                                      .map(clazz -> compose(clazz, LocalDate.now(clock)))
                                      .toList();
    }

    private ComplianceMessage compose(LicenceClass clazz, LocalDate today) throws NoSuchElementException, IllegalArgumentException {
        var compliance = clazz.computeExpiryCompliance(today)
                              .orElseThrow();
        var classType = clazz.getType();
        var className = classType.getTitle();
        var classCode = ComplianceMessage.Code.valueOf(classType.name());
        return ComplianceMessage.compose(compliance, className, classCode);
    }

    default List<ComplianceMessage> collectEndorsementExpiryCompliances(Licence licence, Clock clock) {
        var expiryComplianceEndorsements = licence.getExpiryComplianceEndorsements(clock);
        return expiryComplianceEndorsements.stream()
                                           .map(endorsement -> compose(endorsement, LocalDate.now(clock)))
                                           .toList();
    }

    private ComplianceMessage compose(LicenceEndorsement endorsement, LocalDate today) throws NoSuchElementException, IllegalArgumentException {
        var compliance = endorsement.computeExpiryCompliance(today)
                                    .orElseThrow();
        var endorsementName = "%s (%s) endorsement".formatted(endorsement.getName(), endorsement.getType().getValue());
        var endorsementType = endorsement.getType();
        var endorsementCode = ComplianceMessage.Code.valueOf(endorsementType.name());
        return ComplianceMessage.compose(compliance, endorsementName, endorsementCode);
    }

    default List<ComplianceMessage> mergeAndSortAll(List<ComplianceMessage>... complianceMessages) {
        var all = new ArrayList<ComplianceMessage>();
        Arrays.stream(complianceMessages)
              .forEach(c -> {
                  if (c != null) all.addAll(c);
              });
        return all.stream()
                  .sorted(Comparator.comparing(ComplianceMessage::getLevel))
                  .collect(Collectors.toList());
    }

    default void addTopSummaryMessageIfRequires(List<ComplianceMessage> sortedComplianceMessages) {
        if (sortedComplianceMessages.size() > 1) {
            var urgentComplianceMessage = sortedComplianceMessages.get(0);
            var level = urgentComplianceMessage.getLevel();
            var code = ComplianceMessage.Code.MULTICLASSENDORSEMENT;
            var summaryMessage = new ComplianceMessage(level, getText(level), code);
            sortedComplianceMessages.add(0, summaryMessage);
        }
    }

    private static String getText(ComplianceMessage.Level complianceLevel) {
        if (complianceLevel == ComplianceMessage.Level.CRITICAL) {
            return "Multiple expired classes/endorsements";
        } else {
            return "Multiple classes/endorsements expiring";
        }
    }
}

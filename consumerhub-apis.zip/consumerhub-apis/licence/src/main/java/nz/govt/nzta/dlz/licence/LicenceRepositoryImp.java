package nz.govt.nzta.dlz.licence;

import lombok.RequiredArgsConstructor;
import nz.govt.nzta.clients.api.ApiGet;
import nz.govt.nzta.licence.Licence;
import nz.govt.nzta.licence.LicenceRepository;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@RequiredArgsConstructor
public class LicenceRepositoryImp implements LicenceRepository {

    private final ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse, String> apiGetDriver;
    private final ApiGet<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse, String> apiGetLicence;
    private final ApiGet<Void, String> apiGetIssueCoP;
    private final ApiGetDriverLicenceMapper mapper;

    @Override
    public Licence getLicence(String driverId) {
        var licenceDetails = fetchLicenceDetails(driverId);
        var licenceNumber = getLicenceNumber(licenceDetails);
        var licenceHolderDetails = fetchLicenceHolderDetails(licenceNumber);
        return mapper.map(licenceHolderDetails, licenceDetails);
    }

    @Override
    public String getLicenceNumberOnly(String driverId) {
        var licenceDetails = fetchLicenceDetails(driverId);
        return getLicenceNumber(licenceDetails);
    }

    @Override
    public void issueCoP(String driverId) {
        apiGetIssueCoP.get(driverId);
    }

    private String getLicenceNumber(NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse licenceDetails) {
        return String.valueOf(licenceDetails.getLicence().getId());
    }

    public NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse fetchLicenceHolderDetails(
            String licenceNumber) {
        var response = apiGetDriver.get(licenceNumber);
        Objects.requireNonNull(response, "Empty driver data returned from downstream service");
        Objects.requireNonNull(response.getDriver(), "Empty driver data returned from downstream service");
        return response;
    }

    public NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse fetchLicenceDetails(
            String driverId) {
        var response = apiGetLicence.get(driverId);
        Objects.requireNonNull(response, "Empty licence data returned from downstream service");
        Objects.requireNonNull(response.getLicence(), "Empty licence data returned from downstream service");
        return response;
    }
}

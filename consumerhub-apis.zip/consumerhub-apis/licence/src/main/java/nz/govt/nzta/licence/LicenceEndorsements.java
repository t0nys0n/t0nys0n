package nz.govt.nzta.licence;

import lombok.NonNull;

import java.time.Clock;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import static java.util.function.Predicate.not;

public record LicenceEndorsements(@NonNull List<LicenceEndorsement> list) {

    public LicenceEndorsements {
        Objects.requireNonNull(list, "list is marked non-null but is null");
        list = Collections.unmodifiableList(filterByStatus(list));
    }

    public List<LicenceEndorsement> list() {
        return list.stream()
                .filter(c -> !c.getIssueDate().isEmpty())
                .sorted(Comparator.comparing(LicenceEndorsement::getType)
                        .thenComparing(LicenceEndorsement::getClassType))
                .toList();
    }

    public List<LicenceEndorsement> withExpiryCompliance(Clock clock) {
        var today = LocalDate.now(clock);
        return list.stream()
                .filter(c -> !c.isSuppressed(today))
                .filter(c -> c.computeExpiryCompliance(today).isPresent())
                .sorted(Comparator.comparing(LicenceEndorsement::getExpiryDate))
                .toList();
    }

    private List<LicenceEndorsement> filterByStatus(List<LicenceEndorsement> list) {
        return list.stream()
                .filter(not(LicenceEndorsement::isProhibitStatus))
                .toList();
    }

}

package nz.govt.nzta.licence;

import lombok.NonNull;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public record LicenceConditions(@NonNull List<LicenceCondition> list) {

    public LicenceConditions {
        Objects.requireNonNull(list, "list is marked non-null but is null");
        list = Collections.unmodifiableList(list);
    }

    @Override
    public List<LicenceCondition> list() {
        return list.stream()
                .filter(e -> e.isNotExpired())
                .toList();
    }
}

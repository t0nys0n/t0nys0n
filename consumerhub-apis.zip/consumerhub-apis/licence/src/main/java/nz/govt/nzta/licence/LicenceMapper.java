package nz.govt.nzta.licence;


import nz.govt.nzta.DateFormats;
import org.mapstruct.*;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Mapper(componentModel = "spring",
        uses = {LicenceComplianceMapper.class,
                DemeritResponseMapper.class
        }, injectionStrategy = InjectionStrategy.FIELD,
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT
)
public interface LicenceMapper {
    @Mapping(target = "firstName", source = "firstName", defaultValue = "")
    @Mapping(target = "otherNames", source = "otherNames", defaultValue = "")
    @Mapping(target = "familyName", source = "familyName", defaultValue = "")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth", defaultValue = "")
    @Mapping(target = "donorStatus", source = "donor", qualifiedByName = "mapDonorStatus", defaultValue = "")
    @Mapping(target = "mobilePhone", source = "mobilePhone", defaultValue = "")
    @Mapping(target = "emailAddress", source = "emailAddress", defaultValue = "")
    @Mapping(target = "number", defaultValue = "")
    @Mapping(target = "issueDate", defaultValue = "")
    @Mapping(target = "cardVersion", source = "cardVersion", defaultValue = "")
    @Mapping(target = "status", defaultValue = "EMPTY")
    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "stage", defaultValue = "EMPTY")
    @Mapping(target = "demerit", source = "demerit")
    @Mapping(target = "classEndorsementComplianceMessages", source = ".")
    LicenceResponse map(Licence source, @Context Clock clock);

    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "status.value", source = "status")
    @Mapping(target = "expiryDate", source = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN, defaultValue = "")
    @Mapping(target = "expiryComplianceMessage", source = ".")
    LicenceResponse.Class map(LicenceClass clazz, @Context Clock clock);

    default List<LicenceResponse.Class> mapClasses(List<LicenceClass> classes, @Context Clock clock) {
        var today = LocalDate.now(clock);
        return classes.stream()
                .filter(c -> !c.isSuppressed(today))
                .map(c -> map(c, clock))
                .toList();
    }

    @Mapping(target = "description", source = "type", qualifiedByName = "mapEndorsementDescription")
    @Mapping(target = "status.value", source = "status")
    @Mapping(target = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN, defaultValue = "")
    @Mapping(target = "expiryComplianceMessage", source = ".")
    LicenceResponse.Endorsement map(LicenceEndorsement endorsement, @Context Clock clock);

    default List<LicenceResponse.Endorsement> mapEndorsements(List<LicenceEndorsement> classes, @Context Clock clock) {
        var today = LocalDate.now(clock);
        return classes.stream()
                .filter(c -> !c.isSuppressed(today))
                .map(c -> map(c, clock))
                .toList();
    }

    @Named("mapDonorStatus")
    default String mapDonorStatus(boolean isDonor) {
        return isDonor ? "DONOR" : "NOT A DONOR";
    }

    @Named("mapEndorsementDescription")
    default String mapEndorsementDescription(LicenceEndorsement.EndorsementType type) {
        return String.format("(%s)", type.getValue());
    }

    default Optional<LicenceResponse.ComplianceMessage> mapClassExpiryCompliance(LicenceClass clazz, @Context Clock clock) {
        var className = "Class %s".formatted(clazz.getType()
                .getNumber());
        var today = LocalDate.now(clock);
        return clazz.computeExpiryCompliance(today)
                .map(compliance -> {
                    var classType = clazz.getType();
                    var classCode = LicenceResponse.ComplianceMessage.Code.valueOf(classType.name());
                    return LicenceResponse.ComplianceMessage.compose(compliance, className, classCode);
                });
    }

    default Optional<LicenceResponse.ComplianceMessage> mapEndorsementExpiryCompliance(LicenceEndorsement endorsement, @Context Clock clock) {
        var endorsementName = "%s endorsement".formatted(endorsement.getName());
        var today = LocalDate.now(clock);
        return endorsement.computeExpiryCompliance(today)
                .map(compliance -> {
                    var endorsementType = endorsement.getType();
                    var endorsementCode = LicenceResponse.ComplianceMessage.Code.valueOf(endorsementType.name());
                    return LicenceResponse.ComplianceMessage.compose(compliance, endorsementName, endorsementCode);
                });
    }
}

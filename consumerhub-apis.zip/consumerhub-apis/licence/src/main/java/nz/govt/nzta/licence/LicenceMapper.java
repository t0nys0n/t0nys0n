package nz.govt.nzta.licence;

import nz.govt.nzta.DateFormats;
import nz.govt.nzta.licence.Licence.ExpiryCompliance;
import nz.govt.nzta.licence.LicenceClass.ClassStatus;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementStatus;
import nz.govt.nzta.licence.LicenceResponse.ComplianceMessage;
import org.mapstruct.*;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Mapper(componentModel = "spring", uses = {LicenceComplianceMapper.class,
        DemeritResponseMapper.class
}, injectionStrategy = InjectionStrategy.FIELD, nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT)
public interface LicenceMapper {
    @Mapping(target = "firstName", source = "firstName")
    @Mapping(target = "otherNames", source = "otherNames")
    @Mapping(target = "familyName", source = "familyName")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth")
    @Mapping(target = "donorStatus", source = "donor", qualifiedByName = "mapDonorStatus")
    @Mapping(target = "mobilePhone", source = "mobilePhone")
    @Mapping(target = "emailAddress", source = "emailAddress")
    @Mapping(target = "number")
    @Mapping(target = "issueDate")
    @Mapping(target = "cardVersion", source = "cardVersion")
    @Mapping(target = "status", defaultValue = "EMPTY")
    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "stage", defaultValue = "EMPTY")
    @Mapping(target = "demerit", source = "demerit")
    @Mapping(target = "classEndorsementComplianceMessages", source = ".")
    LicenceResponse map(Licence source, @Context Clock clock);

    @Mapping(target = "type", defaultValue = "EMPTY")
    @Mapping(target = "status.value", source = "status")
    @Mapping(target = "expiryDate", source = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN)
    @Mapping(target = "expiryComplianceMessage", expression = "java(mapClassExpiryCompliance(clazz, clock))")
    LicenceResponse.Class map(LicenceClass clazz, @Context Clock clock);

    default List<LicenceResponse.Class> mapClasses(List<LicenceClass> classes, @Context Clock clock) {
        var today = LocalDate.now(clock);
        return classes.stream()
                .filter(c -> !c.isSuppressed(today))
                .map(c -> map(c, clock))
                .toList();
    }

    @Mapping(target = "description", source = "type", qualifiedByName = "mapEndorsementDescription")
    @Mapping(target = "status.value", source = "status")
    @Mapping(target = "expiryDate", source = "expiryDate", dateFormat = DateFormats.MEDIUM_DATE_PATTERN)
    @Mapping(target = "expiryComplianceMessage", expression = "java(mapEndorsementExpiryCompliance(endorsement, clock))")
    LicenceResponse.Endorsement map(LicenceEndorsement endorsement, @Context Clock clock);

    default List<LicenceResponse.Endorsement> mapEndorsements(List<LicenceEndorsement> endorsements, @Context Clock clock) {
        var today = LocalDate.now(clock);
        return endorsements.stream()
                .filter(e -> !e.isSuppressed(today))
                .map(e -> map(e, clock))
                .toList();
    }

    @Named("mapDonorStatus")
    default String mapDonorStatus(boolean isDonor) {
        return isDonor ? "DONOR" : "NOT A DONOR";
    }

    @Named("mapEndorsementDescription")
    default String mapEndorsementDescription(LicenceEndorsement.EndorsementType type) {
        return String.format("(%s)", type.getValue());
    }

    default ComplianceMessage mapClassExpiryCompliance(LicenceClass clazz, @Context Clock clock) {
        return Optional.of(clazz)
                       .filter(c -> Stream.of(ClassStatus.CURRENT, ClassStatus.LIMITED)
                                          .anyMatch(cs -> cs.equals(c.getStatus())))
                       .flatMap(c -> c.computeExpiryCompliance(LocalDate.now(clock)))
                       .filter(ec -> Stream.of(ExpiryCompliance.Level.EXPIRES_TODAY, ExpiryCompliance.Level.EXPIRES_SOON)
                                           .anyMatch(l -> l.equals(ec.level())))
                       .map(ec -> ComplianceMessage.compose(ec, "Class %s".formatted(clazz.getType()
                                                                                          .getNumber()), ComplianceMessage.Code.valueOf(clazz.getType()
                                                                                                                                             .name())))
                       .orElse(null);
    }

    default ComplianceMessage mapEndorsementExpiryCompliance(LicenceEndorsement endorsement, @Context Clock clock) {
        return Optional.of(endorsement)
                       .filter(e -> Stream.of(EndorsementStatus.CURRENT, EndorsementStatus.LIMITED)
                                          .anyMatch(es -> es.equals(e.getStatus())))
                       .flatMap(e -> e.computeExpiryCompliance(LocalDate.now(clock)))
                       .filter(ec -> Stream.of(ExpiryCompliance.Level.EXPIRES_TODAY, ExpiryCompliance.Level.EXPIRES_SOON)
                                           .anyMatch(l -> l.equals(ec.level())))
                       .map(ec -> ComplianceMessage.compose(ec, "%s endorsement".formatted(endorsement.getName()), ComplianceMessage.Code.valueOf(endorsement.getType()
                                                                                                                                                             .name())))
                       .orElse(null);

    }
}

package nz.govt.nzta.dlz.licence;

import nz.govt.nzta.DataInMemory;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse;

import java.util.Objects;
import java.util.Optional;

public class LicencesInMemory extends DataInMemory<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse> {

    public LicencesInMemory(String jsonFilePath) {
        this(jsonFilePath, NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse.class);
    }

    protected LicencesInMemory(String jsonFilePath, Class clazz) {
        super(jsonFilePath, clazz);
    }

    @Override
    public Optional<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse> get(String id) {
        return list.stream()
                .filter(e -> Objects.equals(id, e.getLicence().getId()))
                .findFirst();
    }
}

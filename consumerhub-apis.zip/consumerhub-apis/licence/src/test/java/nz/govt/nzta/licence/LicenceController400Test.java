package nz.govt.nzta.licence;

import jakarta.validation.ConstraintViolationException;
import nz.govt.nzta.ValidationMessagesConfigs;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.server.configuration.DriverIdClaimInterceptor;
import nz.govt.nzta.server.configuration.OAuthResourceServerConfigs;
import nz.govt.nzta.server.configuration.WebMvcConfigs;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Clock;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest
@ContextConfiguration(classes = LicenceController.class)
@Import({BuildProperties.class, OAuthResourceServerConfigs.class, DriverIdClaimInterceptor.class, WebMvcConfigs.class, ValidationMessagesConfigs.class})
@MockBean({LicenceService.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class LicenceController400Test {

    @MockBean
    LicenceService licenceService;

    @MockBean
    LicenceMapper licenceMapper;

    @MockBean
    Clock clock;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void invalidDriverIdMustReturn400WithMessage() {

        assertThatThrownBy(
                () -> mockMvc.perform(get(ResourcePath.LICENCES)
                        .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "0"))
                                   .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))))

                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("get.driverId: length must be 9 and positive numeric between 1 and 9 digits is required");
    }

    @Test
    void failOnMissingRequestAttribute() throws Exception {

        mockMvc.perform(get(ResourcePath.LICENCES)
                       .with(jwt()
                               .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser")))))
               .andExpect(status().isBadRequest());
    }
}

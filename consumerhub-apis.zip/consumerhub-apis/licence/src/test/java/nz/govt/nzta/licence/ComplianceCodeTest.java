package nz.govt.nzta.licence;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class ComplianceCodeTest {

    @Test
    void complianceMessageCodeMustHaveAllClassTypes() {
        var classTypes = Arrays.stream(LicenceClass.ClassType.values());
        assertDoesNotThrow(() -> classTypes.forEach(type -> LicenceResponse.ComplianceMessage.Code.valueOf(type.name())));
    }

    @Test
    void complianceMessageCodeMustHaveAllEndorsementTypes() {
        var endorsementTypes = Arrays.stream(LicenceEndorsement.EndorsementType.values());
        assertDoesNotThrow(() -> endorsementTypes.forEach(type -> LicenceResponse.ComplianceMessage.Code.valueOf(type.name())));
    }
}

package nz.govt.nzta;

public interface LicenceRepositoryFactory<R, T> {

    R mock(T t);
}

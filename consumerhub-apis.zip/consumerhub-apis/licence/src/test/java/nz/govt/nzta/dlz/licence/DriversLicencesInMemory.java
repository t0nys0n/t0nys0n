package nz.govt.nzta.dlz.licence;

import nz.govt.nzta.DataInMemory;
import nz.govt.nzta.dlz.licence.DriversLicencesInMemory.DriverLicence;

import java.util.Objects;
import java.util.Optional;

public class DriversLicencesInMemory extends DataInMemory<DriverLicence> {

    public DriversLicencesInMemory(String jsonFilePath) {
        this(jsonFilePath, DriverLicence.class);
    }

    protected DriversLicencesInMemory(String jsonFilePath, Class clazz) {
        super(jsonFilePath, clazz);
    }

    @Override
    public Optional<DriverLicence> get(String id) {
        return list.stream()
                .filter(e -> Objects.equals(id, e.getLicenceNumber()))
                .findFirst();
    }

    public static class DriverLicence {

        private Integer driverId;
        private String licenceNumber;

        public Integer getDriverId() {
            return driverId;
        }

        public String getLicenceNumber() {
            return licenceNumber;
        }
    }
}

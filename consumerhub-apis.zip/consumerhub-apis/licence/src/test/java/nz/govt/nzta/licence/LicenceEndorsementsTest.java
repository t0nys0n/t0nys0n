package nz.govt.nzta.licence;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.licence.LicenceClass.ClassType;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementType;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementStatus;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class LicenceEndorsementsTest {

    @Test
    void sortByType() {
        var list = new LinkedList<LicenceEndorsement>();
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.I, "02-01-1990", LocalDate.parse("2000-01-02")));
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.P, "02-01-1990", LocalDate.parse("2000-01-02")));
        var endorsements = new LicenceEndorsements(list);

        var sorted = endorsements.list();

        assertEquals(EndorsementType.P, sorted.get(0).getType());
        assertEquals(EndorsementType.I, sorted.get(1).getType());
    }

    @Test
    void sortByTypeAndClassType() {
        var list = new LinkedList<LicenceEndorsement>();
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.I, "01-01-1990", LocalDate.parse("2000-01-01")));
        list.add(new LicenceEndorsement("", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "01-01-1990", LocalDate.parse("2000-01-01")));
        list.add(new LicenceEndorsement("", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "01-01-1990", LocalDate.parse("2000-01-01")));
        list.add(new LicenceEndorsement("Vehicle Recovery Service", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.REQUALIFY, EndorsementType.V, "14-11-1989", LocalDate.parse("1999-11-14")));
        list.add(new LicenceEndorsement("Testing Officer", ClassType.MOTORCARLIGHTMOTORVEHICLE, EndorsementStatus.REQUALIFY, EndorsementType.O, "14-11-1989", LocalDate.parse("1999-11-14")));
        var endorsements = new LicenceEndorsements(list);

        var sorted = endorsements.list();

        assertEquals(EndorsementType.P, sorted.get(0).getType());
        assertEquals(ClassType.MEDIUMRIGIDVEHICLES, sorted.get(0).getClassType());
        assertEquals(EndorsementType.P, sorted.get(1).getType());
        assertEquals(ClassType.HEAVYRIGIDVEHICLES, sorted.get(1).getClassType());
        assertEquals(EndorsementType.V, sorted.get(2).getType());
        assertEquals(EndorsementType.I, sorted.get(3).getType());
        assertEquals(EndorsementType.O, sorted.get(4).getType());
    }

    @Test
    void sortedExpiryCompliances() {
        var clock = Clock.fixed(Instant.parse("2023-04-23T00:00:00.00Z"), ClockConfigs.NST);
        var list = new LinkedList<LicenceEndorsement>();
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.I, "", LocalDate.parse("2023-04-23")));
        list.add(new LicenceEndorsement("", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "", LocalDate.parse("2023-04-24")));
        list.add(new LicenceEndorsement("", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "", LocalDate.parse("2023-04-22")));
        list.add(new LicenceEndorsement("", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "", LocalDate.parse("2023-06-05")));
        LicenceEndorsements classes = new LicenceEndorsements(list);

        var compliances = classes.withExpiryCompliance(clock);

        assertNotNull(compliances);
        assertEquals(3, compliances.size());
        assertEquals(compliances.get(0), list.get(2));
        assertEquals(compliances.get(1), list.get(0));
        assertEquals(compliances.get(2), list.get(1));
    }

    @Test
    void mustExcludeEndorsementAndComplianceOfProhibitStatus() {
        var clock = Clock.fixed(Instant.parse("2023-04-23T00:00:00.00Z"), ClockConfigs.NST);
        var list = new LinkedList<LicenceEndorsement>();
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.PROHIBIT_P_ENDORSEMENT, EndorsementType.I, "23-04-2013", LocalDate.parse("2023-04-23")));
        list.add(new LicenceEndorsement("", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "22-04-2013", LocalDate.parse("2023-04-22")));
        list.add(new LicenceEndorsement("", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.PROHIBIT_P_ENDORSEMENT, EndorsementType.P, "24-04-2013", LocalDate.parse("2023-04-24")));
        LicenceEndorsements classes = new LicenceEndorsements(list);

        var endorsements = classes.list();
        var compliances = classes.withExpiryCompliance(clock);

        assertNotNull(endorsements);
        assertNotNull(compliances);
        assertEquals(1, endorsements.size());
        assertEquals(1, compliances.size());
    }

    @Test
    void shouldEmptyWithNoIssueDate() {
        var list = new LinkedList<LicenceEndorsement>();
        list.add(new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.PROHIBIT_P_ENDORSEMENT, EndorsementType.I, "", LocalDate.parse("2023-04-23")));
        list.add(new LicenceEndorsement("", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.EMPTY, EndorsementType.P, "", LocalDate.parse("2023-04-22")));
        list.add(new LicenceEndorsement("", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.PROHIBIT_P_ENDORSEMENT, EndorsementType.P, "", LocalDate.parse("2023-04-24")));
        LicenceEndorsements classes = new LicenceEndorsements(list);


        assertEquals(0, classes.list().size());
    }

}

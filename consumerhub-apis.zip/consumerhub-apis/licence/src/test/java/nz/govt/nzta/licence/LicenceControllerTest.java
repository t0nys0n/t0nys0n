package nz.govt.nzta.licence;


import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.DataInMemory;
import nz.govt.nzta.licence.Licence.GraduatedStage;
import nz.govt.nzta.licence.LicenceResponse.ComplianceMessage;
import nz.govt.nzta.licence.LicenceResponse.DemeritsPoint;
import nz.govt.nzta.licence.LicenceResponse.DemeritsStatus.Type;
import nz.govt.nzta.objectmapper.ObjectMapperFactory;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class LicenceControllerTest {

    DataInMemory<Licence> licences = new LicencesInMemory("data/licences.json");
    LicenceMapper mapper = getMapper();
    LicenceService service = mock(LicenceService.class);
    Clock clock = Clock.system(ClockConfigs.NST);
    LicenceController controller = new LicenceController(service, mapper, clock);

    LicenceMapper getMapper() {
        var licenceMapper = Mappers.getMapper(LicenceMapper.class);
        var licenceComplianceMapper = Mappers.getMapper(LicenceComplianceMapper.class);
        var demeritResponseMapper = Mappers.getMapper(DemeritResponseMapper.class);
        ReflectionTestUtils.setField(licenceMapper, "licenceComplianceMapper", licenceComplianceMapper);
        ReflectionTestUtils.setField(licenceMapper, "demeritResponseMapper", demeritResponseMapper);
        return licenceMapper;
    }

    @Test
    void get() {
        var licenceNumber = "AA164622";
        mockResponse(licenceNumber);

        ResponseEntity<LicenceResponse> response = controller.get("AA164622");

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertEquals(200, response.getStatusCode()
                                  .value());

        var body = response.getBody();
        assertEquals("AA164622", body.getNumber());
        assertEquals("DOUGLAS", body.getFirstName());
        assertEquals("JAMES", body.getOtherNames());
        assertEquals("ANDREWS", body.getFamilyName());
        assertEquals("01-01-1945", body.getDateOfBirth());
        assertEquals("DONOR", body.getDonorStatus());
        assertEquals("021234567", body.getMobilePhone());
        assertEquals("test@email.com", body.getEmailAddress());
        assertEquals("002", body.getCardVersion());
        assertEquals("22-08-1962", body.getIssueDate());
        assertEquals(Licence.Type.STANDARD, body.getType());
        assertEquals(GraduatedStage.LEARNER, body.getStage());
        assertEquals(Licence.Status.CURRENT, body.getStatus());
    }

    @Test
    void getSortedClasses() {
        var licenceNumber = "AA164624";
        mockResponse(licenceNumber);
        Clock clock = Clock.fixed(Instant.parse("2010-02-19T00:00:00.00Z"), ClockConfigs.NST);
        var controller = new LicenceController(service, mapper, clock);

        ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody()
                              .getClasses());
        assertFalse(response.getBody()
                            .getClasses()
                            .isEmpty());

        var complianceMessage = new ComplianceMessage(ComplianceMessage.Level.WARN, "Class 6 expires in 19 days", ComplianceMessage.Code.MOTORCYCLESMOPEDORATV);
        var statusCurrent = new LicenceResponse.ClassStatus(LicenceClass.ClassStatus.CURRENT);
        var statusExpired = new LicenceResponse.ClassStatus(LicenceClass.ClassStatus.EXPIRED);
        var statusNotSet = new LicenceResponse.ClassStatus(LicenceClass.ClassStatus.NOTSET);
        var class1 = new LicenceResponse.Class("3L", LicenceClass.ClassType.MEDIUMCOMBINATIONVEHICLES, statusExpired, "19-02-2000", "19-02-2010", null);
        var class2 = new LicenceResponse.Class("4L", LicenceClass.ClassType.HEAVYRIGIDVEHICLES, statusNotSet, "20-02-2000", "20-02-2010", null);
        var class3 = new LicenceResponse.Class("6R", LicenceClass.ClassType.MOTORCYCLESMOPEDORATV, statusCurrent, "18-02-2000", "10-03-2010", complianceMessage);
        assertIterableEquals(List.of(class1, class2, class3), response.getBody()
                                                                      .getClasses());
    }

    @Test
    void getSortedEndorsements() {
        var licenceNumber = "AA164622";
        mockResponse(licenceNumber);
        Clock clock = Clock.fixed(Instant.parse("2010-01-01T00:00:00.00Z"), ClockConfigs.NST);
        var controller = new LicenceController(service, mapper, clock);

        ResponseEntity<LicenceResponse> response = controller.get("AA164622");

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody()
                              .getEndorsements());
        assertFalse(response.getBody()
                            .getEndorsements()
                            .isEmpty());

        var complianceMessages1 = new ComplianceMessage(ComplianceMessage.Level.WARN, "P6 endorsement expires today", ComplianceMessage.Code.P);
        var complianceMessages2 = new ComplianceMessage(ComplianceMessage.Level.WARN, "F endorsement expires in 29 days", ComplianceMessage.Code.F);
        var statusRequalify = new LicenceResponse.EndorsementStatus(LicenceEndorsement.EndorsementStatus.REQUALIFY);
        var statusCurrent = new LicenceResponse.EndorsementStatus(LicenceEndorsement.EndorsementStatus.CURRENT);
        var statusExpired = new LicenceResponse.EndorsementStatus(LicenceEndorsement.EndorsementStatus.EXPIRED);
        var statusLimited = new LicenceResponse.EndorsementStatus(LicenceEndorsement.EndorsementStatus.LIMITED);
        var endorsement1 = new LicenceResponse.Endorsement("P1", "(Passenger)", statusExpired, "02-10-2006", "31-12-2009", null);
        var endorsement2 = new LicenceResponse.Endorsement("P6", "(Passenger)", statusCurrent, "02-10-2006", "01-01-2010", complianceMessages1);
        var endorsement3 = new LicenceResponse.Endorsement("I1", "(Driving instructor)", statusRequalify, "01-10-2004", "12-02-2010", null);
        var endorsement4 = new LicenceResponse.Endorsement("F", "(Forklift)", statusLimited, "01-10-2005", "30-01-2010", complianceMessages2);
        assertIterableEquals(List.of(endorsement1, endorsement2, endorsement3, endorsement4), response.getBody()
                                                                                                      .getEndorsements());
    }

    @Test
    void getNotExpiredConditions() {
        var licenceNumber = "AA164622";
        mockResponse(licenceNumber);

        ResponseEntity<LicenceResponse> response = controller.get("AA164622");

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody()
                              .getConditions());
        assertFalse(response.getBody()
                            .getConditions()
                            .isEmpty());
        assertEquals(2, response.getBody()
                                .getConditions()
                                .size());
        var condition1 = new LicenceResponse.Condition("Must be accompanied by supervisor (except moped / ATV)", "1", "05-04-2013", "");
        var condition2 = new LicenceResponse.Condition("Correcting lenses must be used at all times while driving", "", "05-04-2013", "05-04-2075");
        assertIterableEquals(List.of(condition1, condition2), response.getBody()
                                                                      .getConditions());
    }

    @Test
    void getExpiredMultipleClassEndorsementComplianceMessage() {
        var licenceNumber = "AA164626";
        mockResponse(licenceNumber);
        var clock = Clock.fixed(Instant.parse("2023-04-24T00:00:00.00Z"), ClockConfigs.NST);
        var controller = new LicenceController(service, mapper, clock);

        var response = controller.get(licenceNumber);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody()
                              .getClassEndorsementComplianceMessages());
        assertFalse(response.getBody()
                            .getClassEndorsementComplianceMessages()
                            .isEmpty());
        var complianceMessages1 = new ComplianceMessage(ComplianceMessage.Level.CRITICAL, "Multiple expired classes/endorsements", ComplianceMessage.Code.MULTICLASSENDORSEMENT);
        var complianceMessages2 = new ComplianceMessage(ComplianceMessage.Level.CRITICAL, "Heavy rigid vehicle (class 4) has expired", ComplianceMessage.Code.HEAVYRIGIDVEHICLES);
        var complianceMessages3 = new ComplianceMessage(ComplianceMessage.Level.WARN, "Medium combination vehicle (class 3) expires today", ComplianceMessage.Code.MEDIUMCOMBINATIONVEHICLES);
        var complianceMessages4 = new ComplianceMessage(ComplianceMessage.Level.WARN, "Motorcycles (class 6) expires in 1 days", ComplianceMessage.Code.MOTORCYCLESMOPEDORATV);
        var complianceMessages5 = new ComplianceMessage(ComplianceMessage.Level.WARN, "F (Forklift) endorsement expires today", ComplianceMessage.Code.F);
        var complianceMessages6 = new ComplianceMessage(ComplianceMessage.Level.WARN, "I1 (Driving instructor) endorsement expires in 1 days", ComplianceMessage.Code.I);
        var complianceMessages7 = new ComplianceMessage(ComplianceMessage.Level.WARN, "P6 (Passenger) endorsement expires in 31 days", ComplianceMessage.Code.P);
        var expected = List.of(complianceMessages1, complianceMessages2, complianceMessages3, complianceMessages4, complianceMessages5, complianceMessages6, complianceMessages7);
        var actual = response.getBody()
                             .getClassEndorsementComplianceMessages();
        assertIterableEquals(expected, actual);
    }

    @Test
    void getMultipleClassEndorsementExpiringComplianceMessage() {
        var licenceNumber = "AA164627";
        mockResponse(licenceNumber);
        var clock = Clock.fixed(Instant.parse("2023-04-24T00:00:00.00Z"), ClockConfigs.NST);
        var controller = new LicenceController(service, mapper, clock);

        var response = controller.get(licenceNumber);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody()
                              .getClassEndorsementComplianceMessages());
        assertFalse(response.getBody()
                            .getClassEndorsementComplianceMessages()
                            .isEmpty());
        var complianceMessages1 = new ComplianceMessage(ComplianceMessage.Level.WARN, "Multiple classes/endorsements expiring", ComplianceMessage.Code.MULTICLASSENDORSEMENT);
        var complianceMessages2 = new ComplianceMessage(ComplianceMessage.Level.WARN, "Motorcycles (class 6) expires in 1 days", ComplianceMessage.Code.MOTORCYCLESMOPEDORATV);
        var complianceMessages3 = new ComplianceMessage(ComplianceMessage.Level.WARN, "F (Forklift) endorsement expires today", ComplianceMessage.Code.F);
        var complianceMessages4 = new ComplianceMessage(ComplianceMessage.Level.WARN, "I1 (Driving instructor) endorsement expires in 1 days", ComplianceMessage.Code.I);
        var expected = (List.of(complianceMessages1, complianceMessages2, complianceMessages3, complianceMessages4));
        var actual = response.getBody()
                             .getClassEndorsementComplianceMessages();
        assertIterableEquals(expected, actual);
    }

    @Test
    void whenValuesMissing() {
        var licenceNumber = "AA164623";
        mockResponse(licenceNumber);

        ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertEquals(200, response.getStatusCode()
                                  .value());

        var body = response.getBody();
        assertEquals("AA164623", body.getNumber());
        assertEquals("", body.getFirstName());
        assertEquals("", body.getOtherNames());
        assertEquals("", body.getFamilyName());
        assertEquals("", body.getDateOfBirth());
        assertEquals("NOT A DONOR", body.getDonorStatus());
        assertEquals("", body.getCardVersion());
        assertEquals("", body.getIssueDate());
        assertEquals(Licence.Type.EMPTY, body.getType());
        assertEquals(GraduatedStage.EMPTY, body.getStage());
        assertEquals(Licence.Status.EMPTY, body.getStatus());
        assertNotNull(body.getDemerit());
        var demerit = body.getDemerit();
        assertEquals(0, demerit.getTotalPoints());
        assertEquals(Type.NOSTATUS, demerit.getStatus()
                                           .getType());
        assertTrue(demerit.getStatus()
                          .isHidden());
        assertTrue(demerit.getNextRecalculationDate()
                          .isHidden());
        var demeritPoints = demerit.getPoints();
        assertNotNull(demeritPoints);
        assertEquals(0, demeritPoints.getTotal());
        assertEquals(DemeritsPoint.Level.OK, demeritPoints.getLevel());
        assertNotNull(body.getClasses());
        assertTrue(body.getClasses()
                       .isEmpty());
        assertNotNull(body.getEndorsements());
        assertTrue(body.getEndorsements()
                       .isEmpty());
        assertNotNull(body.getConditions());
        assertTrue(body.getConditions()
                       .isEmpty());
        assertTrue(body.getClassEndorsementComplianceMessages()
                       .isEmpty());
    }

    @Test
    void validateContract() throws IOException {
        var licenceNumber = "AA164622";
        mockResponse(licenceNumber);
        Clock clock = Clock.fixed(Instant.parse("2010-01-01T00:00:00.00Z"), ClockConfigs.NST);
        var controller = new LicenceController(service, mapper, clock);

        ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

        InputStream resource = new ClassPathResource("data/licence_response.json").getInputStream();

        var expectedResponseObject = ObjectMapperFactory.create(true)
                                                        .readValue(resource, LicenceResponse.class);
        var actualResponseObject = response.getBody();
        assertEquals(expectedResponseObject, actualResponseObject);

        var expectedResponseRepresentation = ObjectMapperFactory.create(true)
                                                                .writeValueAsString(expectedResponseObject);
        var actualResponseRepresentation = ObjectMapperFactory.create(true)
                                                              .writeValueAsString(actualResponseObject);
        assertEquals(expectedResponseRepresentation, actualResponseRepresentation);
    }

    private void mockResponse(String licenceNumber) {
        var licence = licences.getElseThrow(licenceNumber);
        when(service.getLicence(licenceNumber)).thenReturn(licence);
    }

    @Nested
    class DemeritResponseMapperTest {
        private static Stream<Arguments> getDemeritsPoint() {
            return Stream.of(
                    Arguments.of("AA164622", 100, DemeritsPoint.Level.CRITICAL),
                    Arguments.of("AA164627", 101, DemeritsPoint.Level.CRITICAL),
                    Arguments.of("AA164626", 99, DemeritsPoint.Level.WARN),
                    Arguments.of("AA164625", 20, DemeritsPoint.Level.WARN),
                    Arguments.of("AA164623", 0, DemeritsPoint.Level.OK),
                    Arguments.of("AA164628", -1, DemeritsPoint.Level.OK)
            );
        }

        private static Stream<Arguments> getDemeritsNextRecalculationDate() {
            return Stream.of(
                    Arguments.of("AA164627", 101, true),
                    Arguments.of("AA164622", 100, true),
                    Arguments.of("AA164623", 0, true),
                    Arguments.of("AA164626", 99, false),
                    Arguments.of("AA164625", 20, false),
                    Arguments.of("AA164628", -1, false)
            );
        }

        private static Stream<Arguments> getDemeritsStatus() {
            return Stream.of(
                    Arguments.of("AA164622", Type.SUSPENDED, false),
                    Arguments.of("AA164623", Type.NOSTATUS, true),
                    Arguments.of("AA164625", Type.NOSTATUS, true)
            );
        }

        @ParameterizedTest
        @MethodSource
        void getDemeritsPoint(String licenceNumber, int expectedTotalPoints, DemeritsPoint.Level expectedPointsLevel) {
            mockResponse(licenceNumber);

            ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

            assertNotNull(response);
            assertNotNull(response.getBody());
            assertNotNull(response.getBody()
                                  .getDemerit());
            var demerits = response.getBody()
                                   .getDemerit();
            assertNotNull(demerits);

            assertNotNull(demerits.getPoints());
            assertEquals(expectedTotalPoints, demerits.getPoints()
                                                      .getTotal());
            assertEquals(expectedPointsLevel, demerits.getPoints()
                                                      .getLevel());
        }

        @ParameterizedTest
        @MethodSource
        void getDemeritsNextRecalculationDate(String licenceNumber, int expectedTotalPoints, boolean expectedHiddenFlag) {
            mockResponse(licenceNumber);

            ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

            assertNotNull(response);
            assertNotNull(response.getBody());
            var demerits = response.getBody()
                                   .getDemerit();
            assertNotNull(demerits);
            assertEquals(expectedTotalPoints, demerits.getPoints()
                                                      .getTotal());
            assertNotNull(demerits.getNextRecalculationDate());
            assertEquals(expectedHiddenFlag, demerits.getNextRecalculationDate()
                                                     .isHidden());
            assertNotNull(demerits.getNextRecalculationDate()
                                  .getDate());
        }

        @ParameterizedTest
        @MethodSource
        void getDemeritsStatus(String licenceNumber, Type expectedType, boolean expectedHiddenFlag) {
            mockResponse(licenceNumber);

            ResponseEntity<LicenceResponse> response = controller.get(licenceNumber);

            assertNotNull(response);
            assertNotNull(response.getBody());
            var demerits = response.getBody()
                                   .getDemerit();
            assertNotNull(demerits);
            assertNotNull(demerits.getStatus());
            assertEquals(expectedType, demerits.getStatus()
                                               .getType());
            assertEquals(expectedHiddenFlag, demerits.getStatus()
                                                     .isHidden());
        }
    }
}
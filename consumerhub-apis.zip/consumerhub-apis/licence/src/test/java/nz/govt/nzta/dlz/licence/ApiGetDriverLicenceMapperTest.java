package nz.govt.nzta.dlz.licence;

import nz.govt.nzta.DataInMemory;
import nz.govt.nzta.licence.LicenceClass;
import nz.govt.nzta.licence.LicenceEndorsement;
import org.generated.apis.dlz.licence.model.*;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;

import java.io.IOException;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class ApiGetDriverLicenceMapperTest {

    DataInMemory<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverLicenceResponse> licences
            = new LicencesInMemory("data/dlz/licences.json");
    ApiGetDriverLicenceMapper mapper = Mappers.getMapper(ApiGetDriverLicenceMapper.class);

    @ParameterizedTest
    @MethodSource
    void mustMapAllLicenceClassStatuses(
            NZTADLRAPIDriverLicencingEnumsClassStatus input,
            LicenceClass.ClassStatus expected) {

        var sourceClass = licences.getElseThrow("AA164622")
                                  .getLicence()
                                  .getClasses()
                                  .get(0);
        sourceClass.setStatus(input);

        var result = mapper.map(sourceClass);
        assertEquals(expected, result.getStatus());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllLicenceEndorsementStatuses(
            NZTADLRAPIDriverLicencingEnumsEndorsementStatus input,
            LicenceEndorsement.EndorsementStatus expected) {

        var sourceEndorsement = licences.getElseThrow("AA164622")
                                        .getLicence()
                                        .getEndorsements()
                                        .get(0);
        sourceEndorsement.setStatus(input);

        var result = mapper.map(sourceEndorsement);
        assertEquals(expected, result.getStatus());
    }

    private static Stream<Arguments> mustMapAllLicenceClassStatuses() {
        return Stream.of(
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.NOTSET, LicenceClass.ClassStatus.NOTSET),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.CANCELLED, LicenceClass.ClassStatus.CANCELLED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.CURRENT, LicenceClass.ClassStatus.CURRENT),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.DISQUALIFIED, LicenceClass.ClassStatus.DISQUALIFIED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.EXPIRED, LicenceClass.ClassStatus.EXPIRED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.INACTIVE, LicenceClass.ClassStatus.INACTIVE),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.LIMITED, LicenceClass.ClassStatus.LIMITED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.REQUALIFY, LicenceClass.ClassStatus.REQUALIFY),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.REVOKED, LicenceClass.ClassStatus.REVOKED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.SUSPENDED, LicenceClass.ClassStatus.SUSPENDED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.VOLUNTARYSURRENDER, LicenceClass.ClassStatus.VOLUNTARY_SURRENDER),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.REINSTATE, LicenceClass.ClassStatus.REINSTATE),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsClassStatus.UNKNOWN, LicenceClass.ClassStatus.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllLicenceEndorsementStatuses() {
        return Stream.of(
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.NOTSET, LicenceEndorsement.EndorsementStatus.NOTSET),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.CANCELLED, LicenceEndorsement.EndorsementStatus.CANCELLED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.CURRENT, LicenceEndorsement.EndorsementStatus.CURRENT),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.DISQUALIFIED, LicenceEndorsement.EndorsementStatus.DISQUALIFIED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.EXPIRED, LicenceEndorsement.EndorsementStatus.EXPIRED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.INACTIVE, LicenceEndorsement.EndorsementStatus.INACTIVE),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.LIMITED, LicenceEndorsement.EndorsementStatus.LIMITED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.REQUALIFY, LicenceEndorsement.EndorsementStatus.REQUALIFY),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.REVOKED, LicenceEndorsement.EndorsementStatus.REVOKED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.SUSPENDED, LicenceEndorsement.EndorsementStatus.SUSPENDED),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.VOLUNTARYSURRENDER, LicenceEndorsement.EndorsementStatus.VOLUNTARY_SURRENDER),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.INACTIVEREQUALIFICATION, LicenceEndorsement.EndorsementStatus.INACTIVE_REQUALIFICATION),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.PROHIBITPENDORSEMENT, LicenceEndorsement.EndorsementStatus.PROHIBIT_P_ENDORSEMENT),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.REINSTATE, LicenceEndorsement.EndorsementStatus.REINSTATE),
                Arguments.of(NZTADLRAPIDriverLicencingEnumsEndorsementStatus.UNKNOWN, LicenceEndorsement.EndorsementStatus.UNKNOWN)
        );
    }
}

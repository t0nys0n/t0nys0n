package nz.govt.nzta.licence;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.licence.Licence.GraduatedStage;
import nz.govt.nzta.licence.LicenceClass.ClassStatus;
import nz.govt.nzta.licence.LicenceClass.ClassType;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class LicenceClassesTest {

    @Test
    void sortedByType() {
        var list = new LinkedList<LicenceClass>();
        var issueDate = "2008-02-18";
        var expiryDate = LocalDate.parse("2010-02-18");
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.HEAVYRIGIDVEHICLES, "", issueDate, expiryDate));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.UNKNOWN, "", issueDate, expiryDate));
        LicenceClasses classes = new LicenceClasses(list);

        assertEquals(ClassType.HEAVYRIGIDVEHICLES, classes.list().get(0).getType());
        assertEquals(ClassType.MOTORCYCLESMOPEDORATV, classes.list().get(1).getType());
        assertEquals(ClassType.UNKNOWN, classes.list().get(2).getType());
    }

    @Test
    void sortedExpiryCompliances() {
        var clock = Clock.fixed(Instant.parse("2023-04-24T00:00:00.00Z"), ClockConfigs.NST);
        var list = new LinkedList<LicenceClass>();
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.HEAVYRIGIDVEHICLES, "", "", LocalDate.parse("2023-04-24")));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.MOTORCYCLESMOPEDORATV, "", "", LocalDate.parse("2023-04-25")));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.UNKNOWN, "", "", LocalDate.parse("2023-04-23")));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.UNKNOWN, "", "", LocalDate.parse("2023-05-25")));
        LicenceClasses classes = new LicenceClasses(list);

        var compliances = classes.withExpiryCompliance(clock);

        assertNotNull(compliances);
        assertEquals(3, compliances.size());
        assertEquals(compliances.get(0),list.get(2));
        assertEquals(compliances.get(1), list.get(0));
        assertEquals(compliances.get(2), list.get(1));
    }

    @Test
    void shouldEmptyWithNoIssueDate() {
        var list = new LinkedList<LicenceClass>();
        var expiryDate = LocalDate.parse("2010-02-18");
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.HEAVYRIGIDVEHICLES, "", "", expiryDate));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.MOTORCYCLESMOPEDORATV, "", "", expiryDate));
        list.add(new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.UNKNOWN, "", "", expiryDate));
        LicenceClasses classes = new LicenceClasses(list);

        assertEquals(0, classes.list().size());
    }
}

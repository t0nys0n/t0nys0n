package nz.govt.nzta.licence;

import nz.govt.nzta.dlz.licence.LicenceRepositoryFactoryImp;
import nz.govt.nzta.licence.Licence.DemeritStatus;
import nz.govt.nzta.licence.Licence.GraduatedStage;
import nz.govt.nzta.licence.Licence.Status;
import nz.govt.nzta.licence.Licence.Type;
import nz.govt.nzta.licence.LicenceClass.ClassStatus;
import nz.govt.nzta.licence.LicenceClass.ClassType;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementStatus;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementType;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LicenceServiceTest {

    @Test
    void retrieveLicenceByNumber() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164622");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164622");

        assertNotNull(response);
        assertEquals("DOUGLAS", response.getFirstName());
        assertEquals("JAMES", response.getOtherNames());
        assertEquals("ANDREWS", response.getFamilyName());
        assertEquals("01-01-1945", response.getDateOfBirth());
        assertEquals(true, response.isDonor());
        assertEquals("021234567", response.getMobilePhone());
        assertEquals("test@email.com", response.getEmailAddress());
        assertEquals("AA164622", response.getNumber());
        assertEquals("22-08-1962", response.getIssueDate());
        assertEquals("002", response.getCardVersion());
        assertEquals(Status.CURRENT, response.getStatus());
        assertEquals(GraduatedStage.RESTRICTED, response.getStage());
        assertEquals(Type.STANDARD, response.getType());

        //demerits
        assertNotNull(response.getDemerit());
        assertEquals(170, response.getDemerit()
                                  .getTotalPoints());
        assertEquals(DemeritStatus.SUSPENDED, response.getDemerit()
                                                      .getStatus());
        assertEquals("14-12-2024", response.getDemerit()
                                           .getNextRecalculationDate());

        //address on card
        assertFalse(response.getAddressOnCard()
                            .isEmpty());
        assertEquals("THE CRIB 1 ABBERFIELD LANE", response.getAddressOnCard()
                                                           .get()
                                                           .line1());
        assertEquals("WELLINGTON CENTRAL", response.getAddressOnCard()
                                                   .get()
                                                   .line2());
        assertEquals("WELLINGTON", response.getAddressOnCard()
                                           .get()
                                           .line3());
        assertEquals("1 ABBERFIELD LANE", response.getAddressOnCard()
                                                  .get()
                                                  .line4());
        assertEquals("THE CRIB 1", response.getAddressOnCard()
                                           .get()
                                           .line5());
    }

    @Test
    void retrieveLicenceClassesByNumber() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164622");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164622");
        assertNotNull(response);
        assertNotNull(response.getClasses());
        assertFalse(response.getClasses()
                            .isEmpty());
        var clazz1 = new LicenceClass(GraduatedStage.LEARNER, ClassStatus.REQUALIFY, ClassType.MOTORCARLIGHTMOTORVEHICLE, "Class 1 - car", "22-08-1962", LocalDate.parse("2010-02-18"));
        var clazz2 = new LicenceClass(GraduatedStage.RESTRICTED, ClassStatus.CURRENT, ClassType.MOTORCARLIGHTMOTORVEHICLE, "Class 1 - car", "22-08-1962", LocalDate.parse("2010-02-18"));
        assertIterableEquals(List.of(clazz1, clazz2), response.getClasses());
    }

    @Test
    void retrieveLicenceEndorsementsByNumber() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164622");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164622");
        assertNotNull(response);
        assertNotNull(response.getEndorsements());
        assertFalse(response.getEndorsements()
                            .isEmpty());

        var endorsement1 = new LicenceEndorsement("Driving Instructor", ClassType.MOTORCARLIGHTMOTORVEHICLE, EndorsementStatus.REQUALIFY, EndorsementType.I, "01-10-2004", LocalDate.parse("2009-10-01"));
        var endorsement2 = new LicenceEndorsement("Passenger", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.REQUALIFY, EndorsementType.P, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement3 = new LicenceEndorsement("Vehicle Recovery", ClassType.HEAVYRIGIDVEHICLES, EndorsementStatus.REQUALIFY, EndorsementType.V, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement4 = new LicenceEndorsement("Testing Officer", ClassType.MOTORCARLIGHTMOTORVEHICLE, EndorsementStatus.REQUALIFY, EndorsementType.O, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement5 = new LicenceEndorsement("Dangerous Goods", ClassType.MOTORCARLIGHTMOTORVEHICLE, EndorsementStatus.REQUALIFY, EndorsementType.D, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement6 = new LicenceEndorsement("Forklift", ClassType.MEDIUMRIGIDVEHICLES, EndorsementStatus.REQUALIFY, EndorsementType.F, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement7 = new LicenceEndorsement("Roller", ClassType.HEAVYCOMBINATIONVEHICLES, EndorsementStatus.REQUALIFY, EndorsementType.R, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement8 = new LicenceEndorsement("Tracks", ClassType.MOTORCYCLESMOPEDORATV, EndorsementStatus.REQUALIFY, EndorsementType.T, "14-11-1989", LocalDate.parse("1999-11-14"));
        var endorsement9 = new LicenceEndorsement("Wheels", ClassType.MOTORCARLIGHTMOTORVEHICLE, EndorsementStatus.REQUALIFY, EndorsementType.W, "14-11-1989", LocalDate.parse("1999-11-14"));

        assertEquals("I1", endorsement1.getName());
        assertEquals("P4", endorsement2.getName());
        assertEquals("V4", endorsement3.getName());
        assertEquals("O1", endorsement4.getName());
        assertEquals("D1", endorsement5.getName());
        assertEquals("F2", endorsement6.getName());
        assertEquals("R5", endorsement7.getName());
        assertEquals("T6", endorsement8.getName());
        assertEquals("W1", endorsement9.getName());

        var expected = List.of(endorsement1);
        assertIterableEquals(expected, response.getEndorsements());
    }

    @Test
    void retrieveLicenceConditionsByNumber() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164622");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164622");
        assertNotNull(response);
        assertNotNull(response.getEndorsements());
        assertFalse(response.getConditions()
                            .isEmpty());

        var condition1 = new LicenceCondition(LicenceCondition.ConditionType.SUPERVISORREQUIRED, "Must be accompanied by supervisor (except moped / ATV)", "1", "05-04-2013", "");
        var condition2 = new LicenceCondition(LicenceCondition.ConditionType.OTHER, "Correcting lenses must be used at all times while driving", "All", "05-04-2013", "");
        var condition3 = new LicenceCondition(LicenceCondition.ConditionType.NOPILIONORSIDECAR, "No side car allowed", "2", "05-04-2013", "05-04-2075");
        assertIterableEquals(List.of(condition1, condition2, condition3), response.getConditions());
    }

    @Test
    void mustFailOnNulls() {
        assertDoesNotThrow(() -> {
            LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164623");
            LicenceService service = new LicenceService(repository);
            var response = service.getLicence("AA164623");
        });
    }

    @Test
    void whenLicenceDetailsHasNulls() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164623");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164623");
        assertNotNull(response);
        assertEquals("", response.getFirstName());
        assertEquals("", response.getOtherNames());
        assertEquals("", response.getFamilyName());
        assertEquals("", response.getDateOfBirth());
        assertEquals(false, response.isDonor());
        assertEquals("AA164623", response.getNumber());
        assertEquals("", response.getIssueDate());
        assertEquals("", response.getCardVersion());
        assertEquals(Status.EMPTY, response.getStatus());
        assertEquals(Licence.GraduatedStage.EMPTY, response.getStage());
        assertEquals(Licence.Type.EMPTY, response.getType());
        assertNotNull(response.getDemerit());
        assertEquals(0, response.getDemerit()
                                .getTotalPoints());
        assertEquals(Licence.DemeritStatus.EMPTY, response.getDemerit()
                                                          .getStatus());
        assertTrue(response.getAddressOnCard()
                           .isEmpty());
    }

    @Test
    void whenClassDetailsHasNulls() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164623");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164623");
        assertNotNull(response);
        assertNotNull(response.getClasses());
        assertFalse(response.getClasses()
                            .isEmpty());
        var clazz = response.getClasses()
                            .get(0);
        assertEquals(Licence.GraduatedStage.EMPTY, clazz.getStage());
        assertEquals(ClassType.EMPTY, clazz.getType());
        assertEquals(ClassStatus.EMPTY, clazz.getStatus());
        assertEquals("", clazz.getDescription());
        assertEquals("-1Empty", clazz.getName());
        assertEquals("18-02-2000", clazz.getIssueDate());
        assertEquals(LocalDate.parse("2010-02-18"), clazz.getExpiryDate());
    }

    @Test
    void whenEndorsementDetailsHasNulls() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164623");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164623");
        assertNotNull(response);
        assertNotNull(response.getEndorsements());
        assertFalse(response.getEndorsements()
                            .isEmpty());
        var endorsement = response.getEndorsements()
                                  .get(0);
        assertEquals("", endorsement.getDescription());
        assertEquals(ClassType.EMPTY, endorsement.getClassType());
        assertEquals(EndorsementStatus.EMPTY, endorsement.getStatus());
        assertEquals(EndorsementType.EMPTY, endorsement.getType());
        assertEquals("18-02-1990", endorsement.getIssueDate());
        assertEquals(LocalDate.parse("2000-01-01"), endorsement.getExpiryDate());
    }

    @Test
    void whenConditionDetailsHasNulls() {
        LicenceRepository repository = new LicenceRepositoryFactoryImp().mock("AA164623");
        LicenceService service = new LicenceService(repository);

        var response = service.getLicence("AA164623");
        assertNotNull(response);
        assertNotNull(response.getConditions());
        assertFalse(response.getConditions()
                            .isEmpty());
        var condition = response.getConditions()
                                .get(0);
        assertEquals(LicenceCondition.ConditionType.EMPTY, condition.getType());
        assertEquals("", condition.getDescription());
        assertEquals("", condition.getApplicableTo());
        assertEquals("", condition.getIssueDate());
        assertEquals("", condition.getExpiryDate());
    }
}

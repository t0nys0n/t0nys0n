package nz.govt.nzta.licence;

import nz.govt.nzta.licence.Licence.ExpiryCompliance;
import nz.govt.nzta.licence.LicenceClass.ClassType;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementStatus;
import nz.govt.nzta.licence.LicenceEndorsement.EndorsementType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LicenceEndorsementTest {

    @Test
    void endorsementMustBeWithoutClassNumberIfClassNotSet() {
        var expiryDate = LocalDate.parse("2000-01-01");
        var endorsement = new LicenceEndorsement("", ClassType.NOTSET, EndorsementStatus.EMPTY, EndorsementType.D, "", expiryDate);
        assertEquals("D", endorsement.getName());
    }

    @Test
    void complianceExpired() {
        var today = LocalDate.parse("2023-04-21");
        var expiryDate = LocalDate.parse("2023-04-20");
        var expiredEndorsement = new LicenceEndorsement("", ClassType.NOTSET, EndorsementStatus.EMPTY, EndorsementType.D, "", expiryDate);

        var compliance = expiredEndorsement.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRED, compliance.get().level());
    }

    @Test
    void complianceExpiresToday() {
        var today = LocalDate.parse("2023-04-23");
        var expiryDate = LocalDate.parse("2023-04-23");
        var expiredEndorsement = new LicenceEndorsement("", ClassType.NOTSET, EndorsementStatus.EMPTY, EndorsementType.F, "", expiryDate);

        var compliance = expiredEndorsement.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRES_TODAY, compliance.get().level());
    }

    @Test
    void complianceExpiresSoonIn42Days() {
        var today = LocalDate.parse("2023-04-19");
        var expiryDate = LocalDate.parse("2023-05-31");
        var expiredEndorsement = new LicenceEndorsement("", ClassType.NOTSET, EndorsementStatus.EMPTY, EndorsementType.P, "", expiryDate);

        var compliance = expiredEndorsement.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRES_SOON, compliance.get().level());
    }

    @Test
    void complianceExpiresSoonIn30Days() {
        var today = LocalDate.parse("2023-04-30");
        var expiryDate = LocalDate.parse("2023-05-30");
        var expiredEndorsement = new LicenceEndorsement("", ClassType.NOTSET, EndorsementStatus.EMPTY, EndorsementType.R, "", expiryDate);

        var compliance = expiredEndorsement.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRES_SOON, compliance.get().level());
    }

    @Test
    void expiredEndorsementIsNotSuppressed4YearNoExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(4);
        LicenceEndorsement endorsement = new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.EMPTY, "", expiryDate);
        assertFalse(endorsement.isSuppressed(today));
    }

    @Test
    void expiredEndorsementIsNotSuppressed4YearExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(4);
        LicenceEndorsement endorsement = new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EXPIRED, EndorsementType.EMPTY, "", expiryDate);
        assertFalse(endorsement.isSuppressed(today));
    }

    @Test
    void expiredEndorsementIsNotSuppressed5YearNoExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(5);
        LicenceEndorsement endorsement = new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EMPTY, EndorsementType.EMPTY, "", expiryDate);
        assertFalse(endorsement.isSuppressed(today));
    }

    @Test
    void expiredEndorsementIsSuppressed5YearExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(5);
        LicenceEndorsement endorsement = new LicenceEndorsement("", ClassType.EMPTY, EndorsementStatus.EXPIRED, EndorsementType.EMPTY, "", expiryDate);
        assertTrue(endorsement.isSuppressed(today));
    }

    @ParameterizedTest
    @CsvSource({
            "NOTSET, NotSet",
            "CANCELLED, Cancelled",
            "CURRENT, Current",
            "DISQUALIFIED, Disqualified",
            "EXPIRED, Expired",
            "INACTIVE, Inactive",
            "LIMITED, Limited",
            "REQUALIFY, Requalify",
            "REVOKED, Revoked",
            "SUSPENDED, Suspended",
            "VOLUNTARY_SURRENDER, Voluntary surrender",
            "INACTIVE_REQUALIFICATION, Inactive requalification",
            "PROHIBIT_P_ENDORSEMENT, Prohibit P endorsement",
            "REINSTATE, Reinstate",
            "UNKNOWN, Unknown",
            "EMPTY, Empty"
    })
    void endorsementStatus_shouldReturnSentenceCaseStringValue(EndorsementStatus status, String expectedValue) {
        assertEquals(status.getValue(), expectedValue);
    }

}

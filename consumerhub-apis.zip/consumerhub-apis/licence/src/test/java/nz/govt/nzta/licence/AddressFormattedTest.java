package nz.govt.nzta.licence;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AddressFormattedTest {

    @Test
    void allNullLinesMustReturnEmpty() {
        var address = new AddressFormatted(null, null, null, null, null);
        assertTrue(address.isEmpty());
    }

    @Test
    void allBlankLinesMustReturnEmpty() {
        var address = new AddressFormatted("   ", "             ", "" +
                "", "    ", "");
        assertTrue(address.isEmpty());
    }

    @Test
    void allNullOrBlankLinesMustReturnEmpty() {
        var address = new AddressFormatted(null, "", "          ", "   ", null);
        assertTrue(address.isEmpty());
    }

    @Test
    void anyNonNullNonBlankLineMustReturnNotEmpty() {
        var address = new AddressFormatted(null, "    ", null, null, "Flat 78");
        assertFalse(address.isEmpty());
    }
}

package nz.govt.nzta;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import nz.govt.nzta.objectmapper.ObjectMapperFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

public abstract class DataInMemory<T> {

    protected List<T> list;
    ObjectMapper mapper = ObjectMapperFactory.create(false);

    protected DataInMemory(String jsonFilePath, Class clazz) {
        JavaType type = mapper.getTypeFactory()
                .constructCollectionType(List.class, clazz);
        try {
            InputStream resource = new ClassPathResource(jsonFilePath).getInputStream();
            mapper.configOverride(LocalDate.class).setFormat(JsonFormat.Value.forPattern("dd-MM-yyyy"));
            list = mapper.readValue(resource, type);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public abstract Optional<T> get(String id);

    public T getElseThrow(String id) throws NoSuchElementException {
        return get(id).orElseThrow();
    }
}

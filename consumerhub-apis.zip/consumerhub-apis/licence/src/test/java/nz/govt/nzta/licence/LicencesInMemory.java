package nz.govt.nzta.licence;

import nz.govt.nzta.DataInMemory;

import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;

public class LicencesInMemory extends DataInMemory<Licence> {

    public LicencesInMemory(String jsonFilePath) {
        this(jsonFilePath, Licence.class);
    }

    protected LicencesInMemory(String jsonFilePath, Class clazz) {
        super(jsonFilePath, clazz);
    }

    @Override
    public Optional<Licence> get(String id) throws NoSuchElementException {
        return list.stream()
                .filter(e -> isMatchedWithLicenceNumberOrDriverId(id, e))
                .findFirst();
    }

    private static boolean isMatchedWithLicenceNumberOrDriverId(String id, Licence e) {
        return Objects.equals(id, e.getNumber()) || Objects.equals(id, e.getDriverId());
    }
}

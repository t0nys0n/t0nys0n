package nz.govt.nzta.dlz.licence;


import nz.govt.nzta.DataInMemory;
import nz.govt.nzta.LicenceRepositoryFactory;
import nz.govt.nzta.clients.api.ApiGet;
import nz.govt.nzta.licence.LicenceRepository;
import org.mapstruct.factory.Mappers;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;

@SuppressWarnings("unchecked")
public class LicenceRepositoryFactoryImp implements
        LicenceRepositoryFactory<LicenceRepository, String> {

    ApiGet apiGetDriver = Mockito.mock(ApiGet.class);
    ApiGet apiGetLicence = Mockito.mock(ApiGet.class);
    ApiGet apiGetIssueCoP = Mockito.mock(ApiGet.class);
    ApiGetDriverLicenceMapper mapper = Mappers.getMapper(ApiGetDriverLicenceMapper.class);
    LicenceRepository repository = new LicenceRepositoryImp(apiGetDriver, apiGetLicence, apiGetIssueCoP, mapper);
    DataInMemory driversInMemory = new DriversInMemory("data/dlz/drivers.json");
    DataInMemory licencesInMemory = new LicencesInMemory("data/dlz/licences.json");

    @Override
    public LicenceRepository mock(String licenceNumber) {
        var driverDetails = driversInMemory.get(licenceNumber).get();
        var licenceDetails = licencesInMemory.get(licenceNumber).get();

        Mockito.when(apiGetDriver.get(licenceNumber))
                .thenReturn(driverDetails);
        Mockito.when(apiGetLicence.get(any()))
                .thenReturn(licenceDetails);
        return repository;
    }
}

package nz.govt.nzta.dlz.licence;

import nz.govt.nzta.DataInMemory;
import org.generated.apis.dlz.licence.model.NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse;

import java.util.Objects;
import java.util.Optional;

public class DriversInMemory extends
        DataInMemory<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse> {

    private final DriversLicencesInMemory driversLicencesInMemory = new DriversLicencesInMemory(
            "data/dlz/drivers-licences.json");

    public DriversInMemory(String jsonFilePath) {
        this(jsonFilePath, NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse.class);
    }

    protected DriversInMemory(String jsonFilePath, Class clazz) {
        super(jsonFilePath, clazz);
    }

    @Override
    public Optional<NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse> get(String id) {
        return driversLicencesInMemory
                .get(id)
                .map(driver -> findDriverByLicenceNumber(driver));
    }

    private NZTADLRAPIDriverLicencingModelsDriversResponseGetDriverResponse findDriverByLicenceNumber(
            DriversLicencesInMemory.DriverLicence driver) {
        return list.stream()
                .filter(e -> Objects.equals(driver.getDriverId(), e.getDriver().getDriverId()))
                .findFirst()
                .get();
    }
}

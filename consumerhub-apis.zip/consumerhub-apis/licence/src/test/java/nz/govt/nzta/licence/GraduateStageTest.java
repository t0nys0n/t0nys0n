package nz.govt.nzta.licence;

import nz.govt.nzta.licence.Licence.GraduatedStage;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import static nz.govt.nzta.licence.Licence.GraduatedStage.*;
import static nz.govt.nzta.licence.LicenceClass.ClassStatus.CURRENT;
import static nz.govt.nzta.licence.LicenceClass.ClassStatus.EXPIRED;
import static nz.govt.nzta.licence.LicenceClass.ClassType.MOTORCYCLESMOPEDORATV;
import static org.junit.jupiter.api.Assertions.assertSame;

class GraduateStageTest {

    LicenceClass learnerClass;
    LicenceClass restrictedClass;
    LicenceClass fullClass;
    LicenceClass notSetClass;
    LicenceClass unknownClass;
    LicenceClass learnerExpiredClass;
    LicenceClass withoutStageClass;

    {
        var issueDate = "18-02-2008";
        var expiryDate = LocalDate.parse("18-02-2010", DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        learnerClass = new LicenceClass(LEARNER, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        restrictedClass = new LicenceClass(RESTRICTED, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        fullClass = new LicenceClass(FULL, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        notSetClass = new LicenceClass(NOTSET, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        unknownClass = new LicenceClass(UNKNOWN, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        learnerExpiredClass = new LicenceClass(LEARNER, EXPIRED, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
        withoutStageClass = new LicenceClass(EMPTY, CURRENT, MOTORCYCLESMOPEDORATV, "", issueDate, expiryDate);
    }

    @Test
    void mustSort() {
        var classes = new LicenceClasses(List.of(
                restrictedClass, notSetClass, learnerClass, fullClass,
                learnerClass, restrictedClass, unknownClass, fullClass)
        );
        var sorted = classes.list()
                .stream()
                .sorted(LicenceClasses::sortByStage)
                .collect(Collectors.toList());

        assertSame(LEARNER, sorted.get(0).getStage());
        assertSame(LEARNER, sorted.get(1).getStage());
        assertSame(RESTRICTED, sorted.get(2).getStage());
        assertSame(RESTRICTED, sorted.get(3).getStage());
        assertSame(FULL, sorted.get(4).getStage());
        assertSame(FULL, sorted.get(5).getStage());
        assertSame(NOTSET, sorted.get(6).getStage());
        assertSame(UNKNOWN, sorted.get(7).getStage());
    }

    @Test
    void mustSortAlreadySorted() {
        var classes = new LicenceClasses(List.of(learnerClass, restrictedClass, fullClass));
        var sorted = classes.list()
                .stream()
                .sorted(LicenceClasses::sortByStage)
                .collect(Collectors.toList());

        assertSame(LEARNER, sorted.get(0).getStage());
        assertSame(RESTRICTED, sorted.get(1).getStage());
        assertSame(FULL, sorted.get(2).getStage());
    }

    @Test
    void mustSortReverseSorted() {
        var classes = new LicenceClasses(List.of(fullClass, restrictedClass, learnerClass));
        var sorted = classes.list()
                .stream()
                .sorted(LicenceClasses::sortByStage)
                .collect(Collectors.toList());

        assertSame(LEARNER, sorted.get(0).getStage());
        assertSame(RESTRICTED, sorted.get(1).getStage());
        assertSame(FULL, sorted.get(2).getStage());
    }

    @Test
    void mustNotSortEmptyStages() {
        var classes = new LicenceClasses(List.of(notSetClass, notSetClass, unknownClass, notSetClass));
        var sorted = classes.list()
                .stream()
                .sorted(LicenceClasses::sortByStage)
                .collect(Collectors.toList());

        assertSame(NOTSET, sorted.get(0).getStage());
        assertSame(NOTSET, sorted.get(1).getStage());
        assertSame(UNKNOWN, sorted.get(2).getStage());
        assertSame(NOTSET, sorted.get(3).getStage());
    }

    @Test
    void mustMapFromCurrentClassesOnly() {
        var classes = new LicenceClasses(List.of(fullClass, restrictedClass, learnerExpiredClass));
        GraduatedStage actual = classes.computeLicenceStage();
        assertSame(RESTRICTED, actual);
    }

    @Test
    void mustMapAllExpiredToEmpty() {
        var classes = new LicenceClasses(List.of(learnerExpiredClass));
        GraduatedStage actual = classes.computeLicenceStage();
        assertSame(EMPTY, actual);
    }

    @Test
    void mustMapEmptyListToEmpty() {
        var classes = new LicenceClasses(List.of());
        GraduatedStage actual = classes.computeLicenceStage();
        assertSame(EMPTY, actual);
    }

    @Test
    void mustMapNullStageToEmpty() {
        var classes = new LicenceClasses(List.of(withoutStageClass));
        GraduatedStage actual = classes.computeLicenceStage();
        assertSame(EMPTY, actual);
    }

    @Test
    void mustMapOtherStages() {
        var classes = new LicenceClasses(List.of(notSetClass, unknownClass));
        GraduatedStage actual = classes.computeLicenceStage();
        assertSame(NOTSET, actual);
    }
}

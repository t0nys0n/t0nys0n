package nz.govt.nzta.licence;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LicenceCardsTest {

    @Test
    void returnVersionOfFirstCard() {
        var card1 = new LicenceCard("002", null);
        var card2 = new LicenceCard("001", null);

        var cards = new LicenceCards(List.of(card1, card2));
        assertSame("002", cards.getCardVersion());
    }

    @Test
    void returnEmptyWhenNoCards() {
        var cards = new LicenceCards(List.of());
        assertSame("", cards.getCardVersion());
    }

    @Test
    void returnEmptyWhenVersionIsEmpty() {
        var card1 = new LicenceCard("", null);
        var cards = new LicenceCards(List.of(card1));
        assertSame("", cards.getCardVersion());
    }

    @Test
    void returnAddressOfFirstCard() {
        var card1 = new LicenceCard("002", new AddressFormatted("78", null, null, null, null));
        var card2 = new LicenceCard("001", null);

        var cards = new LicenceCards(List.of(card1, card2));
        assertFalse(cards.getAddressOnCard()
                         .isEmpty());
        assertSame("78", cards.getAddressOnCard()
                              .get()
                              .line1());
    }

    @Test
    void returnEmptyAddressWhenNull() {
        var card1 = new LicenceCard("1", null);
        var cards = new LicenceCards(List.of(card1));
        assertTrue(cards.getAddressOnCard()
                        .isEmpty());
    }

    @Test
    void returnEmptyAddressWhenAddressLinesAreBlank() {
        var card1 = new LicenceCard("0", new AddressFormatted(null, null, "  ", "      ", null));
        var cards = new LicenceCards(List.of(card1));
        assertTrue(cards.getAddressOnCard()
                        .isEmpty());
    }
}

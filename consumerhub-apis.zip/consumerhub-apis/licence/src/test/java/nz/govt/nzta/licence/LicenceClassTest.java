package nz.govt.nzta.licence;

import nz.govt.nzta.licence.Licence.ExpiryCompliance;
import nz.govt.nzta.licence.Licence.GraduatedStage;
import nz.govt.nzta.licence.LicenceClass.ClassStatus;
import nz.govt.nzta.licence.LicenceClass.ClassType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LicenceClassTest {

    @Test
    void constructClassNameFromClassNumberAndStage() {
        var expiryDate = LocalDate.parse("2010-02-18");
        var description = "Class 1 - car";
        var clazz1 = new LicenceClass(GraduatedStage.LEARNER, ClassStatus.EMPTY, ClassType.MOTORCARLIGHTMOTORVEHICLE, description, "", expiryDate);
        var clazz2 = new LicenceClass(GraduatedStage.RESTRICTED, ClassStatus.EMPTY, ClassType.MEDIUMCOMBINATIONVEHICLES, description, "", expiryDate);
        var clazz3 = new LicenceClass(GraduatedStage.FULL, ClassStatus.EMPTY, ClassType.MOTORCYCLESMOPEDORATV, description, "", expiryDate);
        var clazz4 = new LicenceClass(GraduatedStage.UNKNOWN, ClassStatus.EMPTY, ClassType.NOTSET, description, "", expiryDate);

        assertEquals("1L", clazz1.getName());
        assertEquals("3R", clazz2.getName());
        assertEquals("6", clazz3.getName());
        assertEquals("-1Unknown", clazz4.getName());
    }

    @Test
    void complianceExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = LocalDate.parse("2023-03-30");
        LicenceClass expiredClass = new LicenceClass(GraduatedStage.LEARNER, ClassStatus.EMPTY, ClassType.MOTORCARLIGHTMOTORVEHICLE, "Class 1 - car", "", expiryDate);

        var compliance = expiredClass.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRED, compliance.get().level());
    }

    @Test
    void complianceExpiresToday() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = LocalDate.parse("2023-04-01");
        LicenceClass expiredClass = new LicenceClass(GraduatedStage.LEARNER, ClassStatus.EMPTY, ClassType.HEAVYRIGIDVEHICLES, "Class 1 - car", "", expiryDate);

        var compliance = expiredClass.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRES_TODAY, compliance.get().level());
    }

    @Test
    void complianceExpiresSoon() {
        var today = LocalDate.parse("2023-03-31");
        var expiryDate = LocalDate.parse("2023-04-30");
        LicenceClass expiredClass = new LicenceClass(GraduatedStage.LEARNER, ClassStatus.EMPTY, ClassType.MEDIUMRIGIDVEHICLES, "Class 1 - car", "", expiryDate);

        var compliance = expiredClass.computeExpiryCompliance(today);

        assertTrue(compliance.isPresent());
        assertEquals(ExpiryCompliance.Level.EXPIRES_SOON, compliance.get().level());
    }

    @Test
    void expiredClassIsNotSuppressed4YearNoExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(4);
        LicenceClass clazz = new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.EMPTY, "", "", expiryDate);
        assertFalse(clazz.isSuppressed(today));
    }

    @Test
    void expiredClassIsNotSuppressed4YearExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(4);
        LicenceClass clazz = new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EXPIRED, ClassType.EMPTY, "", "", expiryDate);
        assertFalse(clazz.isSuppressed(today));
    }

    @Test
    void expiredClassIsNotSuppressed5YearNoExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(5);
        LicenceClass clazz = new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EMPTY, ClassType.EMPTY, "", "", expiryDate);
        assertFalse(clazz.isSuppressed(today));
    }

    @Test
    void expiredClassIsSuppressed5YearExpired() {
        var today = LocalDate.parse("2023-04-01");
        var expiryDate = today.minusYears(5);
        LicenceClass clazz = new LicenceClass(GraduatedStage.EMPTY, ClassStatus.EXPIRED, ClassType.EMPTY, "", "", expiryDate);
        assertTrue(clazz.isSuppressed(today));
    }

    @ParameterizedTest
    @CsvSource({
            "NOTSET, NotSet",
            "CANCELLED, Cancelled",
            "CURRENT, Current",
            "DISQUALIFIED, Disqualified",
            "EXPIRED, Expired",
            "INACTIVE, Inactive",
            "LIMITED, Limited",
            "REQUALIFY, Requalify",
            "REVOKED, Revoked",
            "SUSPENDED, Suspended",
            "VOLUNTARY_SURRENDER, Voluntary surrender",
            "REINSTATE, Reinstate",
            "UNKNOWN, Unknown",
            "EMPTY, Empty"
    })
    void classStatus_shouldReturnSentenceCaseStringValue(ClassStatus status, String expectedValue) {
        assertEquals(status.getValue(), expectedValue);
    }
}

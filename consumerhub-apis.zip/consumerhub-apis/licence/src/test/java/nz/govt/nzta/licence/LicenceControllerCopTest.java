package nz.govt.nzta.licence;

import nz.govt.nzta.server.api.ResourcePath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.anonymous;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = LicenceController.class)
class LicenceControllerCopTest {

    @MockBean
    LicenceService licenceService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void whenValidUrlAndMethodAndContentTypeAndNoToken_thenReturns401() throws Exception {
        mockMvc.perform(post(ResourcePath.LICENCES_ISSUE_COP)
                       .content("{}")
                       .contentType(MediaType.APPLICATION_JSON)
                       .with(anonymous()))
               .andExpect(status().isUnauthorized());
    }

    @Test
    void whenValidUrlAndMethodAndContentTypeAndNoContent_thenReturns400() throws Exception {

        doNothing().when(this.licenceService)
                   .issueCoP("15391158");

        mockMvc.perform(post(ResourcePath.LICENCES_ISSUE_COP)
                       .contentType(MediaType.APPLICATION_JSON)
                       .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                  .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser")))))
               .andExpect(status().isBadRequest());

        verify(this.licenceService, times(0)).issueCoP("15391158");
    }

    @Test
    void whenValidUrlAndMethodAndContentType_thenReturns202() throws Exception {

        doNothing().when(this.licenceService)
                   .issueCoP("15391158");

        mockMvc.perform(post(ResourcePath.LICENCES_ISSUE_COP)
                       .content("{}")
                       .contentType(MediaType.APPLICATION_JSON)
                       .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                  .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser")))))
               .andExpect(status().isAccepted());

        verify(this.licenceService, times(1)).issueCoP("15391158");
    }
}

package nz.govt.nzta.licence;

import nz.govt.nzta.SignedJWTBuilder;
import nz.govt.nzta.server.api.ResourcePath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockBeans;
import org.springframework.http.*;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = LicenceController.class)
@MockBeans({
        @MockBean(LicenceService.class),
        @MockBean(LicenceMapper.class)
})
class LicenceControllerIntegrationTest {

    private final String ACCESS_TOKEN_WITH_VALID_CLAIM = new SignedJWTBuilder().driverId("15391158")
                                                                               .build();

    @Autowired
    private MockMvc mockMvc;

    @Test
    void passWhenValidClaimIsExtractedAndSetAsRequestAttribute() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ACCESS_TOKEN_WITH_VALID_CLAIM);

        var request = get(ResourcePath.LICENCES).headers(headers);
        mockMvc.perform(request)
                .andExpect(status().isOk());
    }

}

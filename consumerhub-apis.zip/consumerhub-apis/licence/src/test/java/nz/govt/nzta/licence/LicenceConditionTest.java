package nz.govt.nzta.licence;


import nz.govt.nzta.DateFormats;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LicenceConditionTest {

    @Test
    void isConditionExpired() {
        var condition1 = new LicenceCondition(LicenceCondition.ConditionType.I, "", "", "", pastDate());
        var condition2 = new LicenceCondition(LicenceCondition.ConditionType.I, "", "", "", futureDate());

        assertFalse(condition1.isNotExpired());
        assertTrue(condition2.isNotExpired());
    }

    String pastDate() {
        return LocalDate.now()
                        .minus(1, ChronoUnit.DAYS)
                        .format(DateFormats.MEDIUM_DATE_FORMATTER);
    }

    String futureDate() {
        return LocalDate.now()
                        .plus(1, ChronoUnit.DAYS)
                        .format(DateFormats.MEDIUM_DATE_FORMATTER);
    }

}
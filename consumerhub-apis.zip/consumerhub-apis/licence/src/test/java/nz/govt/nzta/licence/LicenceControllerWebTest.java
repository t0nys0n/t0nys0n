package nz.govt.nzta.licence;

import nz.govt.nzta.DataInMemory;
import nz.govt.nzta.ReturnValueConstraintViolationException;
import nz.govt.nzta.SignedJWTBuilder;
import nz.govt.nzta.server.api.ResourcePath;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockBeans;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@MockBeans({
        @MockBean(LicenceMapper.class)
})
class LicenceControllerWebTest {

    DataInMemory<Licence> licences = new LicencesInMemory("data/licences.json");

    @MockBean
    private LicenceRepository repository;

    @Autowired
    private MockMvc mockMvc;

    @ParameterizedTest(name = "{index} - {0} is not a valid driver id")
    @MethodSource
    void invalidDriverId(String accessToken) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        var request = get(ResourcePath.LICENCES).headers(headers);
        mockMvc.perform(request)
               .andExpect(status().isBadRequest())
               .andExpect(result -> assertEquals("get.driverId: length must be 9 and positive numeric between 1 and 9 digits is required", result.getResolvedException().getMessage()));
    }

    @ParameterizedTest(name = "{index} - {0} is a valid driver id")
    @MethodSource
    void validDriverId(String accessToken) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        var request = get(ResourcePath.LICENCES).headers(headers);
        mockMvc.perform(request)
               .andExpect(status().isOk());
    }

    @Test
    void mustReturnErrorWhenDemeritPointsAreNegative() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        String driverId = "7";
        String accessToken = new SignedJWTBuilder().driverId(driverId).build();
        headers.setBearerAuth(accessToken);
        mockResponse(driverId);
        var request = get(ResourcePath.LICENCES).headers(headers);

        mockMvc.perform(request)
               .andExpect(status().is5xxServerError())
               .andExpect(result -> assertTrue(result.getResolvedException() instanceof ReturnValueConstraintViolationException))
               .andExpect(result -> assertEquals("getLicence.<return value>.demerit.totalPoints: must be greater than or equal to 0", result.getResolvedException().getMessage()));

    }

    private static Stream<Arguments> invalidDriverId() {
        return Stream.of(
                Arguments.of(new SignedJWTBuilder().driverId("0").build()),
                Arguments.of(new SignedJWTBuilder().driverId("00000").build()),
                Arguments.of(new SignedJWTBuilder().driverId("1111111111").build()),
                Arguments.of(new SignedJWTBuilder().driverId("-10000").build()),
                Arguments.of(new SignedJWTBuilder().driverId("+10000").build()),
                Arguments.of(new SignedJWTBuilder().driverId("10A000").build()),
                Arguments.of(new SignedJWTBuilder().driverId("10@000").build())
        );
    }

    private static Stream<Arguments> validDriverId() {
        return Stream.of(
                Arguments.of(new SignedJWTBuilder().driverId("111111111").build()),
                Arguments.of(new SignedJWTBuilder().driverId("15391158").build()),
                Arguments.of(new SignedJWTBuilder().driverId("100000000").build())
        );
    }

    private void mockResponse(String driverId) {
        var licence = licences.getElseThrow(driverId);
        when(repository.getLicence(driverId)).thenReturn(licence);
    }

}

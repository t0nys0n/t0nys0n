# APIs Load Test ![test status](https://github.com/NZTA/consumerhub-apis/actions/workflows/apis-loadtest.yml/badge.svg)

This folder contains scripts and configuration for running load tests of the Consumer Hub APIs.

A Github Workflow ["API Load Test"](https://github.com/NZTA/consumerhub-apis/actions/workflows/apis-loadtest.yml) can be triggered manually
to run a JMeter script in an Azure Load Test engine against the "QA" API endpoints (with prod-like Azure resources).

It can be used for performance regression testing after code changes are deployed to "QA".
The Workflow will fail if response time thresholds are exceeded, indicating that performance has regressed.


## JMeter Script

The JMeter script `api-loadtest.jmx` generates a defined amount of load for the below API endpoints:
- GET /licences
- GET /vehicles/{PLATE}

### Parameters

The script parameter `TPM` (default: 1200 transactions per minute) defines
the number of users that interact with the mobile apps in one minute.

Those interactions include multiple calls to different API endpoints:
1x licences and 2x vehicles (the latter can be modified by changing the parameter `NUMBER_OF_VEHICLES`).

The script runs constant load for 10 minutes (or `DURATION_MINUTES`)
after ramping up to full load within 1 minute or `RAMPUP_MINUTES`).

### Test Data

- Authentication/Licence holder:
  The Realme account "Agency1" (linked to I_SID 20804839) is used to authenticate and obtain an access token from IAM ST.
  The same token is used for all API requests.
  Should the test run long enough for it to expire, a refresh token is used to get a new access token.

- Vehicle data:
  Three plates that exist in the VT backend are used to retrieve vehicle details (assuming no data is cache along the way).


## Azure Load Test

The non-prod Consumer Hub subscription contains an Azure Load Testing component
[nonprod-chub-azlt](https://portal.azure.com/#@nzta.govt.nz/resource/subscriptions/fefd2492-c2ec-4c82-a000-f17d0e240b82/resourceGroups/common-rg/providers/Microsoft.LoadTestService/loadtests/nonprod-chub-azlt/overview)
that can be used to run the above JMeter script.

Though tests can be set up, initiated, and managed there manually, the intention is for this to be used
via a CI/CD pipeline, namely a Github Workflow as described below.


## Github Workflow

The Action [azure/load-testing](https://github.com/marketplace/actions/azure-load-testing) is used
with the configuration in [`azure-loadtest.yml`](./azure-loadtest.yml) to define the test script, parameters as well as failure criteria.

### Parameters

The below Workflow parameters can be modified as required.
- "Test duration in minutes": Default 10 minutes, corresponds to `DURATION_MINUTES` above.
- "App user interactions per minute": Default 500 TPM, corresponds to `TPM` above.

### Failure Criteria

The Workflow will fail if any of the below criteria are exceeded:
- Response times median for "GET /licences" > 500 ms
- Response times median for "GET /vehicles/{PLATE}" > 300ms
- Percentage of failed API requests overall > 1%

### Dependencies

The following secrets are required to be set up correctly for the Github repo as well as a federated identity with appropriate Azure access:
`NONPROD_MI_CLIENT_ID`, `AZURE_NZTA_TENANT_ID`, `NONPROD_SUBSCRIPTION_ID`.


## Reporting

There is no detailed report generated currently, as the intention is automated regression testing.

However, Azure features can be leveraged instead, such as App Insights or the Azure Load Test reports.

Alternatively, results files can be downloaded from Azure and processed offline in JMeter.

package nz.govt.nzta.preference.vehicle;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase(
        replace = AutoConfigureTestDatabase.Replace.NONE
)
@TestPropertySource(properties = {"spring.liquibase.enabled=true"})
class PreferenceVehicleRepositoryTest {

    @Container
    private static final MSSQLServerContainer<?> mssqlserver = new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest").acceptLicense();

    @Autowired
    PreferenceVehicleRepository repository;

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {

        String datasourceUrl = mssqlserver.getJdbcUrl() + ";user=" + mssqlserver.getUsername() + ";password=" + mssqlserver.getPassword() + ";";

        registry.add("spring.datasource.url", datasourceUrl::toString);
        registry.add("spring.liquibase.url", datasourceUrl::toString);
    }

    @Test
    void savePreferenceVehicle() {
        var result = repository.save(PreferenceVehicle.builder()
                                                      .id(UUID.randomUUID())
                                                      .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                            .convertedValue(List.of())
                                                                            .build())
                                                      .build());

        assertThat(result.getId()).isNotNull();
        assertThat(result.getCreatedAt()).isNotNull();
        assertThat(result.getUpdatedAt()).isNotNull();
        assertThat(result.getVersion()).isNotNegative();
    }

    @Test
    void findByIdPreferenceVehicle() {
        var preSaved = repository.save(PreferenceVehicle.builder()
                                                        .id(UUID.randomUUID())
                                                        .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                              .convertedValue(List.of())
                                                                              .build())
                                                        .build());

        var result = repository.findById(preSaved.getId());

        assertThat(result).isPresent();

        var pv = result.get();
        assertThat(pv.getId()).isNotNull();
        assertThat(pv.getCreatedAt()).isNotNull();
        assertThat(pv.getUpdatedAt()).isNotNull();
        assertThat(pv.getVersion()).isNotNegative();
    }
}
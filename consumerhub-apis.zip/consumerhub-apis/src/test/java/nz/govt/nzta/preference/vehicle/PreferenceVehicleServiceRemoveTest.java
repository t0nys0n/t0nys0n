package nz.govt.nzta.preference.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@WithMockUser(username = "f705d424-902c-4966-868d-9e298d664b78", authorities = {"ROLE_VerifiedUser"})
class PreferenceVehicleServiceRemoveTest {

    private final UUID userId = UUID.fromString("f705d424-902c-4966-868d-9e298d664b78");

    private final ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private PreferenceVehicleService preferenceVehicleService;

    @Mock
    private PreferenceVehicleRepository preferenceVehicleRepository;

    @Test
    void shouldReturn404ErrorWhenNoVehicleAdded() {

        when(preferenceVehicleRepository.findById(userId)).thenReturn(Optional.empty());

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.removePreferenceVehicle("ABC123"))
                .withMessage("404 NOT_FOUND \"The Plate Number is not found.\"");

    }

    @Test
    void shouldReturn404ErrorWhenDiffVehicleAdded() {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle))
                                                                                        .build())
                                                                  .build());

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.removePreferenceVehicle("ABC111"))
                .withMessage("404 NOT_FOUND \"The Plate Number is not found.\"");

    }

    @Test
    void shouldReturnVehicleListWithValidRequest() throws Exception {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC123")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("XYZ789")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle1, vehicle2))
                                                                                        .build())
                                                                  .build());

        vehicle2.setSortOrder(0);

        var removedPreferenceVehicle = PreferenceVehicle.builder()
                                                        .id(userId)
                                                        .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                              .convertedValue(List.of(vehicle2))
                                                                              .build())
                                                        .build();

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        when(preferenceVehicleRepository.save(any())).thenReturn(removedPreferenceVehicle);

        var result = preferenceVehicleService.removePreferenceVehicle("ABC123");

        String expectedMessage = "[{\"plateNumber\":\"XYZ789\",\"sortOrder\":0,\"isRegistered\":false}]";
        String actualMessage = objectMapper.writeValueAsString(result);

        assertEquals(expectedMessage, actualMessage);
    }
}

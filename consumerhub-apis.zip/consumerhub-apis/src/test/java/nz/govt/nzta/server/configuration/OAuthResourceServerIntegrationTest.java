package nz.govt.nzta.server.configuration;

import com.nimbusds.jwt.JWTClaimsSet;
import nz.govt.nzta.SignedJWTBuilder;
import nz.govt.nzta.ValidationMessagesConfigs;
import nz.govt.nzta.server.api.ResourcePath;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalManagementPort;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Import;
import org.springframework.http.*;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Date;
import java.util.List;

import static nz.govt.nzta.SignedJWTBuilder.ROLES_CLAIM_NAME;
import static org.junit.jupiter.api.Assertions.*;

@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Import({BuildProperties.class, OAuthResourceServerConfigs.class, ValidationMessagesConfigs.class})
@AutoConfigureTestDatabase(
        replace = AutoConfigureTestDatabase.Replace.NONE
)
class OAuthResourceServerIntegrationTest {

    @Container
    @ServiceConnection
    private static final MSSQLServerContainer<?> mssqlserver = new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest").acceptLicense();
    
    @LocalManagementPort
    int randomManagementPort;
    
    @Autowired
    TestRestTemplate restClient;

    @Test
    void mustCheckTokenExistence() {
        ResponseEntity<Void> response = restClient.getForEntity("/", Void.class);
        assertSame(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void mustCheckMalformedToken() {
        HttpHeaders headers = new HttpHeaders();
        String malformedToken = "eyyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SfflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        headers.setBearerAuth(malformedToken);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<Void> response = restClient.exchange("/", HttpMethod.GET, request, Void.class);

        assertSame(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        List<String> responseHeader = response.getHeaders()
                                              .get(HttpHeaders.WWW_AUTHENTICATE);
        assertNotNull(responseHeader);
        assertFalse(responseHeader.isEmpty());
        assertTrue(responseHeader.get(0)
                                 .contains("invalid_token"));
    }


    @Test
    void mustNotCheckFiltersAndInterceptorsForActuatorPath() {
        ResponseEntity<Void> response = restClient.getForEntity("http://localhost:" + randomManagementPort + "/actuator", Void.class);
        assertSame(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void mustNotVerifyTokenSignature() {
        HttpHeaders headers = new HttpHeaders();
        String signedToken = new SignedJWTBuilder().build();
        headers.setBearerAuth(signedToken);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<Void> response = restClient.exchange("/", HttpMethod.GET, request, Void.class);

        assertSame(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void mustReturnContentSecurityPolicyHeader() {
        HttpHeaders headers = new HttpHeaders();
        String signedToken = new SignedJWTBuilder().build();
        headers.setBearerAuth(signedToken);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<Void> response = restClient.exchange("/", HttpMethod.GET, request, Void.class);

        var header = response.getHeaders()
                             .get("Content-Security-Policy");
        assertNotNull(header);
        assertTrue(header.contains("frame-ancestors 'none'; upgrade-insecure-requests;"));
    }

    @Test
    void mustNotAuthorizeRoleOtherThanAllowedRoles() {
        var jwtBuilder = new JWTClaimsSet.Builder().expirationTime(new Date())
                                                   .claim(ROLES_CLAIM_NAME, "ANONYMOUS");
        String signedToken = new SignedJWTBuilder(jwtBuilder).build();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(signedToken);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<Void> response = restClient.exchange("/", HttpMethod.GET, request, Void.class);

        assertSame(HttpStatus.FORBIDDEN, response.getStatusCode());
    }

    @ParameterizedTest
    @ValueSource(strings = {"VerifiedUser", "DLVerified"})
    void mustAuthorizeAllowedRoles(String role) {
        var jwtBuilder = new JWTClaimsSet.Builder().expirationTime(new Date())
                                                   .claim(ROLES_CLAIM_NAME, role);
        String signedToken = new SignedJWTBuilder(jwtBuilder).build();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(signedToken);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<Void> response = restClient.exchange(ResourcePath.LICENCES, HttpMethod.GET, request, Void.class, "");

        assertNotSame(HttpStatus.FORBIDDEN, response.getStatusCode());
    }

}

package nz.govt.nzta.preference.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@WithMockUser(username = "f705d424-902c-4966-868d-9e298d664b78", authorities = {"ROLE_VerifiedUser"})
class PreferenceVehicleServiceAddTest {

    private final UUID userId = UUID.fromString("f705d424-902c-4966-868d-9e298d664b78");

    private final ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private PreferenceVehicleService preferenceVehicleService;

    @Mock
    private PreferenceVehicleRepository preferenceVehicleRepository;

    @Test
    void shouldReturn422ErrorWhenVehicleAlreadyAdded() {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle))
                                                                                        .build())
                                                                  .build());

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.addPreferenceVehicle(vehicle))
                .withMessage("422 UNPROCESSABLE_ENTITY \"The Plate Number is already added.\"");

    }

    @Test
    void shouldReturnVehicleListWithValidRequestWithoutVehicle() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        var savedPreferenceVehicle = PreferenceVehicle.builder()
                                                      .id(userId)
                                                      .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                            .convertedValue(List.of(vehicle))
                                                                            .build())
                                                      .build();

        when(preferenceVehicleRepository.findById(userId)).thenReturn(Optional.ofNullable(null));


        when(preferenceVehicleRepository.save(any())).thenReturn(savedPreferenceVehicle);

        var result = preferenceVehicleService.addPreferenceVehicle(vehicle);


        String expectedMessage = "[{\"plateNumber\":\"ABC123\",\"sortOrder\":0,\"isRegistered\":false}]";
        String actualMessage = objectMapper.writeValueAsString(result);

        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void shouldReturnVehicleListWithValidRequestWithVehicle() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        var newVehicle = JsonVehicle.builder()
                                    .plateNumber("XYZ789")
                                    .sortOrder(0)
                                    .isRegistered(false)
                                    .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle))
                                                                                        .build())
                                                                  .build());

        vehicle.setSortOrder(1);

        var updatedPreferenceVehicle = PreferenceVehicle.builder()
                                                        .id(userId)
                                                        .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                              .convertedValue(List.of(newVehicle, vehicle))
                                                                              .build())
                                                        .build();

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        when(preferenceVehicleRepository.save(any())).thenReturn(updatedPreferenceVehicle);

        var result = preferenceVehicleService.addPreferenceVehicle(newVehicle);

        String expectedMessage = "[{\"plateNumber\":\"XYZ789\",\"sortOrder\":0,\"isRegistered\":false},{\"plateNumber\":\"ABC123\",\"sortOrder\":1,\"isRegistered\":false}]";
        String actualMessage = objectMapper.writeValueAsString(result);

        assertEquals(expectedMessage, actualMessage);
    }
}

package nz.govt.nzta;

import com.github.dockerjava.api.model.ExposedPort;
import com.github.dockerjava.api.model.HostConfig;
import com.github.dockerjava.api.model.PortBinding;
import com.github.dockerjava.api.model.Ports;
import org.springframework.boot.devtools.restart.RestartScope;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.testcontainers.containers.MSSQLServerContainer;

@TestConfiguration(proxyBeanMethods = false)
public class TestContainersConfiguration {

    @RestartScope
    @Bean
    @ServiceConnection
    public MSSQLServerContainer<?> MSSQLServerContainer() {
        return new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest").acceptLicense()
                                                                                       .withReuse(true)
                                                                                       .withExposedPorts(1433)
                                                                                       .withCreateContainerCmdModifier(cmd -> cmd.withHostConfig(
                                                                                               new HostConfig().withPortBindings(
                                                                                                       new PortBinding(Ports.Binding.bindPort(1433), new ExposedPort(1433)))));
    }
}

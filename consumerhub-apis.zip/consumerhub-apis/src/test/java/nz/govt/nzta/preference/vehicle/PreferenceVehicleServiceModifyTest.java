package nz.govt.nzta.preference.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@WithMockUser(username = "f705d424-902c-4966-868d-9e298d664b78", authorities = {"ROLE_VerifiedUser"})
class PreferenceVehicleServiceModifyTest {

    private final UUID userId = UUID.fromString("f705d424-902c-4966-868d-9e298d664b78");

    private final ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private PreferenceVehicleService preferenceVehicleService;

    @Mock
    private PreferenceVehicleRepository preferenceVehicleRepository;

    @Test
    void shouldReturn409ErrorWhenNoData() {

        var vehicles = List.of(JsonVehicle.builder()
                                          .plateNumber("ABC111")
                                          .sortOrder(0)
                                          .isRegistered(false)
                                          .build(), JsonVehicle.builder()
                                                               .plateNumber("ABC222")
                                                               .sortOrder(1)
                                                               .isRegistered(false)
                                                               .build());

        when(preferenceVehicleRepository.findById(userId)).thenReturn(Optional.empty());

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.modifyPreferenceVehicle(vehicles))
                .withMessage("409 CONFLICT \"[]\"");
    }

    @Test
    void shouldReturn409ErrorWhenInvalidRequestSameSize() {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC222")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var vehicle3 = JsonVehicle.builder()
                                  .plateNumber("ABC333")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle1, vehicle2))
                                                                                        .build())
                                                                  .build());

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        var vehicles = List.of(vehicle1, vehicle3);

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.modifyPreferenceVehicle(vehicles))
                .withMessage("409 CONFLICT \"[{\"plateNumber\":\"ABC111\",\"sortOrder\":0,\"isRegistered\":false},{\"plateNumber\":\"ABC222\",\"sortOrder\":1,\"isRegistered\":false}]\"");
    }

    @Test
    void shouldReturn409ErrorWhenInvalidRequestDiffSize() {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC222")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var vehicle3 = JsonVehicle.builder()
                                  .plateNumber("ABC333")
                                  .sortOrder(2)
                                  .isRegistered(false)
                                  .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle1, vehicle2))
                                                                                        .build())
                                                                  .build());

        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        var vehicles = List.of(vehicle1, vehicle2, vehicle3);

        assertThatExceptionOfType(ResponseStatusException.class)
                .isThrownBy(() -> preferenceVehicleService.modifyPreferenceVehicle(vehicles))
                .withMessage("409 CONFLICT \"[{\"plateNumber\":\"ABC111\",\"sortOrder\":0,\"isRegistered\":false},{\"plateNumber\":\"ABC222\",\"sortOrder\":1,\"isRegistered\":false}]\"");
    }

    @Test
    void shouldReturnVehicleListWithValidRequest() throws Exception {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC222")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var savedPreferenceVehicle = Optional.of(PreferenceVehicle.builder()
                                                                  .id(userId)
                                                                  .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                                        .convertedValue(List.of(vehicle1, vehicle2))
                                                                                        .build())
                                                                  .build());

        vehicle1.setSortOrder(1);
        vehicle2.setSortOrder(0);

        var modifiedPreferenceVehicle = PreferenceVehicle.builder()
                                                         .id(userId)
                                                         .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                                               .convertedValue(List.of(vehicle2, vehicle1))
                                                                               .build())
                                                         .build();


        when(preferenceVehicleRepository.findById(userId)).thenReturn(savedPreferenceVehicle);

        when(preferenceVehicleRepository.save(any())).thenReturn(modifiedPreferenceVehicle);

        var result = preferenceVehicleService.modifyPreferenceVehicle(List.of(vehicle1, vehicle2));

        String expectedMessage = "[{\"plateNumber\":\"ABC222\",\"sortOrder\":0,\"isRegistered\":false},{\"plateNumber\":\"ABC111\",\"sortOrder\":1,\"isRegistered\":false}]";
        String actualMessage = objectMapper.writeValueAsString(result);

        assertEquals(expectedMessage, actualMessage);
    }
}

package nz.govt.nzta.preference.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolationException;
import nz.govt.nzta.ValidationMessagesConfigs;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.server.configuration.OAuthResourceServerConfigs;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.net.URI;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.anonymous;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@ContextConfiguration(classes = PreferenceVehicleController.class)
@Import({BuildProperties.class, OAuthResourceServerConfigs.class, ValidationMessagesConfigs.class})
@MockBean(PreferenceVehicleRepository.class)
class PreferenceVehicleControllerTest {

    @MockBean
    private PreferenceVehicleService preferenceVehicleService;

    @Autowired
    private MockMvc mockMvc;

    private static Stream<Arguments> provideArgumentsFor40X() {
        return Stream.of(
                Arguments.of(POST, ResourcePath.PREFERENCES_VEHICLES, "{\"plateNumber\": \"ABC123\", \"sortOrder\": 0, \"isRegistered\": false}"),
                Arguments.of(GET, ResourcePath.PREFERENCES_VEHICLES, null),
                Arguments.of(PUT, ResourcePath.PREFERENCES_VEHICLES, "[{\"plateNumber\": \"ABC111\", \"sortOrder\": 0, \"isRegistered\": false}, {\"plateNumber\": \"ABC222\", \"sortOrder\": 1, \"isRegistered\": false}]"),
                Arguments.of(DELETE, ResourcePath.PREFERENCES_VEHICLES + "/ABC123", null)
        );
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsFor40X")
    void whenValidUrlAndMethodAndContentTypeAndNoToken_thenReturns401(HttpMethod method, URI uri, String content) throws Exception {

        var request = request(method, ResourcePath.PREFERENCES_VEHICLES);

        if (method == HttpMethod.POST || method == HttpMethod.PUT) {
            request.content(content)
                   .contentType(MediaType.APPLICATION_JSON);
        }

        request.with(anonymous());

        mockMvc.perform(request)
               .andExpect(status().isUnauthorized());
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsFor40X")
    void whenValidUrlAndMethodAndContentTypeAndNoAuthority_thenReturns403(HttpMethod method, URI uri, String content) throws Exception {

        var request = request(method, ResourcePath.PREFERENCES_VEHICLES);

        if (method == HttpMethod.POST || method == HttpMethod.PUT) {
            request.content(content)
                   .contentType(MediaType.APPLICATION_JSON);
        }

        request.with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158")));

        mockMvc.perform(request)
               .andExpect(status().isForbidden());
    }

    @Test
    void whenValidUrlAndPostMethodAndContentTypeAndInvalidPlateNumber_thenReturns400() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123456789")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        mockMvc.perform(post(ResourcePath.PREFERENCES_VEHICLES)
                       .contentType(MediaType.APPLICATION_JSON)
                       .content(new ObjectMapper().writeValueAsString(vehicle))
                       .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                  .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
               )
               .andExpect(status().isBadRequest())
               .andExpect(status().reason("Invalid request content."));
    }

    @Test
    void whenValidUrlAndPostMethodAndContentTypeAndInvalidSortOrder_thenReturns400() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(1)
                                 .isRegistered(false)
                                 .build();

        mockMvc.perform(post(ResourcePath.PREFERENCES_VEHICLES)
                       .contentType(MediaType.APPLICATION_JSON)
                       .content(new ObjectMapper().writeValueAsString(vehicle))
                       .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                  .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
               )
               .andExpect(status().isBadRequest())
               .andExpect(status().reason("`sortOrder` should be 0 and `isRegistered` should be false."));
    }

    @Test
    void whenValidUrlAndPostMethodAndContentTypeAndInvalidRegistered_thenReturns400() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(true)
                                 .build();

        mockMvc.perform(post(ResourcePath.PREFERENCES_VEHICLES)
                       .contentType(MediaType.APPLICATION_JSON)
                       .content(new ObjectMapper().writeValueAsString(vehicle))
                       .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                  .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
               )
               .andExpect(status().isBadRequest())
               .andExpect(status().reason("`sortOrder` should be 0 and `isRegistered` should be false."));
    }

    @Test
    void whenValidUrlAndDeleteMethodAndContentTypeAndInvalidRequest_thenReturns400() {

        assertThatThrownBy(
                () -> mockMvc.perform(delete(ResourcePath.PREFERENCES_VEHICLES + "/XX777777")
                        .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                   .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))))
                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("removePreferenceVehicle.plateNumber: length must be from 1 to 6 characters and an alphanumeric value is required");
    }

    @Test
    void whenValidUrlAndPutMethodAndContentTypeAndInvalidPlateNumber_thenReturns400() {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC123456789")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC123")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        assertThatThrownBy(
                () ->
                        mockMvc.perform(put(ResourcePath.PREFERENCES_VEHICLES)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(new ObjectMapper().writeValueAsString(List.of(vehicle1, vehicle2)))
                                .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                           .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                        ))
                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("plateNumber: length must be from 1 to 6 characters and an alphanumeric value is required");
    }

    @Test
    void whenValidUrlAndPutMethodAndContentTypeAndInvalidSize0_thenReturns400() {

        assertThatThrownBy(
                () ->
                        mockMvc.perform(put(ResourcePath.PREFERENCES_VEHICLES)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(new ObjectMapper().writeValueAsString(List.of()))
                                .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                           .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                        ))
                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The number of vehicles should be greater than 1.");
    }

    @Test
    void whenValidUrlAndPutMethodAndContentTypeAndInvalidSize1_thenReturns400() {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        assertThatThrownBy(
                () ->
                        mockMvc.perform(put(ResourcePath.PREFERENCES_VEHICLES)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(new ObjectMapper().writeValueAsString(List.of(vehicle1)))
                                .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                           .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                        ))
                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The number of vehicles should be greater than 1.");
    }

    @Test
    void whenValidUrlAndPutMethodAndContentTypeAndvalidSizeInvalidOrder_thenReturns400() {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC222")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        assertThatThrownBy(
                () ->
                        mockMvc.perform(put(ResourcePath.PREFERENCES_VEHICLES)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(new ObjectMapper().writeValueAsString(List.of(vehicle1, vehicle2)))
                                .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                           .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                        ))
                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("`sortOrder` is not valid.");
    }

    @Test
    void whenValidUrlAndPostMethodAndContentType_thenReturns201() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        when(this.preferenceVehicleService.addPreferenceVehicle(vehicle)).thenReturn(List.of(vehicle));

        MvcResult result = mockMvc.perform(post(ResourcePath.PREFERENCES_VEHICLES)
                                          .contentType(MediaType.APPLICATION_JSON)
                                          .content(new ObjectMapper().writeValueAsString(vehicle))
                                          .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                                     .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                                  )
                                  .andExpect(status().isCreated())
                                  .andReturn();

        String content = result.getResponse()
                               .getContentAsString();

        assertEquals(new ObjectMapper().writeValueAsString(List.of(vehicle)), content);

    }

    @Test
    void whenValidUrlAndGetMethodAndContentType_thenReturns200() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("ABC123")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        when(this.preferenceVehicleService.getPreferenceVehicle()).thenReturn(List.of(vehicle));

        MvcResult result = mockMvc.perform(get(ResourcePath.PREFERENCES_VEHICLES)
                                          .contentType(MediaType.APPLICATION_JSON)
                                          .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                                     .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                                  )
                                  .andExpect(status().isOk())
                                  .andReturn();

        String content = result.getResponse()
                               .getContentAsString();

        assertEquals(new ObjectMapper().writeValueAsString(List.of(vehicle)), content);

    }

    @Test
    void whenValidUrlAndDeleteMethodAndContentType_thenReturns200() throws Exception {

        var vehicle = JsonVehicle.builder()
                                 .plateNumber("XYZ789")
                                 .sortOrder(0)
                                 .isRegistered(false)
                                 .build();

        when(this.preferenceVehicleService.removePreferenceVehicle("ABC123")).thenReturn(List.of(vehicle));

        MvcResult result = mockMvc.perform(delete(ResourcePath.PREFERENCES_VEHICLES + "/ABC123")
                                          .contentType(MediaType.APPLICATION_JSON)
                                          .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                                     .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                                  )
                                  .andExpect(status().isOk())
                                  .andReturn();

        String content = result.getResponse()
                               .getContentAsString();

        assertEquals(new ObjectMapper().writeValueAsString(List.of(vehicle)), content);

    }

    @Test
    void whenValidUrlAndPutMethodAndContentType_thenReturns202() throws Exception {

        var vehicle1 = JsonVehicle.builder()
                                  .plateNumber("ABC111")
                                  .sortOrder(0)
                                  .isRegistered(false)
                                  .build();

        var vehicle2 = JsonVehicle.builder()
                                  .plateNumber("ABC222")
                                  .sortOrder(1)
                                  .isRegistered(false)
                                  .build();

        var vehicle3 = JsonVehicle.builder()
                                  .plateNumber("ABC333")
                                  .sortOrder(2)
                                  .isRegistered(false)
                                  .build();

        var modifiedList = List.of(vehicle1, vehicle2, vehicle3);


        when(this.preferenceVehicleService.modifyPreferenceVehicle(modifiedList)).thenReturn(modifiedList);

        MvcResult result = mockMvc.perform(put(ResourcePath.PREFERENCES_VEHICLES)
                                          .contentType(MediaType.APPLICATION_JSON)
                                          .content(new ObjectMapper().writeValueAsString(modifiedList))
                                          .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "15391158"))
                                                     .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))
                                  )
                                  .andExpect(status().isOk())
                                  .andReturn();

        String content = result.getResponse()
                               .getContentAsString();

        assertEquals(new ObjectMapper().writeValueAsString(modifiedList), content);

    }
}

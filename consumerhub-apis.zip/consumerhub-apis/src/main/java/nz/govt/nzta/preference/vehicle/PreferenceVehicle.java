package nz.govt.nzta.preference.vehicle;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

@Data
@Builder
@Table(name = "vehicles")
public class PreferenceVehicle {

    @Id
    @Column("user")
    UUID id;

    JsonList<JsonVehicle> vehiclesJson;

    @CreatedDate
    Timestamp createdAt;

    @LastModifiedDate
    Timestamp updatedAt;

    @Version
    Integer version;
}

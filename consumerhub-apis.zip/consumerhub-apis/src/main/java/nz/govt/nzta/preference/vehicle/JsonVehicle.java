package nz.govt.nzta.preference.vehicle;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import nz.govt.nzta.vehicle.ValidPlateNumber;

@Data
@Builder
public class JsonVehicle {

    @ValidPlateNumber
    String plateNumber;

    Integer sortOrder;

    @Schema(defaultValue = "false")
    Boolean isRegistered;
}

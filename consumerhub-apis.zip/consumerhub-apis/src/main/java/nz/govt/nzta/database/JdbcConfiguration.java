package nz.govt.nzta.database;

import nz.govt.nzta.objectmapper.ObjectMapperUtils;
import nz.govt.nzta.preference.vehicle.JsonList;
import nz.govt.nzta.preference.vehicle.JsonVehicle;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.jdbc.core.mapping.JdbcValue;
import org.springframework.data.jdbc.repository.config.AbstractJdbcConfiguration;
import org.springframework.data.jdbc.repository.config.EnableJdbcAuditing;

import java.sql.JDBCType;
import java.util.Arrays;
import java.util.List;

@Configuration
@EnableJdbcAuditing
public class JdbcConfiguration extends AbstractJdbcConfiguration {

    @Override
    protected List<?> userConverters() {
        return Arrays.asList(new JsonListWritingConverter<>(), new JsonListJsonVehicleReadingConverter());
    }

    @WritingConverter
    public class JsonListWritingConverter<T> implements Converter<JsonList<T>, JdbcValue> {

        @Override
        public JdbcValue convert(JsonList<T> jsonList) {
            return JdbcValue.of(ObjectMapperUtils.writeValueAsString(jsonList.getConvertedValue()), JDBCType.VARCHAR);
        }
    }

    @ReadingConverter
    public class JsonListJsonVehicleReadingConverter implements Converter<String, JsonList<JsonVehicle>> {

        @Override
        public JsonList<JsonVehicle> convert(String jsonString) {
            return JsonList.<JsonVehicle>builder()
                           .convertedValue(ObjectMapperUtils.readValueForList(jsonString, JsonVehicle.class))
                           .build();
        }
    }
}
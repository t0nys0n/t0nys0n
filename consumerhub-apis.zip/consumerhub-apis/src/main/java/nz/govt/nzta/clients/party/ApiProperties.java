package nz.govt.nzta.clients.party;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
public class ApiProperties {

    private @NotBlank String baseUrl;

}

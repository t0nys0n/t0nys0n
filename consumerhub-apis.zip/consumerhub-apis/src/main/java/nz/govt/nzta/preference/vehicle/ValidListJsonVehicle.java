package nz.govt.nzta.preference.vehicle;


import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
@Retention(RUNTIME)
@Constraint(validatedBy = ValidListJsonVehicleValidator.class)
public @interface ValidListJsonVehicle {
    String message() default "There is an invalid Request.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}

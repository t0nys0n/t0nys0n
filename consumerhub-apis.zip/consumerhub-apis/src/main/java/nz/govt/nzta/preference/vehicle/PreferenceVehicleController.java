package nz.govt.nzta.preference.vehicle;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.vehicle.ValidPlateNumber;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Validated
@Tag(name = "preferences")
@RequestMapping(ResourcePath.PREFERENCES_VEHICLES)
@RestController
public class PreferenceVehicleController {

    private final PreferenceVehicleService preferenceVehicleService;

    @Operation(operationId = "addPreferenceVehicle", responses = {
            @ApiResponse(responseCode = "201"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "422", description = "Unprocessable Content", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<JsonVehicle>> addPreferenceVehicle(@RequestBody @Valid JsonVehicle vehicle) {
        log.info("add preference vehicle");

        if (vehicle.sortOrder != 0 || Boolean.TRUE.equals(vehicle.isRegistered)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "`sortOrder` should be 0 and `isRegistered` should be false.");
        }

        return ResponseEntity.status(HttpStatus.CREATED)
                             .body(preferenceVehicleService.addPreferenceVehicle(vehicle));
    }

    @Operation(operationId = "getPreferenceVehicle", responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<JsonVehicle>> getPreferenceVehicle(@RequestAttribute("driverId") @Pattern(regexp = "^[1-9]\\d{0,8}$", message = "{validation.messages.driver.id.format}") String driverId) {
        log.info("get preference vehicle");

        return ResponseEntity.ok()
                             .body(preferenceVehicleService.getPreferenceVehicle(driverId));
    }

    @Operation(operationId = "removePreferenceVehicle", responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "404", description = "Not found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @DeleteMapping(value = ResourcePath.PLATE_NUMBER, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<JsonVehicle>> removePreferenceVehicle(@PathVariable(name = "plateNumber") @ValidPlateNumber String plateNumber) {
        log.info("remove preference vehicle");

        return ResponseEntity.ok()
                             .body(preferenceVehicleService.removePreferenceVehicle(plateNumber));
    }

    @Operation(operationId = "modifyPreferenceVehicle", responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
            @ApiResponse(responseCode = "409", description = "Conflict", content = @Content),
            @ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content),
    })
    @PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<JsonVehicle>> modifyPreferenceVehicle(@RequestBody @ValidListJsonVehicle List<@Valid JsonVehicle> vehicles) {
        log.info("modify preference vehicle");

        return ResponseEntity.ok()
                             .body(preferenceVehicleService.modifyPreferenceVehicle(vehicles));
    }

}
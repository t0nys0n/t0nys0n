package nz.govt.nzta;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
@ConditionalOnProperty(
        prefix = "springdoc.swagger-ui",
        name = "enabled"
)
@OpenAPIDefinition(
        tags = {
                @Tag(name = "licences"),
                @Tag(name = "vehicles"),
                @Tag(name = "preferences")
        })
public class OpenApiConfigs {

    @Autowired
    private BuildProperties buildProperties;

    @Value("${spring.security.oauth2.client.provider.swagger-ui.authorization-uri}")
    private String authorizationUrl;

    @Value("${spring.security.oauth2.client.provider.swagger-ui.token-uri}")
    private String tokenUrl;

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(info())
                .components(new Components()
                        .addSecuritySchemes("oauth2", oAuth2())
                )
                .security(Arrays.asList(new SecurityRequirement().addList("oauth2")));
    }

    private Info info() {
        return new Info().title(buildProperties.getName())
                         .version(buildProperties.getVersion());
    }

    private SecurityScheme oAuth2() {
        return new SecurityScheme()
                .type(SecurityScheme.Type.OAUTH2)
                .flows(new OAuthFlows()
                        .authorizationCode(new OAuthFlow()
                                .authorizationUrl(authorizationUrl)
                                .tokenUrl(tokenUrl)));
    }
}

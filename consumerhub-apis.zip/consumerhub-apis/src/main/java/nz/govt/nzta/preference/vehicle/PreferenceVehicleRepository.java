package nz.govt.nzta.preference.vehicle;

import org.springframework.data.relational.core.sql.LockMode;
import org.springframework.data.relational.repository.Lock;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PreferenceVehicleRepository extends ListCrudRepository<PreferenceVehicle, UUID> {

    @Override
    @Lock(LockMode.PESSIMISTIC_WRITE)
    Optional<PreferenceVehicle> findById(UUID id);

}

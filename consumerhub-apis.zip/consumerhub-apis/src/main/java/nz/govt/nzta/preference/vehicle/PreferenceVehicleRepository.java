package nz.govt.nzta.preference.vehicle;

import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PreferenceVehicleRepository extends ListCrudRepository<PreferenceVehicle, UUID> {

}

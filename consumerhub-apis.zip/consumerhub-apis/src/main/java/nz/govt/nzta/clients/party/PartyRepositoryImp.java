package nz.govt.nzta.clients.party;

import generated.openapi.party.model.PartyRoleType;
import generated.openapi.party.model.PartyType;
import generated.openapi.party.model.Status;
import org.springframework.stereotype.Component;

import generated.openapi.party.client.PartiesApi;
import generated.openapi.party.model.GetSuccessResponse;
import lombok.RequiredArgsConstructor;
import nz.govt.nzta.preference.vehicle.PartyRepository;

import java.util.Optional;

@Component
@RequiredArgsConstructor
public class PartyRepositoryImp implements PartyRepository {

    private final PartiesApi partiesApi;

    @Override
    public Optional<String> getPartyId(String driverLicenceNumber) {
        GetSuccessResponse parties = partiesApi.partiesGet(driverLicenceNumber, "RegisteredParty");

        if (!parties.getData()
                       .isEmpty()) {
            for (var party : parties.getData()) {
                if (party.getType()
                         .equals(PartyType.INDIVIDUAL) && party.getRoles()
                                                               .stream()
                                                               .anyMatch(r -> r.getType()
                                                                               .equals(PartyRoleType.REGISTEREDPARTY) && r.getStatus()
                                                                                                                          .equals(Status.ACTIVE))) {
                    return Optional.of(party.getId());
                }
            }
        }
        return Optional.empty();
    }
}

package nz.govt.nzta.clients.party;

import generated.openapi.party.client.PartiesApi;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import nz.govt.nzta.clients.OAuthClientProperties;
import nz.govt.nzta.clients.OAuthFilter;
import nz.govt.nzta.clients.SslWebClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

import java.io.IOException;
import java.util.UUID;

@Configuration
@ConditionalOnProperty(prefix = "client.registration.party", name = "enabled", matchIfMissing = false)
public class ApiClientConfiguration {

    @Bean("mutualTrustParty")
    io.netty.handler.ssl.SslContext sslContextDefault() throws IOException {
        return SslContextBuilder.forClient()
                                .build();
    }

    @Bean("oAuthPropertiesParty")
    @ConfigurationProperties(prefix = "spring.security.oauth2.client.registration.party", ignoreUnknownFields = false)
    @Value("${spring.security.oauth2.client.provider.party.token-uri}")
    OAuthClientProperties oAuthPropertiesParty(String tokenUri) {
        OAuthClientProperties properties = new OAuthClientProperties();
        properties.setTokenUri(tokenUri);
        return properties;
    }

    @Bean("apiPropertiesParty")
    @ConfigurationProperties(prefix = "client.registration.party")
    ApiProperties apiPropertiesParty() {
        return new ApiProperties();
    }

    @Bean
    PartiesApi partiesApi(
            @Qualifier("mutualTrustParty") final SslContext sslContext,
            @Qualifier("oAuthPropertiesParty") final OAuthClientProperties oAuthClientProperties,
            @Qualifier("apiPropertiesParty") final ApiProperties apiProperties,
            OAuthFilter oAuthFilter
    ) {
        var oAuthClientFiler = oAuthFilter.buildFor(oAuthClientProperties.getClientName())
                                          .ssl(sslContext)
                                          .build();

        WebClient client = SslWebClient.builderNoErrorHandler()
                                       .ssl(sslContext)
                                       .oAuth(oAuthClientFiler)
                                       .filter(addRequestHeaders())
                                       .baseUrl(apiProperties.getBaseUrl())
                                       .build();

        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(WebClientAdapter.create(client))
                                                                 .build();

        return factory.createClient(PartiesApi.class);
    }

    ExchangeFilterFunction addRequestHeaders() {
        return (request, next) -> {
            ClientRequest clientRequest = ClientRequest.from(request)
                                                       .header("x-application-id", "consumerHub")
                                                       .header("x-channel-id", "Mobile")
                                                       .header("x-wk-bu", "")
                                                       .header("x-wk-correlation-id", UUID.randomUUID()
                                                                                          .toString())
                                                       .header("x-wk-transaction-id", UUID.randomUUID()
                                                                                          .toString())
                                                       .build();

            return next.exchange(clientRequest);
        };
    }
}

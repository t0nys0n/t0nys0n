package nz.govt.nzta.clients.party;

import generated.openapi.party.client.PartiesApi;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import nz.govt.nzta.clients.OAuthClientProperties;
import nz.govt.nzta.clients.OAuthFilter;
import nz.govt.nzta.clients.SslWebClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

import java.io.IOException;

@Configuration
@ConditionalOnProperty(prefix = "client.registration.party", name = "enabled", matchIfMissing = false)
public class ApiClientConfiguration {

    @Bean("mutualTrustParty")
    io.netty.handler.ssl.SslContext sslContextDefault() throws IOException {
        return SslContextBuilder.forClient()
                                .build();
    }

    @Bean("oAuthPropertiesParty")
    @ConfigurationProperties(prefix = "spring.security.oauth2.client.registration.party", ignoreUnknownFields = false)
    @Value("${spring.security.oauth2.client.provider.party.token-uri}")
    OAuthClientProperties oAuthPropertiesParty(String tokenUri) {
        OAuthClientProperties properties = new OAuthClientProperties();
        properties.setTokenUri(tokenUri);
        return properties;
    }

    @Bean("apiPropertiesParty")
    @ConfigurationProperties(prefix = "client.registration.party")
    ApiProperties apiPropertiesParty() {
        return new ApiProperties();
    }

    @Bean
    PartiesApi partiesApi(
            @Qualifier("mutualTrustParty") final SslContext sslContext,
            @Qualifier("oAuthPropertiesParty") final OAuthClientProperties oAuthClientProperties,
            @Qualifier("apiPropertiesParty") final ApiProperties apiProperties,
            OAuthFilter oAuthFilter
    ) {
        var oAuthClientFiler = oAuthFilter.buildFor(oAuthClientProperties.getClientName())
                                          .ssl(sslContext)
                                          .build();
        WebClient client = SslWebClient.builder()
                                       .ssl(sslContext)
                                       .oAuth(oAuthClientFiler)
                                       .baseUrl(apiProperties.getBaseUrl())
                                       .muleHeader()
                                       .build();

        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(WebClientAdapter.create(client))
                                                                 .build();

        return factory.createClient(PartiesApi.class);
    }
}

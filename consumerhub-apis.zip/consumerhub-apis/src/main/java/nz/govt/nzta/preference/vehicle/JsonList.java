package nz.govt.nzta.preference.vehicle;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class JsonList<T> {

    List<T> convertedValue;
}

package nz.govt.nzta.preference.vehicle;

import java.util.Optional;

public interface PartyRepository {

    Optional<String> getPartyId(String driverLicenceNumber);
}

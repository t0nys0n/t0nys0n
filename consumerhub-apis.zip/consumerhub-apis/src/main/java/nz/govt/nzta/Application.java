package nz.govt.nzta;

import com.microsoft.applicationinsights.attach.ApplicationInsights;
import lombok.Generated;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FullyQualifiedAnnotationBeanNameGenerator;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;

import java.util.TimeZone;

import static nz.govt.nzta.ClockConfigs.NST;

@EnableJdbcRepositories
@SpringBootApplication
@ComponentScan(nameGenerator = FullyQualifiedAnnotationBeanNameGenerator.class)
public class Application {

    @Generated
    public static void main(String[] args) {
        initialiseTimeZone();
        ApplicationInsights.attach();
        SpringApplication.run(Application.class, args);
    }

    private static void initialiseTimeZone() {
        TimeZone.setDefault(TimeZone.getTimeZone(NST));
    }
}

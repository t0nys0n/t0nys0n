package nz.govt.nzta.preference.vehicle;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.licence.LicenceRepository;
import nz.govt.nzta.objectmapper.ObjectMapperUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
public class PreferenceVehicleService {

    private final PreferenceVehicleRepository repository;

    private final LicenceRepository licenceRepository;

    private final PartyRepository partyRepository;

    public List<JsonVehicle> addPreferenceVehicle(JsonVehicle requestVehicle) {

        var userId = getUserId();

        PreferenceVehicle preferenceVehicle =
                repository.findById(userId)
                          .map(pv -> getPreferenceVehicleWithAdjustInsert(requestVehicle, pv))
                          .orElse(createNewPreferenceVehicle(requestVehicle, userId));

        return repository.save(preferenceVehicle)
                         .getVehiclesJson()
                         .getConvertedValue();
    }

    private PreferenceVehicle getPreferenceVehicleWithAdjustInsert(JsonVehicle requestVehicle, PreferenceVehicle pv) {
        List<JsonVehicle> vehicles = new ArrayList<>(pv.getVehiclesJson()
                                                       .getConvertedValue());

        checkIfVehicleExistsForAdd(vehicles, requestVehicle.getPlateNumber());

        for (int i = 0; i < vehicles.size(); i++) {
            vehicles.get(i)
                    .setSortOrder(i + 1);
        }

        vehicles.add(0, requestVehicle);

        pv.getVehiclesJson()
          .setConvertedValue(vehicles);

        return pv;
    }

    private PreferenceVehicle createNewPreferenceVehicle(JsonVehicle requestVehicle, UUID userId) {
        return PreferenceVehicle.builder()
                                .id(userId)
                                .vehiclesJson(JsonList.<JsonVehicle>builder()
                                                      .convertedValue(List.of(requestVehicle))
                                                      .build())
                                .build();
    }

    private void checkIfVehicleExistsForAdd(List<JsonVehicle> vehicles, String plateNumber) {
        if (vehicles.stream()
                    .anyMatch(v -> v.plateNumber.equals(plateNumber))) {
            log.warn("The Plate Number is already added.");

            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "The Plate Number is already added.");
        }
    }

    public List<JsonVehicle> getPreferenceVehicle(String driverId) {

        var userId = getUserId();

        // get Licence Number
        var licenceNumber = licenceRepository.getLicenceNumberOnly(driverId);

        System.out.println("licenceNumber: ");
        System.out.println(licenceNumber);

        // get MVR I_SID from Party API
        var mvrId = partyRepository.getPartyId("BB444212");

        System.out.println("MVR I_SID: ");
        mvrId.ifPresent(System.out::println);

        // get registered vehicles from Registration API
        //var registeredVehicles = mvrId.map(id ->  ).orElse(List.of());

        // merge info with DB

        // return result/

        return repository.findById(userId)
                         .map(pv -> pv.getVehiclesJson()
                                      .getConvertedValue())
                         .orElse(List.of());
    }

    private UUID getUserId() {
        Authentication authentication = SecurityContextHolder.getContext()
                                                             .getAuthentication();
        var userId = UUID.fromString(authentication.getName());

        Objects.requireNonNull(userId, "User Id shouldn't be null.");

        return userId;
    }

    public List<JsonVehicle> removePreferenceVehicle(String plateNumber) {

        var userId = getUserId();

        PreferenceVehicle preferenceVehicle =
                repository.findById(userId)
                          .map(pv -> removePreferenceVehicleWithFilterAdjust(plateNumber, pv))
                          .orElseThrow(() -> {
                              log.warn("The Plate Number is not found.");

                              return new ResponseStatusException(HttpStatus.NOT_FOUND, "The Plate Number is not found.");
                          });

        return repository.save(preferenceVehicle)
                         .getVehiclesJson()
                         .getConvertedValue();
    }

    private PreferenceVehicle removePreferenceVehicleWithFilterAdjust(String plateNumber, PreferenceVehicle pv) {
        List<JsonVehicle> vehicles = new ArrayList<>(pv.getVehiclesJson()
                                                       .getConvertedValue());

        checkIfVehicleExistsForRemove(vehicles, plateNumber);

        vehicles = vehicles.stream()
                           .filter(v -> !v.plateNumber.equals(plateNumber))
                           .toList();

        for (int i = 0; i < vehicles.size(); i++) {
            vehicles.get(i)
                    .setSortOrder(i);
        }

        pv.getVehiclesJson()
          .setConvertedValue(vehicles);

        return pv;
    }

    private void checkIfVehicleExistsForRemove(List<JsonVehicle> vehicles, String plateNumber) {
        if (vehicles.stream()
                    .noneMatch(v -> v.plateNumber.equals(plateNumber))) {
            log.warn("The Plate Number is not found.");

            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "The Plate Number is not found.");
        }
    }

    public List<JsonVehicle> modifyPreferenceVehicle(List<JsonVehicle> requestVehicles) {

        var userId = getUserId();

        PreferenceVehicle preferenceVehicle =
                repository.findById(userId)
                          .map(pv -> modifyPreferenceVehicleWithCheck(requestVehicles, pv))
                          .orElseThrow(() -> {
                              log.warn("The request data conflicts with DB data.");

                              return new ResponseStatusException(HttpStatus.CONFLICT, "[]");
                          });

        return repository.save(preferenceVehicle)
                         .getVehiclesJson()
                         .getConvertedValue();
    }

    private PreferenceVehicle modifyPreferenceVehicleWithCheck(List<JsonVehicle> requestVehicles, PreferenceVehicle pv) {

        requestVehicles = requestVehicles.stream().sorted(Comparator.comparingInt(JsonVehicle::getSortOrder)).toList();

        checkRequestIsValid(requestVehicles, pv);

        pv.getVehiclesJson()
          .setConvertedValue(requestVehicles);

        return pv;
    }

    private void checkRequestIsValid(List<JsonVehicle> requestVehicles, PreferenceVehicle pv) {

        List<JsonVehicle> vehicles = new ArrayList<>(pv.getVehiclesJson()
                                                       .getConvertedValue());

        if (
                requestVehicles.size() != vehicles.size() ||
                !requestVehicles.stream()
                                .map(JsonVehicle::getPlateNumber)
                                .sorted(Comparable::compareTo)
                                .collect(Collectors.joining())
                                .equals(vehicles.stream()
                                                .map(JsonVehicle::getPlateNumber)
                                                .sorted(Comparable::compareTo)
                                                .collect(Collectors.joining()))
        ) {
            log.warn("The request data conflicts with DB data.");

            throw new ResponseStatusException(HttpStatus.CONFLICT, ObjectMapperUtils.writeValueAsString(vehicles));
        }
    }

}

package nz.govt.nzta.preference.vehicle;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class ValidListJsonVehicleValidator implements ConstraintValidator<ValidListJsonVehicle, List<JsonVehicle>> {

    @Override
    public boolean isValid(List<JsonVehicle> vehicles, ConstraintValidatorContext context) {

        if (vehicles.size() < 2) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("The number of vehicles should be greater than 1.")
                   .addConstraintViolation();
            return false;
        }

        List<JsonVehicle> finalVehicles = vehicles.stream()
                                                  .sorted(Comparator.comparingInt(JsonVehicle::getSortOrder))
                                                  .toList();

        if (IntStream.range(0, vehicles.size())
                     .anyMatch(i -> finalVehicles.get(i)
                                                 .getSortOrder() != i)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("`sortOrder` is not valid.")
                   .addConstraintViolation();

            return false;
        }
        return true;
    }
}

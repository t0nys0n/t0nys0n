plugins {
    id("java-test-fixtures")
}
dependencies {
    implementation("org.springframework.boot:spring-boot-starter-oauth2-resource-server")
    testImplementation("com.squareup.okhttp3:mockwebserver")
    testImplementation("com.squareup.okhttp3:okhttp")
    testImplementation("io.projectreactor:reactor-test")
    testFixturesApi("com.nimbusds:nimbus-jose-jwt:9.37.2")
}
package nz.govt.nzta.server.configuration;

import nz.govt.nzta.server.api.ResourcePath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class FiltersConfigs {

    @Bean
    @Order(1)
    public CommonsRequestLoggingFilter filter() {
        CommonsRequestLoggingFilter filter
                = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(false);
        filter.setIncludePayload(false);
        filter.setMaxPayloadLength(10000);
        filter.setIncludeHeaders(true);
        filter.setIncludeClientInfo(true);
        filter.setHeaderPredicate(header -> !header.equalsIgnoreCase("Authorization"));
        return filter;
    }

    @Bean
    public TracingHeadersFilter.Validator tracingHeaderValidator() {
        return new TracingHeadersFilter.Validator();
    }

    @Bean
    public TracingHeadersFilter tracingHeadersFilter(TracingHeadersFilter.Validator validator) {
        return new TracingHeadersFilter(validator);
    }

    @Bean
    public FilterRegistrationBean<TracingHeadersFilter> registerTracingHeadersFilter(@Autowired TracingHeadersFilter filter) {
        FilterRegistrationBean<TracingHeadersFilter> registrationBean
                = new FilterRegistrationBean<>();

        registrationBean.setFilter(filter);
        registrationBean.addUrlPatterns(ResourcePath.LICENCES);
        registrationBean.addUrlPatterns(ResourcePath.LICENCES_ISSUE_COP);
        registrationBean.addUrlPatterns(ResourcePath.VEHICLES_ALL);
        registrationBean.addUrlPatterns(ResourcePath.PREFERENCES_VEHICLES);
        registrationBean.setOrder(2);

        return registrationBean;
    }
}

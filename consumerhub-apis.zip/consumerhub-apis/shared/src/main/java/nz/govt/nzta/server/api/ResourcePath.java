package nz.govt.nzta.server.api;

public class ResourcePath {

    public static final String PLATE_NUMBER = "/{plateNumber}";
    
    public static final String LICENCES = "/licences";

    public static final String LICENCES_ISSUE_COP = LICENCES + "/issueCoP";

    public static final String VEHICLES = "/vehicles";

    public static final String VEHICLE = VEHICLES + PLATE_NUMBER;

    public static final String VEHICLE_SPECIFICATIONS = VEHICLE + "/specifications";

    public static final String VEHICLES_ALL = VEHICLES + "/*";

    public static final String PREFERENCES = "/preferences";

    public static final String PREFERENCES_VEHICLES = PREFERENCES + VEHICLES;

}

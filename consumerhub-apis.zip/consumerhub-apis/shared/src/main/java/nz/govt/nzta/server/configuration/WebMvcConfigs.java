package nz.govt.nzta.server.configuration;

import nz.govt.nzta.server.api.ResourcePath;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfigs implements WebMvcConfigurer {

    @Override
    public void addInterceptors(final InterceptorRegistry registry) {
        registry.addInterceptor(new DriverIdClaimInterceptor())
                .addPathPatterns(ResourcePath.LICENCES)
                .addPathPatterns(ResourcePath.LICENCES_ISSUE_COP)
                .addPathPatterns(ResourcePath.PREFERENCES_VEHICLES);
    }
}

package nz.govt.nzta.server.configuration;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Optional;

@Slf4j
public class DriverIdClaimInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        Jwt principal = ((Jwt) SecurityContextHolder.getContext()
                                                    .getAuthentication()
                                                    .getPrincipal());
        extract(principal).ifPresent((claim) -> request.setAttribute("driverId", claim));
        return true;
    }

    public Optional<String> extract(Jwt principal) {
        String claim = null;
        try {
            claim = principal.getClaim("accountNumber");
        } catch(Exception e) {
            log.error("malformed claim value found in token, {}", e.getMessage());
        }
        return Optional.ofNullable(claim);
    }
}

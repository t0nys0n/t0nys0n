package nz.govt.nzta.objectmapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@UtilityClass
public class ObjectMapperUtils {

    private static final String JSON_PROCESSING_ERROR = "JSON Processing Error.";

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> List<T> readValueForList(String jsonString, Class<T> elementClass) {
        try {
            CollectionType listType = objectMapper.getTypeFactory()
                                                  .constructCollectionType(ArrayList.class, elementClass);
            return objectMapper.readValue(jsonString, listType);
        } catch (JsonProcessingException e) {
            log.error(JSON_PROCESSING_ERROR);

            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, JSON_PROCESSING_ERROR);
        }
    }

    public static String writeValueAsString(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error(JSON_PROCESSING_ERROR);

            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, JSON_PROCESSING_ERROR);
        }
    }
}

package nz.govt.nzta;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@Configuration
public class ValidationMessagesConfigs {

    @Value("validation-messages")
    private String[] baseNames;

    @Bean
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.addBasenames(baseNames);
        return messageSource;
    }

    @Bean
    public LocalValidatorFactoryBean validatorWithParameterNameResolver() {
        LocalValidatorFactoryBean factoryBean = new LocalValidatorFactoryBean();
        factoryBean.setParameterNameDiscoverer(new DefaultParameterNameDiscoverer());
        factoryBean.setValidationMessageSource(messageSource());
        return factoryBean;
    }
}

package nz.govt.nzta.clients;

import org.springframework.http.HttpStatus;

public class ApiClient4xxException extends RuntimeException {

    private final HttpStatus status;

    public ApiClient4xxException(HttpStatus status, String errorBody) {
        super(errorBody);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return this.status;
    }
}

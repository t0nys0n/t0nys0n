package nz.govt.nzta.server.configuration;

import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import jakarta.validation.constraints.NotNull;
import nz.govt.nzta.server.security.AadJwtGrantedAuthoritiesConverter;
import nz.govt.nzta.server.security.AlwaysPassJWSVerifierFactory;
import nz.govt.nzta.server.security.BlankJWSKeySelector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity()
public class OAuthResourceServerConfigs {

    public static final String[] ALLOWED_ROLES = {"VerifiedUser", "DLVerified"};

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.formLogin(AbstractHttpConfigurer::disable)
            .httpBasic(AbstractHttpConfigurer::disable)
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sessionManagement -> {
                sessionManagement.disable();
                sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
            })
            .authorizeHttpRequests(authz -> authz.requestMatchers("/actuator/**")
                                                 .permitAll()
                                                 .requestMatchers("/v3/api-docs/**")
                                                 .permitAll()
                                                 .requestMatchers("/swagger-ui/**")
                                                 .permitAll()
                                                 .anyRequest()
                                                 .hasAnyRole(ALLOWED_ROLES))
            .headers(configurer -> configurer.contentSecurityPolicy(policyConfigurer -> policyConfigurer.policyDirectives("frame-ancestors 'none'; upgrade-insecure-requests;")))
            .oauth2ResourceServer(configurer -> configurer.jwt(jwtConfigurer -> jwtConfigurer.jwtAuthenticationConverter(jwtAuthenticationConverter())));
        return http.build();
    }

    private Converter<Jwt, AbstractAuthenticationToken> jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(new AadJwtGrantedAuthoritiesConverter());
        return converter;
    }

    @Bean
    public JwtDecoder nimbusJwtDecoder(@NotNull DefaultJWTProcessor<SecurityContext> defaultJWTProcessor) {
        return new NimbusJwtDecoder(defaultJWTProcessor);
    }

    @Bean
    public DefaultJWTProcessor<SecurityContext> defaultJWTProcessor(@NotNull AlwaysPassJWSVerifierFactory alwaysPassJwsVerifierFactory, @NotNull BlankJWSKeySelector blankJwsKeySelector) {
        DefaultJWTProcessor<SecurityContext> defaultJWTProcessor = new DefaultJWTProcessor<>();
        defaultJWTProcessor.setJWSKeySelector(blankJwsKeySelector);
        defaultJWTProcessor.setJWSVerifierFactory(alwaysPassJwsVerifierFactory);
        return defaultJWTProcessor;
    }

    @Bean
    public AlwaysPassJWSVerifierFactory jwsVerifierFactory() {
        return new AlwaysPassJWSVerifierFactory();
    }

    @Bean
    public BlankJWSKeySelector jwsKeySelector() {
        return new BlankJWSKeySelector();
    }
}

package nz.govt.nzta.clients.api;

import io.opentelemetry.javaagent.shaded.io.opentelemetry.api.trace.Span;
import nz.govt.nzta.clients.ApiClient4xxException;
import nz.govt.nzta.DateFormats;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Date;

/**
 * R is response type Q is query type
 */
public interface ApiGet<R, Q> {

    DateFormat dateFormat = createDefaultDateFormat();
    DateTimeFormatter offsetDateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

    static DateFormat createDefaultDateFormat() {
        return DateFormats.rfc3339();
    }

    R get(Q request) throws ApiClient4xxException;

    /**
     * Format now()
     *
     * @return
     */
    default String getCurrentTimestamp() {
        return parameterToString(LocalDate.now());
    }

    /**
     * Get trace from Span.current()
     *
     * @return trace id
     */
    default String getRequestIdentifier() {
        return Span.current().getSpanContext().getTraceId();
    }

    /**
     * Format the given parameter object into string.
     *
     * @param param the object to convert
     * @return String the parameter represented as a String
     */
    default String parameterToString(Object param) {
        if (param == null) {
            return "";
        } else if (param instanceof Date date) {
            return formatDate(date);
        } else if (param instanceof OffsetDateTime offsetDateTime) {
            return formatOffsetDateTime(offsetDateTime);
        } else if (param instanceof Collection<?> objects) {
            StringBuilder b = new StringBuilder();
            for (Object o : objects) {
                if (b.length() > 0) {
                    b.append(",");
                }
                b.append(o);
            }
            return b.toString();
        } else {
            return String.valueOf(param);
        }
    }

    /**
     * Format the given Date object into string.
     */
    default String formatDate(Date date) {
        return dateFormat.format(date);
    }

    /**
     * Format the given {@code OffsetDateTime} object into string.
     *
     * @param offsetDateTime {@code OffsetDateTime}
     * @return {@code OffsetDateTime} in string format
     */
    default String formatOffsetDateTime(OffsetDateTime offsetDateTime) {
        return offsetDateTimeFormatter.format(offsetDateTime);
    }
}

package nz.govt.nzta;


import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

import java.util.Set;

public class ReturnValueConstraintViolationException extends ConstraintViolationException {
    public ReturnValueConstraintViolationException(String message, Set<? extends ConstraintViolation<?>> constraintViolations) {
        super(message, constraintViolations);
    }
}

package nz.govt.nzta.clients;

import io.netty.handler.ssl.SslContext;
import lombok.RequiredArgsConstructor;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.endpoint.WebClientReactiveClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
@RequiredArgsConstructor
public class OAuthFilter {

    private final ReactiveClientRegistrationRepository clientRegistrationRepository;
    private final ReactiveOAuth2AuthorizedClientService authorizedClientService;

    public Builder buildFor(String clientRegistrationId) {
        return new Builder(clientRegistrationId, this);
    }

    private ServerOAuth2AuthorizedClientExchangeFilterFunction create(String clientRegistrationId, WebClient webClient) {
        var authorizedClientProvider = createAuthorizedClientProvider(webClient);
        var authorizedClientManager = createAuthorizedClientManager(authorizedClientProvider);

        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(authorizedClientManager);
        oauth.setDefaultClientRegistrationId(clientRegistrationId);
        return oauth;
    }

    private ReactiveOAuth2AuthorizedClientProvider createAuthorizedClientProvider(WebClient webClient) {
        WebClientReactiveClientCredentialsTokenResponseClient client = new WebClientReactiveClientCredentialsTokenResponseClient();
        client.setWebClient(webClient);
        return ReactiveOAuth2AuthorizedClientProviderBuilder.builder()
                                                            .clientCredentials(c -> c.accessTokenResponseClient(client))
                                                            .build();
    }

    private AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager createAuthorizedClientManager(ReactiveOAuth2AuthorizedClientProvider authorizedClientProvider) {
        var authorizedClientManager = new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrationRepository, authorizedClientService);
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);
        return authorizedClientManager;
    }

    public static class Builder {

        final OAuthFilter oAuthFilter;
        final SslWebClient.Builder webClientBuilder = SslWebClient.builder();
        final String clientRegistrationId;

        private Builder(String clientRegistrationId, final OAuthFilter oAuthFilter) {
            this.clientRegistrationId = clientRegistrationId;
            this.oAuthFilter = oAuthFilter;
        }

        public Builder ssl(SslContext sslContext) {
            webClientBuilder.ssl(sslContext);
            return this;
        }

        public ServerOAuth2AuthorizedClientExchangeFilterFunction build() {
            WebClient webClient = webClientBuilder.build();
            return oAuthFilter.create(clientRegistrationId, webClient);
        }
    }

}

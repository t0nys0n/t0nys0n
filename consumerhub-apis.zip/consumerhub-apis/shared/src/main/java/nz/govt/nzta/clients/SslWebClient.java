package nz.govt.nzta.clients;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.ssl.SslContext;
import jakarta.validation.constraints.NotNull;
import lombok.experimental.UtilityClass;
import nz.govt.nzta.DateFormats;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.util.Assert;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

import java.text.DateFormat;

@UtilityClass
public class SslWebClient {

    /**
     * Build with defaults
     *
     * @return
     */
    public static Builder builder() {
        return invokeBuilder(false);
    }

    public static Builder builderNoErrorHandler() {
        return invokeBuilder(true);
    }

    public static Builder invokeBuilder(boolean ignoreErrorHandler) {
        DateFormat dateFormat = getDefaultDateFormat();
        ObjectMapper objectMapper = buildDefaultObjectMapper(dateFormat);
        int bufferSize = getDefaultBufferSize();
        return new Builder(objectMapper, bufferSize, ignoreErrorHandler);
    }

    public static DateFormat getDefaultDateFormat() {
        return DateFormats.rfc3339();
    }

    public static ObjectMapper buildDefaultObjectMapper(@NotNull DateFormat dateFormat) {
        Assert.notNull(dateFormat, "DateFormat is marked not-null but is null");
        ObjectMapper mapper = new ObjectMapper();
        mapper.setDateFormat(dateFormat);
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }

    public static int getDefaultBufferSize() {
        return 10 * 1024 * 1024; // 10MB
    }

    public static class Builder {

        WebClient.Builder webClientBuilder;

        private Builder(ObjectMapper objectMapper, int bufferSize, boolean ignoreErrorHandler) {

            if (ignoreErrorHandler) {
                this.webClientBuilder = buildWebClientBuilder(objectMapper, bufferSize);
            } else {
                this.webClientBuilder = buildWebClientBuilder(objectMapper, bufferSize).filter(buildErrorHandler());
            }
        }

        public Builder ssl(SslContext sslContext) {
            Assert.notNull(sslContext, "sslContext cannot be null");
            webClientBuilder.clientConnector(buildSslConnector(sslContext));
            return this;
        }

        public Builder oAuth(ServerOAuth2AuthorizedClientExchangeFilterFunction oAuthClientFilter) {
            Assert.notNull(oAuthClientFilter, "oAuth filter cannot be null");
            webClientBuilder.filter(oAuthClientFilter);
            return this;
        }

        public Builder filter(ExchangeFilterFunction filter) {
            webClientBuilder.filter(filter);
            return this;
        }

        public Builder baseUrl(String baseUrl) {
            webClientBuilder.baseUrl(baseUrl);
            return this;
        }

        public WebClient build() {
            return webClientBuilder.build();
        }

        private WebClient.Builder buildWebClientBuilder(final ObjectMapper mapper, int bufferSize) {
            ExchangeStrategies strategies = ExchangeStrategies
                    .builder()
                    .codecs(clientDefaultCodecsConfigurer -> {
                        clientDefaultCodecsConfigurer.defaultCodecs()
                                                     .jackson2JsonEncoder(new Jackson2JsonEncoder(mapper, MediaType.APPLICATION_JSON));
                        clientDefaultCodecsConfigurer.defaultCodecs()
                                                     .jackson2JsonDecoder(new Jackson2JsonDecoder(mapper, MediaType.APPLICATION_JSON));
                        clientDefaultCodecsConfigurer.defaultCodecs()
                                                     .maxInMemorySize(bufferSize);
                    })
                    .build();
            return WebClient.builder()
                            .exchangeStrategies(strategies);
        }

        private ReactorClientHttpConnector buildSslConnector(SslContext sslContext) {
            HttpClient httpClient = HttpClient
                    .create() //.proxyWithSystemProperties()
                    .secure(spec -> spec.sslContext(sslContext)) //.proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP).host("10.49.4.70").port(9090))
                    .wiretap("reactor.netty.http.client.HttpClient",
                            LogLevel.DEBUG,
                            AdvancedByteBufFormat.TEXTUAL);
            return new ReactorClientHttpConnector(httpClient);
        }

        private ExchangeFilterFunction buildErrorHandler() {
            return ExchangeFilterFunction.ofResponseProcessor(response -> {
                if (response.statusCode()
                            .is5xxServerError()) {
                    HttpStatus httpStatus = toHttpStatus(response.statusCode());
                    return mapToString(response).flatMap(
                            errorBody -> Mono.error(new ApiClient5xxException(httpStatus, errorBody)));
                } else if (response.statusCode()
                                   .is4xxClientError()) {
                    HttpStatus httpStatus = toHttpStatus(response.statusCode());
                    return mapToString(response).flatMap(
                            errorBody -> Mono.error(new ApiClient4xxException(httpStatus, errorBody)));
                } else {
                    return Mono.just(response);
                }
            });
        }

        private Mono<String> mapToString(ClientResponse response) {
            HttpStatus httpStatus = toHttpStatus(response.statusCode());
            return response.bodyToMono(String.class)
                           .defaultIfEmpty(httpStatus.getReasonPhrase())
                           .map(errorBody ->
                                   switch (httpStatus) {
                                       case TOO_MANY_REQUESTS -> httpStatus.name()
                                                                           .concat("\"Too Many Request.\"");
                                       default -> httpStatus.name()
                                                            .concat(errorBody);
                                   }
                           );
        }

        private HttpStatus toHttpStatus(HttpStatusCode httpStatusCode) {
            return (HttpStatus) HttpStatusCode.valueOf(httpStatusCode.value());
        }
    }

}

package nz.govt.nzta.server;

import io.netty.channel.ConnectTimeoutException;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.clients.ApiClient4xxException;
import nz.govt.nzta.clients.ApiClient5xxException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.IOException;

import static org.springframework.http.HttpStatus.BAD_GATEWAY;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@ControllerAdvice
@Slf4j
public class RestExceptionHandler {

    @ExceptionHandler(ConstraintViolationException.class)
    public void handleConstraintViolation(
            ConstraintViolationException ex,
            HttpServletResponse response) throws IOException {
        log.error(ex.getMessage());
        response.sendError(BAD_REQUEST.value(), ex.getMessage());
    }

    @ExceptionHandler(ApiClient4xxException.class)
    public void handleClientException(
            ApiClient4xxException ex,
            HttpServletResponse response) throws IOException {
        log.error(ex.getMessage());
        response.sendError(ex.getStatus()
                             .value(), ex.getMessage());
    }

    @ExceptionHandler(ApiClient5xxException.class)
    public void handleClientException(
            ApiClient5xxException ex,
            HttpServletResponse response) throws IOException {
        log.error(ex.getMessage());
        response.sendError(ex.getStatus()
                             .value(), "Upstream service returned 5xx error");
    }

    @ExceptionHandler(ConnectTimeoutException.class)
    public void handleClientException(
            ConnectTimeoutException ex,
            HttpServletResponse response) throws IOException {
        log.error(ex.getMessage());
        response.sendError(BAD_GATEWAY.value(), ex.getMessage());
    }

}

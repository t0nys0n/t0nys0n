package nz.govt.nzta.clients;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.experimental.UtilityClass;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Base64;

@UtilityClass
public class SslUtils {


    public static SslContext initSslContextFromPfx(String base64Pfx, String keyStorePassword)
            throws UnrecoverableKeyException, CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException {
        KeyManagerFactory keyManagerFactory = getKeyManagerFactory(base64Pfx, keyStorePassword);
        TrustManagerFactory trustManagerFactory = getTrustManagerFactory();

        return SslContextBuilder
                .forClient()
                .trustManager(trustManagerFactory)
                .keyManager(keyManagerFactory)
                .build();
    }

    public static KeyManagerFactory getKeyManagerFactory(String base64SecretValue,
                                                         String keyStorePassword)
            throws KeyStoreException, CertificateException, IOException, NoSuchAlgorithmException, UnrecoverableKeyException {
        byte[] src = Base64.getDecoder().decode(base64SecretValue);
        KeyStore keystore = KeyStore.getInstance("PKCS12");
        keystore.load(new ByteArrayInputStream(src), keyStorePassword.toCharArray());

        KeyManagerFactory keyManagerFactory =
                KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keystore, keyStorePassword.toCharArray());
        return keyManagerFactory;
    }

    public static TrustManagerFactory getTrustManagerFactory() {
        return InsecureTrustManagerFactory.INSTANCE;
    }
}

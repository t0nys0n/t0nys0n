package nz.govt.nzta.clients;

import org.springframework.http.HttpStatus;

public class ApiClient5xxException extends Exception {

    private final HttpStatus status;

    public ApiClient5xxException(HttpStatus status, String errorBody) {
        super(errorBody);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return this.status;
    }
}

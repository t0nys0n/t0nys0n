package nz.govt.nzta.server.security;

import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.SecurityContext;

import java.security.Key;
import java.util.List;

public class BlankJWSKeySelector implements JWSKeySelector<SecurityContext> {

    @Override
    public List<? extends Key> selectJWSKeys(JWSHeader header, SecurityContext context) {
        return List.of(new Key() {
            @Override
            public String getAlgorithm() {
                return "";
            }

            @Override
            public String getFormat() {
                return "";
            }

            @Override
            public byte[] getEncoded() {
                return new byte[0];
            }
        });
    }
}

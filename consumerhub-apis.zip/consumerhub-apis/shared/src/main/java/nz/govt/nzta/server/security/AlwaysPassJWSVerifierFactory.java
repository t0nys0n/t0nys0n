package nz.govt.nzta.server.security;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.jca.JCAContext;
import com.nimbusds.jose.proc.JWSVerifierFactory;
import com.nimbusds.jose.util.Base64URL;
import jakarta.validation.constraints.NotNull;

import java.security.Key;
import java.util.Collections;
import java.util.Set;

public class AlwaysPassJWSVerifierFactory implements JWSVerifierFactory {

    @Override
    public JCAContext getJCAContext() {
        return null;
    }

    @Override
    public Set<JWSAlgorithm> supportedJWSAlgorithms() {
        return Collections.emptySet();
    }

    @Override
    public JWSVerifier createJWSVerifier(JWSHeader header, Key key) {
        return createAlwaysPassingJWSVerifier();
    }

    @NotNull
    private JWSVerifier createAlwaysPassingJWSVerifier() {
        return new JWSVerifier() {
            @Override
            public boolean verify(JWSHeader header, byte[] signingInput, Base64URL signature) {
                return true;
            }

            @Override
            public Set<JWSAlgorithm> supportedJWSAlgorithms() {
                return Collections.emptySet();
            }

            @Override
            public JCAContext getJCAContext() {
                return null;
            }
        };
    }
}

package nz.govt.nzta.clients.configuration;

import nz.govt.nzta.clients.OAuthClientProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.*;
import org.springframework.security.oauth2.core.AuthorizationGrantType;

import java.util.LinkedList;
import java.util.List;

@Configuration
public class OAuthClientsConfigs {

    @Bean
    public ReactiveClientRegistrationRepository inMemoryClientsRegistrationRepository(List<OAuthClientProperties> oAuthClientRegistrations) {
        var registrations = new LinkedList<ClientRegistration>();
        oAuthClientRegistrations.stream()
                                .forEach(properties -> registrations.add(buildClientRegistration(properties)));
        return new InMemoryReactiveClientRegistrationRepository(registrations);
    }

    @Bean
    public ReactiveOAuth2AuthorizedClientService inMemoryAuthorizedClientService(ReactiveClientRegistrationRepository clientRegistrationRepository) {
        return new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrationRepository);
    }

    public ClientRegistration buildClientRegistration(OAuthClientProperties properties) {
        return ClientRegistration.withRegistrationId(properties.getClientName())
                                 .tokenUri(properties.getTokenUri())
                                 .clientId(properties.getClientId())
                                 .clientSecret(properties.getClientSecret())
                                 .scope(properties.getScope())
                                 .authorizationGrantType(new AuthorizationGrantType(properties.getAuthorizationGrantType()))
                                 .build();
    }

}

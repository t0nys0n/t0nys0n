package nz.govt.nzta;


import lombok.experimental.UtilityClass;
import nz.govt.nzta.DateFormatRFC3339;

import java.time.format.DateTimeFormatter;
import java.util.Locale;

@UtilityClass
public class DateFormats {

    public static final String MEDIUM_DATE_PATTERN = "dd-MM-yyyy";
    public static final DateTimeFormatter MEDIUM_DATE_FORMATTER = DateTimeFormatter.ofPattern(MEDIUM_DATE_PATTERN,
            Locale.ENGLISH);

    public static DateFormatRFC3339 rfc3339() {
        return new DateFormatRFC3339();
    }
}
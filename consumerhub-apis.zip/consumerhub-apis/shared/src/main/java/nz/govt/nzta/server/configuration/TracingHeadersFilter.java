package nz.govt.nzta.server.configuration;

import io.opentelemetry.javaagent.shaded.io.opentelemetry.api.baggage.Baggage;
import io.opentelemetry.javaagent.shaded.io.opentelemetry.api.trace.Span;
import io.opentelemetry.javaagent.shaded.io.opentelemetry.context.Context;
import io.opentelemetry.javaagent.shaded.io.opentelemetry.context.Scope;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.UUID;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Objects;

@Slf4j
@RequiredArgsConstructor
public class TracingHeadersFilter extends OncePerRequestFilter {

    public static final String CORRELATION_HEADER = "x-wk-correlation-id";

    public static final String CORRELATION_ATTRIBUTE = "enduser.id";

    private final Validator validator;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        doFilterWithoutTraceBaggage(request, response, filterChain);
    }

    protected void doFilterWithoutTraceBaggage(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        var headerValue = requireValidElse(request.getHeader(CORRELATION_HEADER));
        setTracingAttributeUserId(headerValue);
        filterChain.doFilter(request, response);
    }

    /**
     * Baggage is used to propagate user-specific context to downstream
     * Key=Value multi pairs can be assigned with comma delimiter
     * Agents must also propagate baggage header within the received http request
     */
    protected void doFilterWithTraceBaggage(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        var headerValue = requireValidElse(request.getHeader(CORRELATION_HEADER));
        var userIdBaggage = Baggage.current()
                                   .toBuilder()
                                   .put(CORRELATION_ATTRIBUTE, headerValue)
                                   .build();

        try (Scope ignored = Context.current()
                                    .with(userIdBaggage)
                                    .makeCurrent()) {
            setTracingAttributeUserId(headerValue);
            filterChain.doFilter(request, response);
        }
    }

    public void setTracingAttributeUserId(String headerValue) {
        Span.current()
            .setAttribute(CORRELATION_ATTRIBUTE, headerValue);
    }

    public String requireValidElse(String headerValue) {
        try {
            return validator.validate(headerValue);
        } catch (ConstraintViolationException cve) {
            log.error(cve.getMessage());
        }
        return extractUserIdFromToken();
    }

    public String extractUserIdFromToken() {
        try {
            String claim = ((Jwt) SecurityContextHolder.getContext()
                                                       .getAuthentication()
                                                       .getPrincipal()).getClaim("sub");
            return Objects.requireNonNull(claim);
        } catch (Exception e) {
            log.error("Claim {} not found in token, {}", "sub", e.getMessage());
            throw e;
        }
    }

    @Validated
    public static class Validator {
        public String validate(@NotBlank @UUID String correlationHeader) {
            return correlationHeader;
        }
    }
}

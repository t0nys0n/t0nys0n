package nz.govt.nzta.clients;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
public class OAuthClientProperties {
    private @NotBlank String clientId;
    private @NotBlank String clientSecret;
    private @NotBlank String scope;
    private @NotBlank String authorizationGrantType;
    private @NotBlank String clientName;
    private @NotBlank String tokenUri;
}

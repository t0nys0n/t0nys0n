package nz.govt.nzta;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.ZoneId;

@Configuration
public class ClockConfigs {
    public static final ZoneId NST = ZoneId.of("Pacific/Auckland");

    @Bean
    public Clock clock() {
        return Clock.system(NST);
    }
}

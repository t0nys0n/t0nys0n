package nz.govt.nzta;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

public class SignedJWTBuilder {

    public static final String ROLES_CLAIM_NAME = "roles";
    private static final String[] ALLOWED_ROLES= {"VerifiedUser"};

    private final RSAKey key;

    {
        try {
            key = new RSAKeyGenerator(2048).keyUse(KeyUse.SIGNATURE) // indicate the intended use of the key (optional)
                                                   .keyID(UUID.randomUUID().toString()) // give the key a unique ID (optional)
                                                   .issueTime(new Date()) // issued-at timestamp (optional)
                                                   .generate();
        } catch (JOSEException e) {
            throw new RuntimeException(e);
        }
    }

    private final JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256).type(JOSEObjectType.JWT)
                                                                              .keyID(key.getKeyID())
                                                                              .build();
    private JWTClaimsSet.Builder payload = new JWTClaimsSet.Builder().issuer("https://wkiamdev")
                                                                     .audience("c91c09ff-e89b-460f-858c-8e86d9883113")
                                                                     .subject("7fab0651-583b-4148-88e8-f1b6d3276288")
                                                                     .expirationTime(Date.from(Instant.now().plusSeconds(10)))
                                                                     .claim(ROLES_CLAIM_NAME, ALLOWED_ROLES);

    public SignedJWTBuilder() {
        claim("sub", "7fab0651-583b-4148-88e8-f1b6d3276288");
    }

    public SignedJWTBuilder(JWTClaimsSet.Builder claims) {
        payload = new JWTClaimsSet.Builder();
        payload.claim(ROLES_CLAIM_NAME, ALLOWED_ROLES);
        payload.subject("7fab0651-583b-4148-88e8-f1b6d3276288");
        claims.getClaims().forEach((k,v) -> payload.claim(k, v));
    }

    public SignedJWTBuilder driverId(final String value) {
        return claim("accountNumber", value);
    }

    public SignedJWTBuilder claim(final String name, final Object value) {
        payload.claim(name, value);
        return this;
    }

    public String build() {
        var signedJWT = new SignedJWT(header, payload.build());
        try {
            signedJWT.sign(new RSASSASigner(key.toPrivateKey()));
            return signedJWT.serialize();
        } catch (JOSEException e) {
            throw new RuntimeException(e);
        }
    }

}

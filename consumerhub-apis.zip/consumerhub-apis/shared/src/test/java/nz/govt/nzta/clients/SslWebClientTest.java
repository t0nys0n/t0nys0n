package nz.govt.nzta.clients;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class SslWebClientTest {

    private static MockWebServer mockWebServer;

    private static WebClient webClient;

    @BeforeAll
    static void setUp() {
        mockWebServer = new MockWebServer();
        webClient = SslWebClient.builder().webClientBuilder.baseUrl(mockWebServer.url("/").toString()).build();
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockWebServer.close();
    }

    @Test
    void shouldHaveWebclient() {
        assertNotNull(webClient);
    }

    @Test
    void shouldNotChangeMessageOnOtherError() {
        var errorMessage = "\"Not Found.\"";

        mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NOT_FOUND.value())
                .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .setBody(errorMessage)
        );

        Mono<String> result = webClient.get()
                .uri("/")
                .retrieve()
                .bodyToMono(String.class);

        StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof ApiClient4xxException &&
                        throwable.getMessage().equals("NOT_FOUND".concat(errorMessage)))
                .verify();
    }

    @Test
    void shouldChangeMessageOnTooManyRequestsError() {
        var errorMessage = """
                <html>
                        <head>
                            <title>API throttle limit exceeded</title>
                        </head>
                        <body>
                                API throttle limit exceeded on vt.services.nzta.govt.nz.  Requests in the last 60 seconds exceed your assign request limit.  For Agent ID:eba9465f-****-****-****-541238882f59, Agent IP Address:10.48.56.135, Limit:1750 Requests:1831  Application:rest_api
                        </body>
                </html>
                """;

        mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.TOO_MANY_REQUESTS.value())
                .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .setBody(errorMessage)
        );

        Mono<String> result = webClient.get()
                .uri("/")
                .retrieve()
                .bodyToMono(String.class);

        StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof ApiClient4xxException &&
                        throwable.getMessage().equals("TOO_MANY_REQUESTS\"Too Many Request.\""))
                .verify();
    }
}
package nz.govt.nzta.server.configuration;

import jakarta.servlet.http.HttpServletRequest;
import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.mapstruct.Named;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class DriverIdClaimInterceptorTest {

    @AfterAll
    static void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    @Named("When valid claim exists, return its value")
    void valid() {
        DriverIdClaimInterceptor interceptor = new DriverIdClaimInterceptor();
        Jwt principal = Jwt
                .withTokenValue("eyJh")
                .header("type", "JWT")
                .claim("accountNumber", "15391158")
                .build();
        Optional<String> value = interceptor.extract(principal);
        assertSame("15391158", value.get());
    }

    @Test
    @Named("When claim doesn't exist, return empty value")
    void empty() {
        DriverIdClaimInterceptor interceptor = new DriverIdClaimInterceptor();
        Jwt principal = Jwt
                .withTokenValue("eyJh")
                .header("type", "JWT")
                .claim("xyz", List.of("AA123456"))
                .build();
        Optional<String> value = interceptor.extract(principal);
        assertTrue(value.isEmpty());
    }

    @Test
    @Named("When valid claim exists but value is malformed, return empty value")
    void malformed() {
        Jwt principal = Jwt
                .withTokenValue("eyJh")
                .header("type", "JWT")
                .claim("accountNumber", Arrays.array((Object) null))
                .build();
        DriverIdClaimInterceptor interceptor = new DriverIdClaimInterceptor();
        Optional<String> value = interceptor.extract(principal);
        assertTrue(value.isEmpty());
    }

    @Test
    @Named("When valid claim exists, set its value as http request attribute")
    void mustSetValidExtractedClaimAsHttpRequestAttribute() {
        String claimValue = "15391158";
        String requestAttributeName = "driverId";
        Jwt principal = Jwt
                .withTokenValue("eyJh")
                .header("type", "JWT")
                .claim("accountNumber", claimValue)
                .build();
        SecurityContext context = Mockito.mock(SecurityContext.class);
        Authentication authentication = Mockito.mock(Authentication.class);

        Mockito.when(authentication.getPrincipal())
                .thenReturn(principal);
        Mockito.when(context.getAuthentication())
                .thenReturn(authentication);

        SecurityContextHolder.setContext(context);
        DriverIdClaimInterceptor interceptor = new DriverIdClaimInterceptor();
        HttpServletRequest request = new MockHttpServletRequest();

        interceptor.preHandle(request, null, null);

        Object requestAttributeValue = request.getAttribute(requestAttributeName);
        assertNotNull(requestAttributeValue);
        assertSame(claimValue, requestAttributeValue);
    }
}

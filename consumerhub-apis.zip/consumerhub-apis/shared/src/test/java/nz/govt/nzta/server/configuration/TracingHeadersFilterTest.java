package nz.govt.nzta.server.configuration;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.mockito.ArgumentCaptor;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.*;

class TracingHeadersFilterTest {

    private final HttpServletRequest request = mock(HttpServletRequest.class);

    private final HttpServletResponse response = mock(HttpServletResponse.class);

    private final FilterChain filterChain = mock(FilterChain.class);

    private final TracingHeadersFilter.Validator validator = new TracingHeadersFilter.Validator();

    private static Stream<Arguments> mustValidateHeaderValueIsNotBlank() {
        return Stream.of(
                Arguments.of(null, 1, Set.of("must not be blank")),
                Arguments.of(" ", 2, Set.of("must be a valid UUID", "must not be blank")),
                Arguments.of("00-39041612baf14e769ee5ae91b39a75ff-58c08397197c4397-00", 1, Set.of("must be a valid UUID")),
                Arguments.of("AA1234567", 1, Set.of("must be a valid UUID")),
                Arguments.of("6adca39f-8415-44eb-9fb7-f9dc8eb2e2df", 0, Set.of())
        );
    }

    @Test
    void mustDoFilterWithoutTracingBaggage() throws ServletException, IOException {
        var filter = spy(new TracingHeadersFilter(validator));
        when(request.getHeader(TracingHeadersFilter.CORRELATION_HEADER)).thenReturn("123456");

        filter.doFilterInternal(request, response, filterChain);

        verify(filter).doFilterWithoutTraceBaggage(request, response, filterChain);
    }

    @Test
    void mustExtractUserIdFromRequestHeaderAndUpdateTracingAttribute() throws ServletException, IOException {
        var filter = spy(new TracingHeadersFilter(validator));
        var headerValueCaptor = ArgumentCaptor.forClass(String.class);
        when(request.getHeader(TracingHeadersFilter.CORRELATION_HEADER)).thenReturn("123456");

        filter.doFilterInternal(request, response, filterChain);

        verify(filter).requireValidElse(headerValueCaptor.capture());
        assertEquals("123456", headerValueCaptor.getValue());
        verify(filter).setTracingAttributeUserId("123456");
    }

    @Test
    void mustExtractUserIdFromTokenWhenNoRequestHeaderAndUpdateTracingAttribute() throws ServletException, IOException {
        var validator = mock(TracingHeadersFilter.Validator.class);
        var filter = spy(new TracingHeadersFilter(validator));
        doReturn("AA123456")
                .when(filter)
                .extractUserIdFromToken();
        doThrow(new ConstraintViolationException(Set.of()))
                .when(validator)
                .validate(any());

        filter.doFilterInternal(request, response, filterChain);

        verify(filter).extractUserIdFromToken();
        verify(filter).setTracingAttributeUserId("AA123456");
    }

    @ParameterizedTest
    @MethodSource
    void mustValidateHeaderValueIsNotBlank(String headerValue, int expectedNumOfViolations, Set<String> expectedViolationMessage) throws NoSuchMethodException {
        var factory = Validation.buildDefaultValidatorFactory();
        var executableValidator = factory.getValidator()
                                         .forExecutables();

        var method = validator.getClass()
                              .getMethod("validate", String.class);
        Object[] parameters = {headerValue};
        var violations = executableValidator.validateParameters(validator, method, parameters);

        assertSame(expectedNumOfViolations, violations.size());
        assertEquals(expectedViolationMessage, violations.stream()
                                                         .map(v -> v.getMessage())
                                                         .collect(Collectors.toSet()));
    }
}

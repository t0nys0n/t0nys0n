plugins {
    java
    id("org.springframework.boot") version "3.2.2"
    jacoco
    id("com.google.cloud.tools.jib") version "3.4.3"
    id("org.sonarqube") version "4.0.0.2929"
    id("org.openapi.generator") version "7.6.0"
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:2.5.0")
    implementation(project(":shared"))
    implementation(project(":licence"))
    implementation(project(":vehicle"))
    implementation("org.liquibase:liquibase-core")
    testImplementation("org.springframework.boot:spring-boot-devtools")
    runtimeOnly("io.netty:netty-resolver-dns-native-macos:4.1.80.Final:osx-aarch_64")
    testImplementation(testFixtures(project(":shared")))
}

tasks.compileJava {
    dependsOn("genParty")
}

val openApiGenerateOutputDir =  "$buildDir/generated"
val openApiGenerateConfigFile = "$projectDir/src/main/resources/openapi/openapi-configuration.json"

tasks.register<org.openapitools.generator.gradle.plugin.tasks.GenerateTask>("genParty") {

    outputDir.set(openApiGenerateOutputDir)
    configFile.set(openApiGenerateConfigFile)
    generatorName.set("spring")
    library.set("spring-http-interface")
    inputSpec.set("$projectDir/src/main/resources/openapi/party-proc-api/party-proc-api.yaml")
    configOptions.put("apiPackage", "generated.openapi.party.client")
    configOptions.put("modelPackage", "generated.openapi.party.model")
    typeMappings.put("string+date-time", "LocalDateTime")
    importMappings.put("LocalDateTime", "java.time.LocalDateTime")
}

java.sourceSets["main"].java.srcDir("$buildDir/generated/src/main/java")

springBoot {
    buildInfo()
}

/*
Stop creation of -plain.jar by SpringBoot
*/
tasks.jar {
    enabled = false
}

/*
Build layered JAR to utilize multi-stage docker layers
*/
tasks.bootJar {
    layered {
        isEnabled = true
    }
}

tasks.jacocoTestCoverageVerification {
    classDirectories.setFrom(
        files(classDirectories.files.map {
            fileTree(it) {
                exclude("**/generated/**")
            }
        })
    )
    violationRules {
        rule {
            limit {
                counter = "COMPLEXITY"
                value = "COVEREDRATIO"
                minimum = "0.0".toBigDecimal()
            }
        }
    }
}

dependencyLocking {
    lockAllConfigurations()
}

jib {
    container {
        mainClass = "nz.govt.nzta.Application"
    }
}

/*
Sonar task depends on test report
*/
tasks.sonar {
    dependsOn(tasks.jacocoTestReport)
}

sonarqube {
    properties {
        property("sonar.projectKey", "consumerhub-api-vehicle-management")
        property("sonar.organization", "connected-journeys")
        property("sonar.host.url", "https://sonarcloud.io")
        property("sonar.sources", "src/main")
        property("sonar.tests", "src/test")
        property("sonar.java.coveragePlugin", "jacoco")
    }
}

allprojects {
    apply(plugin = "java")
    apply(plugin = "jacoco")

    group = "nz.govt.nzta"
    version = if (version != "unspecified") version else "SNAPSHOT"
    java.sourceCompatibility = JavaVersion.VERSION_17
    java.targetCompatibility = JavaVersion.VERSION_17

    repositories {
        mavenCentral()
    }

    dependencies {
        implementation(platform(org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES))
        implementation(platform("com.azure.spring:spring-cloud-azure-dependencies:5.13.0"))
        implementation(platform("org.testcontainers:testcontainers-bom:1.19.8"))
        implementation("com.microsoft.azure:applicationinsights-runtime-attach:3.5.3")
        implementation("com.microsoft.azure:applicationinsights-agent:3.5.3")
        implementation("com.azure.spring:spring-cloud-azure-starter-keyvault-secrets")
        implementation("org.springframework.boot:spring-boot-starter-web")
        implementation("org.springframework.boot:spring-boot-starter-webflux")
        implementation("org.springframework.boot:spring-boot-starter-validation")
        implementation("org.projectlombok:lombok:1.18.30")
        implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
        implementation("org.springframework.boot:spring-boot-starter-oauth2-client")
        runtimeOnly("com.microsoft.sqlserver:mssql-jdbc")
        annotationProcessor("org.projectlombok:lombok:1.18.30")
        implementation("org.mapstruct:mapstruct:1.5.5.Final")
        annotationProcessor("org.mapstruct:mapstruct-processor:1.5.5.Final")
        implementation("io.swagger.core.v3:swagger-annotations-jakarta:2.2.22")
        testImplementation("org.springframework.boot:spring-boot-starter-test")
        testImplementation("org.springframework.security:spring-security-test")
        testImplementation("org.springframework.boot:spring-boot-testcontainers")
        testImplementation("org.testcontainers:junit-jupiter")
        testImplementation("org.testcontainers:mssqlserver")
    }

    jacoco {
        toolVersion = "0.8.8"
    }

    /*
    Tests are required to run before generating the report
    */
    tasks.jacocoTestReport {
        reports {
            xml.required.set(true)
        }
        dependsOn(tasks.test)
        classDirectories.setFrom(
            files(classDirectories.files.map {
                fileTree(it) {
                    exclude("**/generated/**")
                }
            })
        )
    }

    tasks.test {
        useJUnitPlatform()
        finalizedBy(tasks.jacocoTestReport)
        systemProperty("spring.profiles.active", "test")
    }

    /*
    Some error messages depend on parameter names.
    As of Spring 6.1 (Spring Boot 3.2), parameter names are not deduced from bytecode.
     */
    tasks.withType<JavaCompile>() {
        options.compilerArgs.add("-parameters")
    }
}

subprojects {
    tasks.processTestResources {
        from("$rootDir/src/main/resources/application.yml")
        from("$rootDir/src/test/resources/application-test.yml")
    }
}

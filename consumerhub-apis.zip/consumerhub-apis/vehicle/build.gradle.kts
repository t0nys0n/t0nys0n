plugins {
    id("org.openapi.generator") version "7.6.0"
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-hateoas")
    implementation(project(":shared"))
    testImplementation(testFixtures(project(":shared")))
}

tasks.compileJava {
    dependsOn("generateClientVehicleVss")
}

val openApiGenerateOutputDir =  "$buildDir/generated"
val openApiGenerateConfigFile = "$projectDir/src/main/resources/openapi-configuration.json"

tasks.register<org.openapitools.generator.gradle.plugin.tasks.GenerateTask>("generateClientVehicleVss") {

    outputDir.set(openApiGenerateOutputDir)
    configFile.set(openApiGenerateConfigFile)
    generatorName.set("java")
    library.set("webclient")
    inputSpec.set("$projectDir/src/main/resources/apis-vss-vehicle.json")
    configOptions.put("apiPackage", "org.generated.apis.vss.vehicle.client")
    configOptions.put("modelPackage", "org.generated.apis.vss.vehicle.model")
    typeMappings.put("string+date-time", "LocalDateTime")
    importMappings.put("LocalDateTime", "java.time.LocalDateTime")
}

java.sourceSets["main"].java.srcDir("$buildDir/generated/src/main/java")
package nz.govt.nzta.vss.vehicle;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import nz.govt.nzta.clients.api.ApiGet;
import nz.govt.nzta.clients.OAuthClientProperties;
import nz.govt.nzta.clients.OAuthFilter;
import nz.govt.nzta.clients.SslUtils;
import nz.govt.nzta.clients.SslWebClient;
import org.generated.apis.vss.vehicle.model.NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

@Configuration
@ConditionalOnProperty(prefix = "client.registration.vss-vehicle", name = "enabled", matchIfMissing = false)
public class ApiClientConfiguration {

    @Bean("mutualTrustVss")
    @ConditionalOnProperty(prefix = "client.registration.vss-vehicle", name = "ssl-enabled", havingValue = "true", matchIfMissing = false)
    io.netty.handler.ssl.SslContext mutualTrustVss(@Value("${vss-mtls-cert}") String tlsClientCert) throws UnrecoverableKeyException, CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException {
        return SslUtils.initSslContextFromPfx(tlsClientCert, "");
    }

    @Bean("mutualTrustVss")
    @ConditionalOnProperty(prefix = "client.registration.vss-vehicle", name = "ssl-enabled", havingValue = "false", matchIfMissing = true)
    io.netty.handler.ssl.SslContext sslContextDefault() throws IOException {
        return SslContextBuilder.forClient()
                                .build();
    }

    @Bean("oAuthPropertiesVss")
    @ConfigurationProperties(prefix = "spring.security.oauth2.client.registration.vss-vehicle", ignoreUnknownFields = false)
    @Value("${spring.security.oauth2.client.provider.vss-vehicle.token-uri}")
    OAuthClientProperties oAuthPropertiesVss(String tokenUri) {
        OAuthClientProperties properties = new OAuthClientProperties();
        properties.setTokenUri(tokenUri);
        return properties;
    }

    @Bean("apiPropertiesVss")
    @ConfigurationProperties(prefix = "client.registration.vss-vehicle")
    ApiProperties apiPropertiesVss() {
        return new ApiProperties();
    }

    @Bean("oAuthClientVss")
    WebClient oAuthClientVss(@Qualifier("mutualTrustVss") final SslContext sslContext, @Qualifier("oAuthPropertiesVss") final OAuthClientProperties oAuthClientProperties, OAuthFilter oAuthFilter) {
        var oAuthClientFiler = oAuthFilter.buildFor(oAuthClientProperties.getClientName())
                                          .ssl(sslContext)
                                          .build();
        return SslWebClient.builder()
                           .ssl(sslContext)
                           .oAuth(oAuthClientFiler)
                           .build();
    }

    @Bean
    ApiGet<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience, String> apiGetVehicle(@Qualifier("oAuthClientVss") final WebClient oAuthClientVss, @Qualifier("apiPropertiesVss") final ApiProperties apiProperties) {
        return new ApiGetVehicle(oAuthClientVss, apiProperties);
    }
}

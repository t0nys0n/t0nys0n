package nz.govt.nzta.vss.vehicle;

import lombok.RequiredArgsConstructor;
import nz.govt.nzta.clients.api.ApiGet;
import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.VehicleRepository;

import org.generated.apis.vss.vehicle.model.NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class VehicleRepositoryImp implements VehicleRepository {

    private final ApiGet<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience, String> apiGetVehicle;
    private final ApiGetVehicleMapper mapper;

    @Override
    public Vehicle getVehicle(String plateNumber) {
        var vehicleDetails = fetchVehicleDetails(plateNumber);
        return mapper.map(vehicleDetails);
    }

    private NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience fetchVehicleDetails(String plateNumber) {
        return apiGetVehicle.get(plateNumber);
    }
}

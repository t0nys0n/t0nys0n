package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.Format;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Optional;

@Mapper(componentModel = "spring")
public interface RUCLicenceComplianceMapper {

    default Optional<ComplianceMessage> map(RUCLicence rucLicence) {
        boolean isRoadChargeApplicable = RUCLicence.isRoadChargeApplicable(rucLicence);
        var complianceMessage = isRoadChargeApplicable ? mapComplianceMessage(rucLicence.getEndDistance()) : null;
        return Optional.ofNullable(complianceMessage);
    }

    @Mapping(target = "level", constant = "INFO")
    @Mapping(target = "text", expression = "java(mapText(endDistance))")
    @Mapping(target = "code", constant = "RUC_END_DISTANCE")
    ComplianceMessage mapComplianceMessage(Integer endDistance);

    default String mapText(Integer endDistance) {
        return String.format(Format.KILOMETRES, endDistance);
    }

}

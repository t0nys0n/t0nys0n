package nz.govt.nzta.vehicle;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Value;

@Value
public class BodyStyleResponse {

    @NonNull BodyType value;

    public String getText() {
        return value.getText();
    }

    @AllArgsConstructor
    public enum BodyType {
        NOTSET(""),
        ARTICULATED_TRUCK("Articulated Truck"),
        CAB_CHASSIS("Cab Chassis"),
        CONVERTIBLE("Convertible"),
        FLATDECK_TRUCK("Flatdeck Truck"),
        HATCHBACK("Hatchback"),
        HEAVY_BUS("Heavy Bus"),
        HEAVY_VAN("Heavy Van"),
        MINI_BUS("Mini Bus"),
        LIGHT_VAN("Light Van"),
        MOTORCYCLE("Motorcycle"),
        MOBILE_MACHINE("Mobile Machine"),
        AGRICULTURAL_MACHINE_OTHER("Agricultural Machine Other"),
        OTHER_TRUCK("Other Truck"),
        SELF_PROPELLED_CARAVAN("Self Propelled Caravan"),
        SALOON("Saloon"),
        SPORTS_CAR("Sports Car"),
        STATION_WAGON("Station Wagon"),
        TRACTOR("Tractor"),
        BOAT_TRAILER("Boat Trailer"),
        CARAVAN("Caravan"),
        DOMESTIC_TRAILER("Domestic Trailer"),
        FLATDECK_TRAILER("Flatdeck Trailer"),
        OTHER_COMMERCIAL_TRAILER("Other Commercial Trailer"),
        UTILITY("Utility"),
        UNKNOWN("");

        @Getter
        private final String text;
    }
}

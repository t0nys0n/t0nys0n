package nz.govt.nzta.vehicle.specifications;

import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import nz.govt.nzta.vehicle.BodyStyleResponse;
import nz.govt.nzta.vehicle.Vehicle;

@Builder
@Value
public class SpecificationsResponse {
    @NonNull String plateNumber;
    int year;
    @NonNull String make;
    @NonNull String model;
    @NonNull BodyStyleResponse bodyType;
    @NonNull Colour colour;
    @NonNull EngineTypeResponse engineType;
    @NonNull String reportedStolen;
    @NonNull String maxRatedTowedMass;
    @NonNull String grossVehicleMass;
    @NonNull String wheelBase;
    @NonNull Vehicle.EquipmentClass equipmentClass;

    @Value
    public static class Colour {
        @NonNull ColourType primary;
    }

    @Value
    public static class EngineTypeResponse {

        @NonNull EngineType value;

        public String getText() {
            return value.getText();
        }

        @AllArgsConstructor
        public enum EngineType {
            NOTSET(""),
            PETROL("Petrol"),
            DIESEL("Diesel"),
            CNG("Cng"),
            LPG("Lpg"),
            ELECTRIC("Electric"),
            OTHER("Other"),
            PETROL_HYBRID("Petrol Hybrid"),
            DIESEL_HYBRID("Diesel Hybrid"),
            PETROL_ELECTRIC_HYBRID("Petrol Electric Hybrid"),
            DIESEL_ELECTRIC_HYBRID("Diesel Electric Hybrid"),
            PLUGIN_PETROL_HYBRID("Plugin Petrol Hybrid"),
            PLUGIN_DIESEL_HYBRID("Plugin Diesel Hybrid"),
            ELECTRIC_PETROL_EXTENDED("Electric Petrol Extended"),
            ELECTRIC_DIESEL_EXTENDED("Electric Diesel Extended"),
            ELECTRIC_FUEL_CELL_HYDROGEN("Electric Fuel Cell Hydrogen"),
            ELECTRIC_FUEL_CELL_OTHER("Electric Fuel Cell Other"),
            UNKNOWN("");

            @Getter
            private final String text;
        }
    }

    @AllArgsConstructor
    @Schema(implementation = String.class)
    public enum ColourType {
        NOTSET(""),
        BLACK("Black"),
        BLUE("Blue"),
        BROWN("Brown"),
        CREAM("Cream"),
        GOLD("Gold"),
        GREEN("Green"),
        GREY("Grey"),
        MULTI("Multi"),
        ORANGE("Orange"),
        PINK("Pink"),
        PURPLE("Purple"),
        RED("Red"),
        SILVER("Silver"),
        WHITE("White"),
        YELLOW("Yellow"),
        UNKNOWN("");

        @Getter @JsonValue private final String text;
    }

}

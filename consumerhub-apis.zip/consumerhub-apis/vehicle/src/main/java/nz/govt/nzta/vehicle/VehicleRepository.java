package nz.govt.nzta.vehicle;

public interface VehicleRepository {
    Vehicle getVehicle(String plateNumber);
}

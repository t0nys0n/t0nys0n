package nz.govt.nzta.vss.vehicle;

import lombok.extern.slf4j.Slf4j;
import nz.govt.nzta.clients.ApiClient4xxException;
import nz.govt.nzta.clients.api.ApiGet;
import org.generated.apis.vss.vehicle.ApiClient;
import org.generated.apis.vss.vehicle.client.VehiclesApi;
import org.generated.apis.vss.vehicle.model.NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Objects;

@Slf4j
public class ApiGetVehicle implements ApiGet<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience, String> {

    private final VehiclesApi api;
    private final Float apiVersion;
    private final String apiKey;

    public ApiGetVehicle(final WebClient oAuthClient, final ApiProperties properties) {
        api = createApiClient(oAuthClient, properties.getApiUri());
        apiVersion = properties.getApiVersion();
        apiKey = properties.getApiKey();
    }

    @Override
    public NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience get(String plateNumber) throws ApiClient4xxException {

        var response = api.apiVehiclesPlateIdGet(plateNumber, null, apiVersion, apiKey, getRequestIdentifier(), getCurrentTimestamp())
                .block();

        Objects.requireNonNull(response, "Empty vehicle data returned from downstream service");
        Objects.requireNonNull(response.getVehicle(), "Empty vehicle data returned from downstream service");

        if (response.getVehicle().getSpecialStatus() != null && Boolean.TRUE.equals(response.getVehicle().getSpecialStatus().getIsConfidential())) {
            log.info("if Special Status's Confidential is true, then show the vehicle as NOT FOUND.");
            throw new ApiClient4xxException(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.name() + "\"Not Found.\"");
        }

        return response;
    }

    private VehiclesApi createApiClient(final WebClient webClient, final String basePath) {
        var apiClient = new ApiClient(webClient);
        apiClient.setBasePath(basePath);
        return new VehiclesApi(apiClient);
    }
}

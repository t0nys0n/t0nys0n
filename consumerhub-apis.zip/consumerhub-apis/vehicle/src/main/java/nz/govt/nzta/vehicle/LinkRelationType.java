package nz.govt.nzta.vehicle;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@AllArgsConstructor
public enum LinkRelationType {
    SPECIFICATIONS("specifications");

    @Getter
    @Accessors(fluent = true)
    private String rel;
}

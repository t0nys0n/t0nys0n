package nz.govt.nzta.vehicle;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class VehicleService {
    private final VehicleRepository repository;

    public Vehicle getVehicle(String plateNumber) {
        plateNumber = removeAllSpaces(plateNumber);
        return repository.getVehicle(plateNumber);
    }

    private static String removeAllSpaces(String plateNumber) {
        return plateNumber.replaceAll("\\s+","");
    }
}

package nz.govt.nzta.vehicle;

import nz.govt.nzta.vehicle.compliance.ComplianceMessagesMapper;
import nz.govt.nzta.vehicle.specifications.SpecificationsGetController;
import org.mapstruct.*;
import org.springframework.hateoas.Link;

import java.time.Clock;

import static nz.govt.nzta.vehicle.LinkRelationType.SPECIFICATIONS;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Mapper(componentModel = "spring",
        uses = ComplianceMessagesMapper.class,
        injectionStrategy = InjectionStrategy.FIELD,
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT
)
public interface VehicleResponseMapper {
    @Mapping(target = "complianceMessages", source = ".")
    @Mapping(target = "bodyType.value", source = "bodyStyle", defaultValue = "NOTSET")
    VehicleResponse map(Vehicle vehicle, @Context Clock clock);

    @AfterMapping
    default void addLinks(@MappingTarget VehicleResponse vehicleResponse) {
        String plateNumber = vehicleResponse.getPlateNumber();
        var specifications = methodOn(SpecificationsGetController.class).get(plateNumber);
        Link link = linkTo(specifications).withRel(SPECIFICATIONS.rel());
        vehicleResponse.add(link);
    }

}

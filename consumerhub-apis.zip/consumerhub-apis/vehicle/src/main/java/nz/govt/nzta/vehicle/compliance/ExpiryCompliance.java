package nz.govt.nzta.vehicle.compliance;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public record ExpiryCompliance(Level level, LocalDate expiry, long daysToExpire) {

    public static ExpiryCompliance compute(LocalDate today, LocalDate expiry, int daysCountdown) {
        long daysToExpire = computeDaysBetween(today, expiry);
        Level level;
        if (expiry.isBefore(today)) {
            level = Level.EXPIRED;
        } else if (expiry.equals(today)) {
            level = Level.EXPIRES_TODAY;
        } else if (expiry.isAfter(today) && daysToExpire <= daysCountdown) {
            level = Level.EXPIRES_SOON;
        } else {
            level = Level.SUFFICIENT_EXPIRY;
        }
        return new ExpiryCompliance(level, expiry, daysToExpire);
    }

    public static long computeDaysBetween(LocalDate today, LocalDate expiry) {
        return ChronoUnit.DAYS.between(today, expiry);
    }

    public enum Level {
        EXPIRED, EXPIRES_TODAY, EXPIRES_SOON, SUFFICIENT_EXPIRY
    }
}

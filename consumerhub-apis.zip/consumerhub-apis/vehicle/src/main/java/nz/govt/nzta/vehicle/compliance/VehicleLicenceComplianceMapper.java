package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.time.LocalDate;
import java.util.Optional;

@Mapper(componentModel = "spring")
public abstract class VehicleLicenceComplianceMapper {

    private ExpiryComplianceMapper expiryComplianceMapper;

    private ExpiryComplianceMessageTemplates defaultMessageTemplates;

    private ExpiryComplianceMessageTemplates licenceExemptionMessageTemplates;

    @Autowired
    public void setComplianceMessageMapper(ExpiryComplianceMapper expiryComplianceMapper) {
        this.expiryComplianceMapper = expiryComplianceMapper;
    }

    @Autowired
    public void setMessageTemplates(@Qualifier("defaultExpiryComplianceMessageTemplates") ExpiryComplianceMessageTemplates defaultMessageTemplates, @Qualifier("licenceExemptionExpiryComplianceMessageTemplates") ExpiryComplianceMessageTemplates licenceExemptionMessageTemplates) {
        this.defaultMessageTemplates = defaultMessageTemplates;
        this.licenceExemptionMessageTemplates = licenceExemptionMessageTemplates;
    }

    Optional<ComplianceMessage> map(VehicleLicence vehicleLicence, LocalDate today) {
        var expiryCompliance = VehicleLicence.computeExpiryCompliance(vehicleLicence, today);
        return expiryCompliance.map(compliance -> mapComplianceMessage(vehicleLicence, compliance));
    }

    @ValueMapping(source = "NOTSET", target = MappingConstants.THROW_EXCEPTION)
    @ValueMapping(source = "UNKNOWN", target = MappingConstants.THROW_EXCEPTION)
    abstract ComplianceMessage.Code mapCode(VehicleLicence.Type type);

    private ComplianceMessage mapComplianceMessage(VehicleLicence vehicleLicence, ExpiryCompliance expiryCompliance) {
        var vehicleLicenceTypeCode = mapCode(vehicleLicence.getType());
        return switch(vehicleLicence.getType()) {
            case LICENCE_EXEMPTION -> expiryComplianceMapper.map(expiryCompliance, vehicleLicenceTypeCode, licenceExemptionMessageTemplates);
            default -> expiryComplianceMapper.map(expiryCompliance, vehicleLicenceTypeCode, defaultMessageTemplates);
        };
    }

}

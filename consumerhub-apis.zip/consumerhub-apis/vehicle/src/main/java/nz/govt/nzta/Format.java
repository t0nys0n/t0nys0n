package nz.govt.nzta;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Format {
    public static final String KILOMETRES = "End distance: %,d kms";
    public static final String KILOGRAMS = "%,dkg";
    public static final String METRES = "%sm";
}

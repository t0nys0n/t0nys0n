package nz.govt.nzta.vehicle.compliance;

import jakarta.annotation.Nullable;
import lombok.NonNull;
import lombok.Value;

import java.time.LocalDate;
import java.util.Optional;

import static java.util.Objects.isNull;

@Value
public class Inspection {

    static final int EXPIRY_COUNTDOWN = 42;

    @NonNull Inspection.Type type;

    /**
     * No expiry date for vehicles exempted from fitness inspection
     */
    @Nullable
    LocalDate expiry;

    public static Optional<ExpiryCompliance> computeExpiryCompliance(Inspection inspection, LocalDate today) {
        if (isNull(inspection) ||
                inspection.getType() == Type.NOTSET ||
                inspection.getType() == Type.UNKNOWN ||
                inspection.getExpiry() == null) {
            return Optional.empty();
        }
        var expiryCompliance = ExpiryCompliance.compute(today, inspection.getExpiry(), EXPIRY_COUNTDOWN);
        return Optional.of(expiryCompliance);
    }

    public enum Type {
        NOTSET, WOF, COF, UNKNOWN
    }
}

package nz.govt.nzta.vehicle.compliance;

import lombok.NonNull;
import lombok.Value;

import static java.util.Objects.nonNull;

@Value
public class RUCLicence {

    @NonNull Type type;

    int endDistance;

    static boolean isRoadChargeApplicable(RUCLicence rucLicence) {
        return nonNull(rucLicence);
    }

    public enum Type {
        NOTSET, B, D, H, UNKNOWN
    }
}
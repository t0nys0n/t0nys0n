package nz.govt.nzta.vss.vehicle;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
public class ApiProperties {

    private @NotBlank String apiUri;
    private @NotNull Float apiVersion;
    private @NotBlank String apiKey;
}

package nz.govt.nzta.vehicle;

import jakarta.validation.*;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Size(min = 1, max = 6)
@Pattern(regexp = "^(?! *$)[A-Za-z0-9 ]+$")
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = {})
@ReportAsSingleViolation
public @interface ValidPlateNumber {
    String message() default "{validation.messages.vehicle.plate.format}";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

package nz.govt.nzta.vss.vehicle;

import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.compliance.Inspection;
import nz.govt.nzta.vehicle.compliance.RUCLicence;
import nz.govt.nzta.vehicle.compliance.VehicleLicence;
import org.generated.apis.vss.vehicle.model.*;
import org.mapstruct.*;

import static java.util.Objects.nonNull;

@Mapper(componentModel = "spring",
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS
)
public interface ApiGetVehicleMapper {
    @Mapping(target = "plateNumber", source = "vehicleDetails.vehicle.plate")
    @Mapping(target = "year", source = "vehicleDetails.vehicle.appearance.yearFirstRegistered")
    @Mapping(target = "make", source = "vehicleDetails.vehicle.appearance.makeModel.make", defaultValue = "")
    @Mapping(target = "model", source = "vehicleDetails.vehicle.appearance.makeModel.model", defaultValue = "")
    @Mapping(target = "subModel", source = "vehicleDetails.vehicle.appearance.makeModel.subModel", defaultValue = "")
    @Mapping(target = "bodyStyle", source = "vehicleDetails.vehicle.profile.bodyType", defaultValue = "NOTSET")
    @Mapping(target = "colour.primary", source = "vehicleDetails.vehicle.appearance.colour.primary", defaultValue = "NOTSET")
    @Mapping(target = "engineType", source = "vehicleDetails.vehicle.profile.engineType.fuelType", defaultValue = "NOTSET")
    @Mapping(target = "reportedStolen", source = "vehicleDetails.vehicle.compliance.registration.vehicleOfInterestStolenFlag")
    @Mapping(target = "maxTowedBrakedMassKg", source = "vehicleDetails.vehicle.weightLimits.maxTowedBrakedMassKg", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "maxTowedUnBrakedMassKg", source = "vehicleDetails.vehicle.weightLimits.maxTowedUnBrakedMassKg", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "grossVehicleMassKg", source = "vehicleDetails.vehicle.weightLimits.gvmKg", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "wheelBaseMetres", source = "vehicleDetails.vehicle.profile.wheelBaseMtrs", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "equipmentClass.code", source = "vehicleDetails.vehicle.profile.propertyClass.classCode", defaultValue = "")
    @Mapping(target = "equipmentClass.description", source = "vehicleDetails.vehicle.profile.propertyClass.classDescription", defaultValue = "")
    @Mapping(target = "inspection", source = "vehicleDetails.vehicle.compliance.roadWorthiness.latestInspection", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "licence", source = "vehicleDetails.vehicle.compliance.vehicleLicence.mostRecentLicence", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    @Mapping(target = "rucLicence", source = "vehicleDetails.vehicle.compliance.roadUserCharges", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL)
    Vehicle map(NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience vehicleDetails);

    @ValueMapping(source = "VEHICLELICENCE", target = "VEHICLE_LICENCE")
    @ValueMapping(source = "LICENCEEXEMPTION", target = "LICENCE_EXEMPTION")
    VehicleLicence.Type map(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType licenceType);

    @ValueMapping(source = "ARTICULATEDTRUCK", target = "ARTICULATED_TRUCK")
    @ValueMapping(source = "CABCHASSIS", target = "CAB_CHASSIS")
    @ValueMapping(source = "FLATDECKTRUCK", target = "FLATDECK_TRUCK")
    @ValueMapping(source = "HEAVYBUS", target = "HEAVY_BUS")
    @ValueMapping(source = "HEAVYVAN", target = "HEAVY_VAN")
    @ValueMapping(source = "MINIBUS", target = "MINI_BUS")
    @ValueMapping(source = "LIGHTVAN", target = "LIGHT_VAN")
    @ValueMapping(source = "MOBILEMACHINE", target = "MOBILE_MACHINE")
    @ValueMapping(source = "AGRICULTURALMACHINEOTHER", target = "AGRICULTURAL_MACHINE_OTHER")
    @ValueMapping(source = "OTHERTRUCK", target = "OTHER_TRUCK")
    @ValueMapping(source = "SELFPROPELLEDCARAVAN", target = "SELF_PROPELLED_CARAVAN")
    @ValueMapping(source = "SPORTSCAR", target = "SPORTS_CAR")
    @ValueMapping(source = "STATIONWAGON", target = "STATION_WAGON")
    @ValueMapping(source = "BOATTRAILER", target = "BOAT_TRAILER")
    @ValueMapping(source = "DOMESTICTRAILER", target = "DOMESTIC_TRAILER")
    @ValueMapping(source = "FLATDECKTRAILER", target = "FLATDECK_TRAILER")
    @ValueMapping(source = "OTHERCOMMERCIALTRAILER", target = "OTHER_COMMERCIAL_TRAILER")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = "UNKNOWN")
    Vehicle.BodyType map(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType bodyStyle);

    @ValueMapping(source = "PETROL", target = "PETROL")
    @ValueMapping(source = "DIESEL", target = "DIESEL")
    @ValueMapping(source = "CNG", target = "CNG")
    @ValueMapping(source = "LPG", target = "LPG")
    @ValueMapping(source = "ELECTRIC", target = "ELECTRIC")
    @ValueMapping(source = "OTHER", target = "OTHER")
    @ValueMapping(source = "PETROLHYBRID", target = "PETROL_HYBRID")
    @ValueMapping(source = "DIESELHYBRID", target = "DIESEL_HYBRID")
    @ValueMapping(source = "PETROLELECTRICHYBRID", target = "PETROL_ELECTRIC_HYBRID")
    @ValueMapping(source = "DIESELELECTRICHYBRID", target = "DIESEL_ELECTRIC_HYBRID")
    @ValueMapping(source = "PLUGINPETROLHYBRID", target = "PLUGIN_PETROL_HYBRID")
    @ValueMapping(source = "PLUGINDIESELHYBRID", target = "PLUGIN_DIESEL_HYBRID")
    @ValueMapping(source = "ELECTRICPETROLEXTENDED", target = "ELECTRIC_PETROL_EXTENDED")
    @ValueMapping(source = "ELECTRICDIESELEXTENDED", target = "ELECTRIC_DIESEL_EXTENDED")
    @ValueMapping(source = "ELECTRICFUELCELLHYDROGEN", target = "ELECTRIC_FUEL_CELL_HYDROGEN")
    @ValueMapping(source = "ELECTRICFUELCELLOTHER", target = "ELECTRIC_FUEL_CELL_OTHER")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = "UNKNOWN")
    Vehicle.EngineType map(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType fuelType);

    @Mapping(target = "type", source = "inspectionType")
    @Mapping(target = "expiry", source = "expiryDate", conditionExpression = "java(isDate(latestInspection.getExpiryDate()))")
    Inspection map(NZTAVSSAPIsExperienceTransferObjectsModelComplianceLatestInspection latestInspection);

    @Mapping(target = "type", source = "licenceType")
    @Mapping(target = "expiry", source = "expiryDate", conditionExpression = "java(isDate(mostRecentLicence.getExpiryDate()))")
    VehicleLicence map(NZTAVSSAPIsExperienceTransferObjectsModelComplianceCurrentVehicleLicence mostRecentLicence);

    default RUCLicence map(NZTAVSSAPIsExperienceTransferObjectsModelComplianceRoadUserCharges roadUserCharges) {
        boolean isVehicleRUC = roadUserCharges.getRucVehicle();
        return isVehicleRUC ? map(roadUserCharges.getLatestRUCLicence()) : null;
    }

    @Mapping(target = "endDistance", source = "endDistance", conditionExpression = "java(isInteger(rucLicence.getEndDistance()))")
    @Mapping(target = "type", source = "licenceType", defaultValue = "NOTSET")
    RUCLicence map(NZTAVSSAPIsExperienceTransferObjectsModelComplianceRUCLicence rucLicence);

    default boolean isDate(String value) {
        return nonNull(value) && !value.isBlank();
    }

    default boolean isInteger(String value) {
        return nonNull(value) && value.matches("^\\d+$");
    }

}

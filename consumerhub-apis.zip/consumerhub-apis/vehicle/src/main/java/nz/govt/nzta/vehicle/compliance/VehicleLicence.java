package nz.govt.nzta.vehicle.compliance;

import jakarta.annotation.Nullable;
import lombok.NonNull;
import lombok.Value;

import java.time.LocalDate;
import java.util.Optional;

import static java.util.Objects.isNull;

@Value
public class VehicleLicence {

    static final int EXPIRY_COUNTDOWN = 42;

    @NonNull VehicleLicence.Type type;

    /**
     * No expiry date for vehicles exempted from renewal of vehicle licence
     */
    @Nullable
    LocalDate expiry;

    public static Optional<ExpiryCompliance> computeExpiryCompliance(VehicleLicence licence, LocalDate today) {
        if (isNull(licence) ||
                licence.getType() == Type.NOTSET ||
                licence.getType() == Type.UNKNOWN ||
                licence.getExpiry() == null) {
            return Optional.empty();
        }
        var expiryCompliance = ExpiryCompliance.compute(today, licence.getExpiry(), EXPIRY_COUNTDOWN);
        return Optional.of(expiryCompliance);
    }

    public enum Type {
        NOTSET, VEHICLE_LICENCE, RESTORATION, TRADE, LICENCE_EXEMPTION, UNKNOWN
    }
}

package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import org.mapstruct.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.time.LocalDate;
import java.util.Optional;

@Mapper(componentModel = "spring")
public abstract class InspectionComplianceMapper {

    private ExpiryComplianceMapper expiryComplianceMapper;

    private ExpiryComplianceMessageTemplates defaultMessageTemplates;

    @Autowired
    public void setComplianceMessageMapper(ExpiryComplianceMapper expiryComplianceMapper) {
        this.expiryComplianceMapper = expiryComplianceMapper;
    }

    @Autowired
    public void setMessageTemplates(@Qualifier("defaultExpiryComplianceMessageTemplates") ExpiryComplianceMessageTemplates defaultMessageTemplates) {
        this.defaultMessageTemplates = defaultMessageTemplates;
    }

    Optional<ComplianceMessage> map(Inspection inspection, LocalDate today) {
        var expiryCompliance = Inspection.computeExpiryCompliance(inspection, today);
        return expiryCompliance.map(compliance -> mapComplianceMessage(inspection, compliance));
    }

    @ValueMapping(source = "NOTSET", target = MappingConstants.THROW_EXCEPTION)
    @ValueMapping(source = "UNKNOWN", target = MappingConstants.THROW_EXCEPTION)
    abstract ComplianceMessage.Code mapCode(Inspection.Type type);

    private ComplianceMessage mapComplianceMessage(Inspection inspection, ExpiryCompliance expiryCompliance) {
        var inspectionTypeCode = mapCode(inspection.getType());
        return expiryComplianceMapper.map(expiryCompliance, inspectionTypeCode, defaultMessageTemplates);
    }

}

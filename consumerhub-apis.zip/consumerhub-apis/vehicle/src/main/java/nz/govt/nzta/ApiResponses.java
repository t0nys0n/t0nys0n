package nz.govt.nzta;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@ApiResponse(responseCode = "200")
@ApiResponse(responseCode = "400", description = "Invalid plate number format", content = @Content)
@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content)
@ApiResponse(responseCode = "404", description = "Plate number not found", content = @Content)
@ApiResponse(responseCode = "429", description = "Too many requests", content = @Content)
@ApiResponse(responseCode = "502", description = "Upstream service failure", content = @Content)
@ApiResponse(responseCode = "500", description = "Unexpected failure", content = @Content)
@Target({ElementType.METHOD, ElementType.TYPE, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiResponses {
}

package nz.govt.nzta.vehicle;

import jakarta.annotation.Nullable;
import lombok.*;
import nz.govt.nzta.vehicle.compliance.Inspection;
import nz.govt.nzta.vehicle.compliance.RUCLicence;
import nz.govt.nzta.vehicle.compliance.VehicleLicence;

@Value
@Builder
public class Vehicle {
    @NonNull String plateNumber;
    int year;
    @NonNull String make;
    @NonNull String model;
    @NonNull String subModel;
    @NonNull BodyType bodyStyle;
    @NonNull Colour colour;
    @NonNull EngineType engineType;
    boolean reportedStolen;
    @Nullable Integer maxTowedBrakedMassKg;
    @Nullable Integer maxTowedUnBrakedMassKg;
    @Nullable Integer grossVehicleMassKg;
    @Nullable Double wheelBaseMetres;
    @NonNull EquipmentClass equipmentClass;
    @Nullable Inspection inspection;
    @Nullable VehicleLicence licence;
    @Nullable RUCLicence rucLicence;

    @Value
    public static class Colour {
        @NonNull ColourType primary;
    }

    @Value
    public static class EquipmentClass {
        @NonNull String code;
        @NonNull String description;
    }


    public enum BodyType {
        NOTSET,
        ARTICULATED_TRUCK,
        CAB_CHASSIS,
        CONVERTIBLE,
        FLATDECK_TRUCK,
        HATCHBACK,
        HEAVY_BUS,
        HEAVY_VAN,
        MINI_BUS,
        LIGHT_VAN,
        MOTORCYCLE,
        MOBILE_MACHINE,
        AGRICULTURAL_MACHINE_OTHER,
        OTHER_TRUCK,
        SELF_PROPELLED_CARAVAN,
        SALOON,
        SPORTS_CAR,
        STATION_WAGON,
        TRACTOR,
        BOAT_TRAILER,
        CARAVAN,
        DOMESTIC_TRAILER,
        FLATDECK_TRAILER,
        OTHER_COMMERCIAL_TRAILER,
        UTILITY,
        UNKNOWN
    }

    public enum ColourType {
        NOTSET,
        BLACK,
        BLUE,
        BROWN,
        CREAM,
        GOLD,
        GREEN,
        GREY,
        MULTI,
        ORANGE,
        PINK,
        PURPLE,
        RED,
        SILVER,
        WHITE,
        YELLOW,
        UNKNOWN
    }

    public enum EngineType {
        NOTSET,
        PETROL,
        DIESEL,
        CNG,
        LPG,
        ELECTRIC,
        OTHER,
        PETROL_HYBRID,
        DIESEL_HYBRID,
        PETROL_ELECTRIC_HYBRID,
        DIESEL_ELECTRIC_HYBRID,
        PLUGIN_PETROL_HYBRID,
        PLUGIN_DIESEL_HYBRID,
        ELECTRIC_PETROL_EXTENDED,
        ELECTRIC_DIESEL_EXTENDED,
        ELECTRIC_FUEL_CELL_HYDROGEN,
        ELECTRIC_FUEL_CELL_OTHER,
        UNKNOWN
    }
}

package nz.govt.nzta.vehicle.compliance;

import org.springframework.stereotype.Component;

public interface ExpiryComplianceMessageTemplates {
    default String expired() {
        return "Expired: %s";
    }

    default String expiresToday() {
        return "Expires: %s (today)";
    }

    default String expiresSoon() {
        return "Expires: %s (in %d days)";
    }

    default String sufficientExpiry() {
        return "Expires: %s";
    }

    @Component("defaultExpiryComplianceMessageTemplates")
    class Default implements ExpiryComplianceMessageTemplates {
    }

    @Component("licenceExemptionExpiryComplianceMessageTemplates")
    class LicenceExemption implements ExpiryComplianceMessageTemplates {

        @Override
        public String expired() {
            return "On hold expired %s";
        }

        @Override
        public String expiresToday() {
            return "On hold until %s (ends today)";
        }

        @Override
        public String expiresSoon() {
            return "On hold until %s (%d days)";
        }

        @Override
        public String sufficientExpiry() {
            return "On hold until %s";
        }
    }
}

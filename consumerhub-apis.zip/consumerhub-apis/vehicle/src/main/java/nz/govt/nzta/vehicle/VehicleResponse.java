package nz.govt.nzta.vehicle;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

import java.util.List;

@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class VehicleResponse extends RepresentationModel<VehicleResponse> {
    @NonNull String plateNumber;
    final int year;
    @NonNull String make;
    @NonNull String model;

    /** @deprecated */
    @Deprecated(since = "0.8.0", forRemoval = true)
    @Schema(deprecated = true, description = "Use field bodyType instead of this")
    @NonNull BodyStyleResponse.BodyType bodyStyle;
    @NonNull BodyStyleResponse bodyType;
    List<ComplianceMessage> complianceMessages;

    public record ComplianceMessage(Level level, String text, Code code) {
        public enum Level {
            CRITICAL, WARN, INFO, OK
        }

        public enum Code {
            WOF, COF, VEHICLE_LICENCE, RESTORATION, TRADE, LICENCE_EXEMPTION, RUC_END_DISTANCE
        }
    }

}

package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Mapper(componentModel = "spring")
public abstract class ComplianceMessagesMapper {

    private InspectionComplianceMapper inspectionComplianceMapper;
    private VehicleLicenceComplianceMapper vehicleLicenceComplianceMapper;
    private RUCLicenceComplianceMapper rucLicenceComplianceMapper;

    @Autowired
    public void setInspectionComplianceMapper(InspectionComplianceMapper inspectionComplianceMapper) {
        this.inspectionComplianceMapper = inspectionComplianceMapper;
    }

    @Autowired
    public void setLicenceComplianceMapper(VehicleLicenceComplianceMapper vehicleLicenceComplianceMapper) {
        this.vehicleLicenceComplianceMapper = vehicleLicenceComplianceMapper;
    }

    @Autowired
    public void setRUCLicenceComplianceMapper(RUCLicenceComplianceMapper rucLicenceComplianceMapper) {
        this.rucLicenceComplianceMapper = rucLicenceComplianceMapper;
    }

    public List<ComplianceMessage> map(Vehicle vehicle, @Context Clock clock) {
        var today = LocalDate.now(clock);
        var licenceComplianceMessage = collectLicenceComplianceMessage(vehicle, today);
        var inspectionComplianceMessage = collectInspectionComplianceMessage(vehicle, today);
        var rucComplianceMessage =collectRucComplianceMessage(vehicle);
        var collectedComplianceMessages = List.of(licenceComplianceMessage, inspectionComplianceMessage, rucComplianceMessage);
        return filterEmptyMessages(collectedComplianceMessages);
    }

    private Optional<ComplianceMessage> collectInspectionComplianceMessage(Vehicle vehicle, LocalDate today) {
        return inspectionComplianceMapper.map(vehicle.getInspection(), today);
    }

    private Optional<ComplianceMessage> collectLicenceComplianceMessage(Vehicle vehicle, LocalDate today) {
        return vehicleLicenceComplianceMapper.map(vehicle.getLicence(), today);
    }

    private Optional<ComplianceMessage> collectRucComplianceMessage(Vehicle vehicle) {
        return rucLicenceComplianceMapper.map(vehicle.getRucLicence());
    }

    final List<ComplianceMessage> filterEmptyMessages(List<Optional<ComplianceMessage>> complianceMessages) {
        return complianceMessages.stream()
                                 .filter(Optional::isPresent)
                                 .map(Optional::get)
                                 .toList();
    }
}

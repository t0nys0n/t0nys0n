package nz.govt.nzta.vehicle.compliance;

import jakarta.annotation.Nonnull;
import nz.govt.nzta.DateFormats;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ValueMapping;

@Mapper(componentModel = "spring")
public interface ExpiryComplianceMapper {

    @Mapping(target = "code", source = "code")
    @Mapping(target = "level", source = "expiryCompliance.level")
    @Mapping(target = "text", source = "expiryCompliance")
    ComplianceMessage map(@Nonnull ExpiryCompliance expiryCompliance, ComplianceMessage.Code code, @Context ExpiryComplianceMessageTemplates messageTemplates);

    @ValueMapping(source = "EXPIRED", target = "CRITICAL")
    @ValueMapping(source = "EXPIRES_TODAY", target = "WARN")
    @ValueMapping(source = "EXPIRES_SOON", target = "WARN")
    @ValueMapping(source = "SUFFICIENT_EXPIRY", target = "OK")
    ComplianceMessage.Level mapLevel(ExpiryCompliance.Level value);

    default String mapText(ExpiryCompliance expiryCompliance, @Context ExpiryComplianceMessageTemplates messageTemplates) {
        ExpiryCompliance.Level level = expiryCompliance.level();
        String formattedExpiry = expiryCompliance.expiry()
                .format(DateFormats.MEDIUM_DATE_FORMATTER);
        long daysToExpire = expiryCompliance.daysToExpire();
        return switch (level) {
            case EXPIRED -> String.format(messageTemplates.expired(), formattedExpiry);
            case EXPIRES_TODAY -> String.format(messageTemplates.expiresToday(), formattedExpiry);
            case EXPIRES_SOON -> String.format(messageTemplates.expiresSoon(), formattedExpiry, daysToExpire);
            case SUFFICIENT_EXPIRY -> String.format(messageTemplates.sufficientExpiry(), formattedExpiry);
        };
    }
}

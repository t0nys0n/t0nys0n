package nz.govt.nzta.vehicle.specifications;

import jakarta.annotation.Nullable;
import nz.govt.nzta.Format;
import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.compliance.ComplianceMessagesMapper;
import org.mapstruct.*;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Mapper(componentModel = "spring",
        uses = ComplianceMessagesMapper.class,
        injectionStrategy = InjectionStrategy.FIELD,
        nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_DEFAULT)
public interface SpecificationsResponseMapper {
    @Mapping(target = "bodyType.value", source = "bodyStyle", defaultValue = "NOTSET")
    @Mapping(target = "colour.primary", defaultValue = "NOTSET")
    @Mapping(target = "engineType.value", source = "engineType",  defaultValue = "NOTSET")
    @Mapping(target = "reportedStolen", qualifiedByName = "mapReportedStolen")
    @Mapping(target = "maxRatedTowedMass", source = ".", qualifiedByName = "mapMaxRatedTowedMass")
    @Mapping(target = "grossVehicleMass", source = "grossVehicleMassKg", qualifiedByName = "mapGrossVehicleMass")
    @Mapping(target = "wheelBase", source = "wheelBaseMetres", qualifiedByName = "mapWheelBase")
    SpecificationsResponse map(Vehicle vehicle);

    @Named("mapReportedStolen")
    default String mapReportedStolen(boolean reportedStolen) {
        return reportedStolen ? "Yes" : "No";
    }

    @Named("mapMaxRatedTowedMass")
    default String mapMaxRatedTowedMass(Vehicle vehicle) {
        var braked = vehicle.getMaxTowedBrakedMassKg();
        var unbraked = vehicle.getMaxTowedUnBrakedMassKg();

        return Stream.of(braked, unbraked)
                     .filter(Objects::nonNull)
                     .max(Integer::compareTo)
                     .map(max -> format(Format.KILOGRAMS, max))
                     .orElse("");

    }

    @Named("mapGrossVehicleMass")
    default String mapGrossVehicleMass(@Nullable Integer grossVehicleMass) {
        return Optional.ofNullable(grossVehicleMass)
                       .map(gvm -> format(Format.KILOGRAMS, gvm))
                       .orElse("");
    }

    @Named("mapWheelBase")
    default String mapWheelBase(@Nullable Double wheelBase) {
        return Optional.ofNullable(wheelBase)
                .map(base -> format(Format.METRES, base))
                .orElse("");
    }

    default String format(String format, Number value) {
        return String.format(format, value);
    }

}

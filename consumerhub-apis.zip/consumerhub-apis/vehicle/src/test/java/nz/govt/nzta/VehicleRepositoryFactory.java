package nz.govt.nzta;


import java.io.IOException;

public interface VehicleRepositoryFactory<T> {
    T build() throws IOException;
}

package nz.govt.nzta.vehicle.specifications;

import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.BodyStyleResponse.BodyType;
import nz.govt.nzta.vehicle.specifications.SpecificationsResponse.ColourType;
import nz.govt.nzta.vehicle.specifications.SpecificationsResponse.EngineTypeResponse.EngineType;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryImp;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryFactoryImp;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mapstruct.factory.Mappers;

import java.io.IOException;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SpecificationsGetControllerTest {
    private SpecificationsGetController controller;

    @BeforeAll
    void buildGetController() throws IOException {
        VehicleRepositoryImp repository = new VehicleRepositoryFactoryImp().build();
        VehicleService service = new VehicleService(repository);
        SpecificationsResponseMapper mapper = Mappers.getMapper(SpecificationsResponseMapper.class);
        controller = new SpecificationsGetController(service, mapper);
    }

    @Test
    void getVehicleSpecifications() {
        var response = controller.get("EDZHAO");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());

        var specifications = response.getBody();
        assertEquals("EDZHAO", specifications.getPlateNumber());
        assertEquals(2015, specifications.getYear());
        assertEquals("LAND ROVER", specifications.getMake());
        assertEquals("RANGE ROVER", specifications.getModel());

        assertNotNull(specifications.getBodyType());
        assertEquals(BodyType.TRACTOR, specifications.getBodyType().getValue());
        assertEquals(BodyType.TRACTOR.getText(), specifications.getBodyType().getText());

        assertNotNull(specifications.getColour());
        assertEquals(ColourType.BLACK, specifications.getColour().getPrimary());

        assertNotNull(specifications.getEngineType());
        assertEquals(EngineType.DIESEL, specifications.getEngineType().getValue());
        assertEquals(EngineType.DIESEL.getText(), specifications.getEngineType().getText());

        assertEquals("No", specifications.getReportedStolen());
        assertEquals("2,500kg", specifications.getMaxRatedTowedMass());
        assertEquals("3,200kg", specifications.getGrossVehicleMass());
        assertEquals("2.76m", specifications.getWheelBase());

        var vehicleClass = specifications.getEquipmentClass();
        assertNotNull(vehicleClass);
        assertEquals("MA", vehicleClass.getCode());
        assertEquals("Motor car with 9 seats or less", vehicleClass.getDescription());
    }

    @Test
    void whenStolen() {
        var response = controller.get("IM2041");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());
        var specifications = response.getBody();
        assertEquals("IM2041", specifications.getPlateNumber());
        assertEquals("Yes", specifications.getReportedStolen());
    }

    @Test
    void whenMaxTowedUnBrakedMassIsGreaterThanMaxTowedBrakedMass() {
        var response = controller.get("IM2041");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());
        var specifications = response.getBody();
        assertEquals("IM2041", specifications.getPlateNumber());
        assertEquals("2,500kg", specifications.getMaxRatedTowedMass());
    }

    @Test
    void whenNulls() {
        var response = controller.get("XX0000");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());

        var specifications = response.getBody();
        assertEquals("XX0000", specifications.getPlateNumber());
        assertEquals(0, specifications.getYear());
        assertEquals("", specifications.getMake());
        assertEquals("", specifications.getModel());

        assertNotNull(specifications.getBodyType());
        assertEquals(BodyType.NOTSET, specifications.getBodyType().getValue());
        assertEquals(BodyType.NOTSET.getText(), specifications.getBodyType().getText());

        assertEquals(ColourType.NOTSET, specifications.getColour().getPrimary());

        assertNotNull(specifications.getEngineType());
        assertEquals(EngineType.NOTSET, specifications.getEngineType().getValue());
        assertEquals(EngineType.NOTSET.getText(), specifications.getEngineType().getText());

        assertEquals("", specifications.getMaxRatedTowedMass());
        assertEquals("", specifications.getGrossVehicleMass());
        assertEquals("", specifications.getWheelBase());
        var vehicleClass = specifications.getEquipmentClass();
        assertNotNull(vehicleClass);
        assertEquals("", vehicleClass.getCode());
        assertEquals("", vehicleClass.getDescription());
    }

}
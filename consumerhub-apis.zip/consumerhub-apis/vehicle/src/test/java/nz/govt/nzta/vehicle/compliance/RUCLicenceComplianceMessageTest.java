package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.VehicleGetController;
import nz.govt.nzta.vehicle.VehicleResponseMapper;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Level;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Code;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryImp;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryFactoryImp;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.time.Clock;
import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class RUCLicenceComplianceMessageTest {

    private final Clock clock = Clock.system(ClockConfigs.NST);
    private VehicleService service;
    private VehicleResponseMapper mapper;

    @BeforeAll
    void initializeService() throws IOException {
        VehicleRepositoryImp repository = new VehicleRepositoryFactoryImp().build();
        service = new VehicleService(repository);
    }

    @BeforeAll
    void initializeMapper(@Mock InspectionComplianceMapper inspectionComplianceMapper, @Mock VehicleLicenceComplianceMapper licenceComplianceMapper) {
        mapper = Mappers.getMapper(VehicleResponseMapper.class);
        var complianceMessagesMapper = Mappers.getMapper(ComplianceMessagesMapper.class);
        var rucComplianceMapper = Mappers.getMapper(RUCLicenceComplianceMapper.class);
        complianceMessagesMapper.setLicenceComplianceMapper(licenceComplianceMapper);
        complianceMessagesMapper.setInspectionComplianceMapper(inspectionComplianceMapper);
        complianceMessagesMapper.setRUCLicenceComplianceMapper(rucComplianceMapper);
        ReflectionTestUtils.setField(mapper, "complianceMessagesMapper", complianceMessagesMapper);
    }

    @Test
    void whenVehicleHasRoadCharges() {
        var expectedComplianceMessage = new ComplianceMessage(Level.INFO, "End distance: 100,000 kms", Code.RUC_END_DISTANCE);
        assertComplianceMessage("UN9347", expectedComplianceMessage);

        expectedComplianceMessage = new ComplianceMessage(Level.INFO, "End distance: 203,473 kms", Code.RUC_END_DISTANCE);
        assertComplianceMessage("EDZHAO", expectedComplianceMessage);
    }

    @Test
    void whenVehicleIsNotRUCVehicle() {
        assertNoComplianceMessage("UN9348", "Compliance messages must be zero when vehicle isn't a RUC vehicle");
    }

    @Test
    void whenRoadChargesEndDistanceHasNoValue() {
        var expectedComplianceMessage = new ComplianceMessage(Level.INFO, "End distance: 0 kms", Code.RUC_END_DISTANCE);
        assertComplianceMessage("UN9349", expectedComplianceMessage);
        assertComplianceMessage("UN9350", expectedComplianceMessage);
        assertComplianceMessage("IM2041", expectedComplianceMessage);
    }

    @Test
    void whenRoadChargesLicenceTypeHasNoValue() {
        assertComplianceMessage("100HG", new ComplianceMessage(Level.INFO, "End distance: 23,456 kms", Code.RUC_END_DISTANCE));
        assertComplianceMessage("100HF", new ComplianceMessage(Level.INFO, "End distance: 500,000 kms", Code.RUC_END_DISTANCE));
    }

    @Test
    void whenVehicleRoadChargesIsNull() {
        assertNoComplianceMessage("XX0000", "Compliance messages must be zero when road charges doesn't exist");
    }


    private void assertComplianceMessage(String plateNumber, ComplianceMessage expectedComplianceMessage) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());
        assertNotNull(response.getBody());
        var complianceMessages = response.getBody()
                                         .getComplianceMessages();
        var expectedComplianceMessages = List.of(expectedComplianceMessage);
        assertIterableEquals(expectedComplianceMessages, complianceMessages, String.format("Vehicle %s must have expected compliance message", plateNumber));
    }

    private void assertNoComplianceMessage(String plateNumber, String message) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                           .is2xxSuccessful());
        assertNotNull(response.getBody());
        var complianceMessages = response.getBody()
                                         .getComplianceMessages();
        assertNotNull(complianceMessages, message);
        assertEquals(0, complianceMessages.size(), message);
    }
}

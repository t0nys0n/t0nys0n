package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.VehicleGetController;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Code;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Level;
import nz.govt.nzta.vehicle.VehicleResponseMapper;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryImp;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryFactoryImp;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VehicleLicenceComplianceMessageTest {

    private final Clock clock = Clock.system(ClockConfigs.NST);
    private VehicleService service;
    private VehicleResponseMapper mapper;

    @BeforeAll
    void initializeService() throws IOException {
        VehicleRepositoryImp repository = new VehicleRepositoryFactoryImp().build();
        service = new VehicleService(repository);
    }

    @BeforeAll
    void initializeMapper(@Mock InspectionComplianceMapper inspectionComplianceMapper, @Mock RUCLicenceComplianceMapper rucComplianceMapper) {
        mapper = Mappers.getMapper(VehicleResponseMapper.class);
        var complianceMessagesMapper = Mappers.getMapper(ComplianceMessagesMapper.class);
        var licenceComplianceMapper = Mappers.getMapper(VehicleLicenceComplianceMapper.class);
        var expiryComplianceMapper = Mappers.getMapper(ExpiryComplianceMapper.class);
        var defaultExpiryMessageTemplates = new ExpiryComplianceMessageTemplates.Default();
        var licenceExpiryMessageTemplates = new ExpiryComplianceMessageTemplates.LicenceExemption();

        licenceComplianceMapper.setComplianceMessageMapper(expiryComplianceMapper);
        licenceComplianceMapper.setMessageTemplates(defaultExpiryMessageTemplates, licenceExpiryMessageTemplates);
        complianceMessagesMapper.setLicenceComplianceMapper(licenceComplianceMapper);
        complianceMessagesMapper.setInspectionComplianceMapper(inspectionComplianceMapper);
        complianceMessagesMapper.setRUCLicenceComplianceMapper(rucComplianceMapper);
        ReflectionTestUtils.setField(mapper, "complianceMessagesMapper", complianceMessagesMapper);
    }

    @Test
    void whenVehicleLicenceHasExpired() {
        var today = Instant.parse("2018-07-28T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiredComplianceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 27-07-2018", Code.VEHICLE_LICENCE);

        assertComplianceMessage("UN9347", clock, expiredComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExpiresToday() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "Expires: 27-07-2018 (today)", Code.VEHICLE_LICENCE);

        assertComplianceMessage("UN9347", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExpiresWithin42Days() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z")
                .minus(42, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "Expires: 27-07-2018 (in 42 days)", Code.VEHICLE_LICENCE);

        assertComplianceMessage("UN9347", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceHasSufficientExpiry() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z")
                .minus(43, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expireyComplianceMessage = new ComplianceMessage(Level.OK, "Expires: 27-07-2018", Code.VEHICLE_LICENCE);

        assertComplianceMessage("UN9347", clock, expireyComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExemptionHasExpired() {
        var today = Instant.parse("2019-01-17T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.CRITICAL, "On hold expired 27-07-2018", Code.LICENCE_EXEMPTION);

        assertComplianceMessage("UN9348", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExemptionExpiresToday() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "On hold until 27-07-2018 (ends today)", Code.LICENCE_EXEMPTION);

        assertComplianceMessage("UN9348", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExemptionExpiresWithin42Days() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z")
                .minus(42, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "On hold until 27-07-2018 (42 days)", Code.LICENCE_EXEMPTION);

        assertComplianceMessage("UN9348", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceExemptionHasSufficientExpiry() {
        var today = Instant.parse("2018-07-27T00:00:00.00Z")
                .minus(43, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.OK, "On hold until 27-07-2018", Code.LICENCE_EXEMPTION);

        assertComplianceMessage("UN9348", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceTypeIsRestoration() {
        var today = Instant.parse("2019-01-17T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 27-07-2018", Code.RESTORATION);

        assertComplianceMessage("UN9349", clock, expiryComplianceMessage);
    }

    @Test
    void whenVehicleLicenceTypeIsTrade() {
        var today = Instant.parse("2019-01-17T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 27-07-2018", Code.TRADE);

        assertComplianceMessage("UN9350", clock, expiryComplianceMessage);
    }

    @Test
    void whenLicenceTypeHasNoValue() {
        assertNoComplianceMessage("100HF", "Compliance messages must be zero when vehicle licence type is NotSet");
        assertNoComplianceMessage("100HG", "Compliance messages must be zero when vehicle licence type is Unknown");
    }

    @Test
    void whenVehicleLicenceIsNull() {
        assertNoComplianceMessage("XX0000", "Compliance messages must be zero when vehicle licence doesn't exist");
    }

    @Test
    void whenVehicleLicenceExpiryIsEmpty() {
        assertNoComplianceMessage("IM2041", "Compliance messages must be zero when vehicle licence expiry is empty");
    }

    private void assertComplianceMessage(String plateNumber, Clock clock, ComplianceMessage expectedComplianceMessage) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        assertNotNull(response.getBody());
        var complianceMessages = response.getBody()
                .getComplianceMessages();
        var expectedComplianceMessages = List.of(expectedComplianceMessage);
        assertIterableEquals(expectedComplianceMessages, complianceMessages, String.format("Vehicle %s must have expected compliance message", plateNumber));
    }

    private void assertNoComplianceMessage(String plateNumber, String message) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        assertNotNull(response.getBody());
        var complianceMessages = response.getBody()
                .getComplianceMessages();
        assertNotNull(complianceMessages, message);
        assertEquals(0, complianceMessages.size(), message);
    }
}

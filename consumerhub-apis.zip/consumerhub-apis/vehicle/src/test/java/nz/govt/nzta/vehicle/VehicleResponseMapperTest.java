package nz.govt.nzta.vehicle;

import nz.govt.nzta.vehicle.Vehicle.BodyType;
import nz.govt.nzta.vehicle.compliance.ComplianceMessagesMapper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VehicleResponseMapperTest {

    private final Clock clock = Clock.systemDefaultZone();
    private VehicleResponseMapper mapper;

    @BeforeAll
    private void initializeMapper(@Mock ComplianceMessagesMapper complianceMessagesMapper) {
        mapper = Mappers.getMapper(VehicleResponseMapper.class);
        ReflectionTestUtils.setField(mapper, "complianceMessagesMapper", complianceMessagesMapper);
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllBodyStyles(BodyType input, BodyStyleResponse.BodyType expectedType) {
        var vehicle = Vehicle.builder()
                             .plateNumber("")
                             .make("")
                             .model("")
                             .subModel("")
                             .bodyStyle(input)
                             .colour(new Vehicle.Colour(Vehicle.ColourType.NOTSET))
                             .engineType(Vehicle.EngineType.NOTSET)
                             .equipmentClass(new Vehicle.EquipmentClass("", ""))
                             .build();

        var result = mapper.map(vehicle, clock);

        assertEquals(expectedType, result.getBodyStyle());
        assertNotNull(result.getBodyType());
        assertEquals(expectedType, result.getBodyType().getValue());
        assertEquals(expectedType.getText(), result.getBodyType().getText());
    }

    private Stream<Arguments> mustMapAllBodyStyles() {
        return Stream.of(
                Arguments.of(BodyType.NOTSET, BodyStyleResponse.BodyType.NOTSET),
                Arguments.of(BodyType.ARTICULATED_TRUCK, BodyStyleResponse.BodyType.ARTICULATED_TRUCK),
                Arguments.of(BodyType.CAB_CHASSIS, BodyStyleResponse.BodyType.CAB_CHASSIS),
                Arguments.of(BodyType.CONVERTIBLE, BodyStyleResponse.BodyType.CONVERTIBLE),
                Arguments.of(BodyType.FLATDECK_TRUCK, BodyStyleResponse.BodyType.FLATDECK_TRUCK),
                Arguments.of(BodyType.HATCHBACK, BodyStyleResponse.BodyType.HATCHBACK),
                Arguments.of(BodyType.HEAVY_BUS, BodyStyleResponse.BodyType.HEAVY_BUS),
                Arguments.of(BodyType.HEAVY_VAN, BodyStyleResponse.BodyType.HEAVY_VAN),
                Arguments.of(BodyType.MINI_BUS, BodyStyleResponse.BodyType.MINI_BUS),
                Arguments.of(BodyType.LIGHT_VAN, BodyStyleResponse.BodyType.LIGHT_VAN),
                Arguments.of(BodyType.MOTORCYCLE, BodyStyleResponse.BodyType.MOTORCYCLE),
                Arguments.of(BodyType.MOBILE_MACHINE, BodyStyleResponse.BodyType.MOBILE_MACHINE),
                Arguments.of(BodyType.AGRICULTURAL_MACHINE_OTHER, BodyStyleResponse.BodyType.AGRICULTURAL_MACHINE_OTHER),
                Arguments.of(BodyType.OTHER_TRUCK, BodyStyleResponse.BodyType.OTHER_TRUCK),
                Arguments.of(BodyType.SELF_PROPELLED_CARAVAN, BodyStyleResponse.BodyType.SELF_PROPELLED_CARAVAN),
                Arguments.of(BodyType.SALOON, BodyStyleResponse.BodyType.SALOON),
                Arguments.of(BodyType.SPORTS_CAR, BodyStyleResponse.BodyType.SPORTS_CAR),
                Arguments.of(BodyType.STATION_WAGON, BodyStyleResponse.BodyType.STATION_WAGON),
                Arguments.of(BodyType.TRACTOR, BodyStyleResponse.BodyType.TRACTOR),
                Arguments.of(BodyType.BOAT_TRAILER, BodyStyleResponse.BodyType.BOAT_TRAILER),
                Arguments.of(BodyType.CARAVAN, BodyStyleResponse.BodyType.CARAVAN),
                Arguments.of(BodyType.DOMESTIC_TRAILER, BodyStyleResponse.BodyType.DOMESTIC_TRAILER),
                Arguments.of(BodyType.FLATDECK_TRAILER, BodyStyleResponse.BodyType.FLATDECK_TRAILER),
                Arguments.of(BodyType.OTHER_COMMERCIAL_TRAILER, BodyStyleResponse.BodyType.OTHER_COMMERCIAL_TRAILER),
                Arguments.of(BodyType.UTILITY, BodyStyleResponse.BodyType.UTILITY),
                Arguments.of(BodyType.UNKNOWN, BodyStyleResponse.BodyType.UNKNOWN)
        );
    }

}

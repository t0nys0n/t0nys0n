package nz.govt.nzta.vehicle;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Code;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Level;
import nz.govt.nzta.vehicle.compliance.*;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryImp;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryFactoryImp;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mapstruct.factory.Mappers;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.time.Clock;
import java.util.List;

import static nz.govt.nzta.vehicle.LinkRelationType.SPECIFICATIONS;
import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VehicleGetControllerTest {
    private VehicleGetController controller;
    private Clock clock = Clock.system(ClockConfigs.NST);

    @BeforeAll
    void buildGetController() throws IOException {
        VehicleRepositoryImp repository = new VehicleRepositoryFactoryImp().build();
        VehicleService service = new VehicleService(repository);
        VehicleResponseMapper mapper = initializeMapper();
        controller = new VehicleGetController(service, mapper, clock);
    }

    private VehicleResponseMapper initializeMapper() {
        VehicleResponseMapper mapper = Mappers.getMapper(VehicleResponseMapper.class);
        var complianceMessagesMapper = Mappers.getMapper(ComplianceMessagesMapper.class);
        var inspectionComplianceMapper = Mappers.getMapper(InspectionComplianceMapper.class);
        var licenceComplianceMapper = Mappers.getMapper(VehicleLicenceComplianceMapper.class);
        var rucComplianceMapper = Mappers.getMapper(RUCLicenceComplianceMapper.class);
        var expiryComplianceMapper = Mappers.getMapper(ExpiryComplianceMapper.class);
        var defaultExpiryMessageTemplates = new ExpiryComplianceMessageTemplates.Default();
        var licenceExpiryMessageTemplates = new ExpiryComplianceMessageTemplates.LicenceExemption();

        inspectionComplianceMapper.setComplianceMessageMapper(expiryComplianceMapper);
        inspectionComplianceMapper.setMessageTemplates(defaultExpiryMessageTemplates);
        licenceComplianceMapper.setComplianceMessageMapper(expiryComplianceMapper);
        licenceComplianceMapper.setMessageTemplates(defaultExpiryMessageTemplates, licenceExpiryMessageTemplates);
        complianceMessagesMapper.setInspectionComplianceMapper(inspectionComplianceMapper);
        complianceMessagesMapper.setLicenceComplianceMapper(licenceComplianceMapper);
        complianceMessagesMapper.setRUCLicenceComplianceMapper(rucComplianceMapper);
        ReflectionTestUtils.setField(mapper, "complianceMessagesMapper", complianceMessagesMapper);
        return mapper;
    }

    @Test
    void getVehicle() {
        var response = controller.get("UN9347");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());

        var vehicle = response.getBody();
        assertEquals("UN9347", vehicle.getPlateNumber());
        assertEquals("MITSUBISHI", vehicle.getMake());
        assertEquals("PAJERO", vehicle.getModel());
        assertEquals(1991, vehicle.getYear());
        assertEquals(BodyStyleResponse.BodyType.STATION_WAGON, vehicle.getBodyStyle());

        var bodyTypeExpected = BodyStyleResponse.BodyType.STATION_WAGON;
        var bodyTypeActual = vehicle.getBodyType();
        assertNotNull(bodyTypeActual);
        assertEquals(bodyTypeExpected, bodyTypeActual.getValue());
        assertEquals(bodyTypeExpected.getText(), bodyTypeActual.getText());

        var complianceMessages = vehicle.getComplianceMessages();
        assertNotNull(complianceMessages);
        assertEquals(3, complianceMessages.size());
        var inspectionMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 16-01-2019", Code.WOF);
        var licenceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 27-07-2018", Code.VEHICLE_LICENCE);
        var rucLicenceMessage = new ComplianceMessage(Level.INFO, "End distance: 100,000 kms", Code.RUC_END_DISTANCE);
        var expectedMessages = List.of(licenceMessage, inspectionMessage, rucLicenceMessage);
        assertIterableEquals(expectedMessages, complianceMessages);

        var links = vehicle.getLinks();
        assertNotNull(links);
        var specificationsLink = links.getLink(SPECIFICATIONS.rel());
        assertTrue(specificationsLink.isPresent());
    }

    @Test
    void whenComplianceExpiryDatesAreEmptyOrBlank() {
        var response = controller.get("IM2041");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        var vehicle = response.getBody();
        var complianceMessages = vehicle.getComplianceMessages();
        assertNotNull(complianceMessages);
        assertEquals(1, complianceMessages.size());
        assertEquals(Code.RUC_END_DISTANCE, complianceMessages.get(0).code());
    }

    @Test
    void whenNulls() {
        var response = controller.get("XX0000");

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        var vehicle = response.getBody();
        assertEquals("XX0000", vehicle.getPlateNumber());
        assertEquals(0, vehicle.getYear());
        assertEquals("", vehicle.getMake());
        assertEquals("", vehicle.getModel());
        assertEquals(BodyStyleResponse.BodyType.NOTSET, vehicle.getBodyStyle());

        var bodyTypeExpected = BodyStyleResponse.BodyType.NOTSET;
        var bodyTypeActual = vehicle.getBodyType();
        assertNotNull(bodyTypeActual);
        assertEquals(bodyTypeExpected, bodyTypeActual.getValue());
        assertEquals(bodyTypeExpected.getText(), bodyTypeActual.getText());

        assertNotNull(vehicle.getComplianceMessages());

        var links = vehicle.getLinks();
        assertNotNull(links);
        var specificationsLink = links.getLink(SPECIFICATIONS.rel());
        assertTrue(specificationsLink.isPresent());
    }
}

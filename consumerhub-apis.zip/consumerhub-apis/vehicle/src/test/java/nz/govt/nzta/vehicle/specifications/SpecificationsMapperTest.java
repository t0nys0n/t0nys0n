package nz.govt.nzta.vehicle.specifications;

import nz.govt.nzta.vehicle.BodyStyleResponse;
import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.specifications.SpecificationsResponse.EngineTypeResponse;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class SpecificationsMapperTest {

    private final SpecificationsResponseMapper mapper = Mappers.getMapper(SpecificationsResponseMapper.class);

    @ParameterizedTest
    @MethodSource
    void mustMapAllBodyStyles(Vehicle.BodyType input, BodyStyleResponse.BodyType expectedType, String expectedText) {
        var vehicle = Vehicle.builder()
                             .plateNumber("")
                             .make("")
                             .model("")
                             .subModel("")
                             .bodyStyle(input)
                             .colour(new Vehicle.Colour(Vehicle.ColourType.NOTSET))
                             .engineType(Vehicle.EngineType.NOTSET)
                             .equipmentClass(new Vehicle.EquipmentClass("", ""))
                             .build();

        var result = mapper.map(vehicle);

        assertNotNull(result.getBodyType());
        assertEquals(expectedType, result.getBodyType().getValue());
        assertEquals(expectedText, result.getBodyType().getText());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllColours(Vehicle.ColourType input, SpecificationsResponse.ColourType expectedColour) {
        var vehicle = Vehicle.builder()
                             .plateNumber("")
                             .make("")
                             .model("")
                             .subModel("")
                             .bodyStyle(Vehicle.BodyType.NOTSET)
                             .colour(new Vehicle.Colour(input))
                             .engineType(Vehicle.EngineType.NOTSET)
                             .equipmentClass(new Vehicle.EquipmentClass("", ""))
                             .build();

        var result = mapper.map(vehicle);

        assertEquals(expectedColour, result.getColour().getPrimary());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllEngineTypes(Vehicle.EngineType input, EngineTypeResponse.EngineType expectedType, String expectedText) {
        var vehicle = Vehicle.builder()
                             .plateNumber("")
                             .make("")
                             .model("")
                             .subModel("")
                             .bodyStyle(Vehicle.BodyType.NOTSET)
                             .colour(new Vehicle.Colour(Vehicle.ColourType.NOTSET))
                             .engineType(input)
                             .equipmentClass(new Vehicle.EquipmentClass("", ""))
                             .build();

        var result = mapper.map(vehicle);

        assertNotNull(result.getEngineType());
        assertEquals(expectedType, result.getEngineType().getValue());
        assertEquals(expectedText, result.getEngineType().getText());
    }

    private static Stream<Arguments> mustMapAllBodyStyles() {
        return Stream.of(
                Arguments.of(Vehicle.BodyType.NOTSET, BodyStyleResponse.BodyType.NOTSET, ""),
                Arguments.of(Vehicle.BodyType.ARTICULATED_TRUCK, BodyStyleResponse.BodyType.ARTICULATED_TRUCK, "Articulated Truck"),
                Arguments.of(Vehicle.BodyType.CAB_CHASSIS, BodyStyleResponse.BodyType.CAB_CHASSIS, "Cab Chassis"),
                Arguments.of(Vehicle.BodyType.CONVERTIBLE, BodyStyleResponse.BodyType.CONVERTIBLE, "Convertible"),
                Arguments.of(Vehicle.BodyType.FLATDECK_TRUCK, BodyStyleResponse.BodyType.FLATDECK_TRUCK, "Flatdeck Truck"),
                Arguments.of(Vehicle.BodyType.HATCHBACK, BodyStyleResponse.BodyType.HATCHBACK, "Hatchback"),
                Arguments.of(Vehicle.BodyType.HEAVY_BUS, BodyStyleResponse.BodyType.HEAVY_BUS, "Heavy Bus"),
                Arguments.of(Vehicle.BodyType.HEAVY_VAN, BodyStyleResponse.BodyType.HEAVY_VAN, "Heavy Van"),
                Arguments.of(Vehicle.BodyType.MINI_BUS, BodyStyleResponse.BodyType.MINI_BUS, "Mini Bus"),
                Arguments.of(Vehicle.BodyType.LIGHT_VAN, BodyStyleResponse.BodyType.LIGHT_VAN, "Light Van"),
                Arguments.of(Vehicle.BodyType.MOTORCYCLE, BodyStyleResponse.BodyType.MOTORCYCLE, "Motorcycle"),
                Arguments.of(Vehicle.BodyType.MOBILE_MACHINE, BodyStyleResponse.BodyType.MOBILE_MACHINE, "Mobile Machine"),
                Arguments.of(Vehicle.BodyType.AGRICULTURAL_MACHINE_OTHER, BodyStyleResponse.BodyType.AGRICULTURAL_MACHINE_OTHER, "Agricultural Machine Other"),
                Arguments.of(Vehicle.BodyType.OTHER_TRUCK, BodyStyleResponse.BodyType.OTHER_TRUCK, "Other Truck"),
                Arguments.of(Vehicle.BodyType.SELF_PROPELLED_CARAVAN, BodyStyleResponse.BodyType.SELF_PROPELLED_CARAVAN, "Self Propelled Caravan"),
                Arguments.of(Vehicle.BodyType.SALOON, BodyStyleResponse.BodyType.SALOON, "Saloon"),
                Arguments.of(Vehicle.BodyType.SPORTS_CAR, BodyStyleResponse.BodyType.SPORTS_CAR, "Sports Car"),
                Arguments.of(Vehicle.BodyType.STATION_WAGON, BodyStyleResponse.BodyType.STATION_WAGON, "Station Wagon"),
                Arguments.of(Vehicle.BodyType.TRACTOR, BodyStyleResponse.BodyType.TRACTOR, "Tractor"),
                Arguments.of(Vehicle.BodyType.BOAT_TRAILER, BodyStyleResponse.BodyType.BOAT_TRAILER, "Boat Trailer"),
                Arguments.of(Vehicle.BodyType.CARAVAN, BodyStyleResponse.BodyType.CARAVAN, "Caravan"),
                Arguments.of(Vehicle.BodyType.DOMESTIC_TRAILER, BodyStyleResponse.BodyType.DOMESTIC_TRAILER, "Domestic Trailer"),
                Arguments.of(Vehicle.BodyType.FLATDECK_TRAILER, BodyStyleResponse.BodyType.FLATDECK_TRAILER, "Flatdeck Trailer"),
                Arguments.of(Vehicle.BodyType.OTHER_COMMERCIAL_TRAILER, BodyStyleResponse.BodyType.OTHER_COMMERCIAL_TRAILER, "Other Commercial Trailer"),
                Arguments.of(Vehicle.BodyType.UTILITY, BodyStyleResponse.BodyType.UTILITY, "Utility"),
                Arguments.of(Vehicle.BodyType.UNKNOWN, BodyStyleResponse.BodyType.UNKNOWN, "")
        );
    }

    private static Stream<Arguments> mustMapAllColours() {
        return Stream.of(
                Arguments.of(Vehicle.ColourType.NOTSET, SpecificationsResponse.ColourType.NOTSET),
                Arguments.of(Vehicle.ColourType.BLACK, SpecificationsResponse.ColourType.BLACK),
                Arguments.of(Vehicle.ColourType.BLUE, SpecificationsResponse.ColourType.BLUE),
                Arguments.of(Vehicle.ColourType.BROWN, SpecificationsResponse.ColourType.BROWN),
                Arguments.of(Vehicle.ColourType.CREAM, SpecificationsResponse.ColourType.CREAM),
                Arguments.of(Vehicle.ColourType.GOLD, SpecificationsResponse.ColourType.GOLD),
                Arguments.of(Vehicle.ColourType.GREEN, SpecificationsResponse.ColourType.GREEN),
                Arguments.of(Vehicle.ColourType.GREY, SpecificationsResponse.ColourType.GREY),
                Arguments.of(Vehicle.ColourType.MULTI, SpecificationsResponse.ColourType.MULTI),
                Arguments.of(Vehicle.ColourType.ORANGE, SpecificationsResponse.ColourType.ORANGE),
                Arguments.of(Vehicle.ColourType.PINK, SpecificationsResponse.ColourType.PINK),
                Arguments.of(Vehicle.ColourType.PURPLE, SpecificationsResponse.ColourType.PURPLE),
                Arguments.of(Vehicle.ColourType.RED,  SpecificationsResponse.ColourType.RED),
                Arguments.of(Vehicle.ColourType.SILVER, SpecificationsResponse.ColourType.SILVER),
                Arguments.of(Vehicle.ColourType.WHITE, SpecificationsResponse.ColourType.WHITE),
                Arguments.of(Vehicle.ColourType.YELLOW, SpecificationsResponse.ColourType.YELLOW),
                Arguments.of(Vehicle.ColourType.UNKNOWN, SpecificationsResponse.ColourType.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllEngineTypes() {
        return Stream.of(
                Arguments.of(Vehicle.EngineType.NOTSET, EngineTypeResponse.EngineType.NOTSET, ""),
                Arguments.of(Vehicle.EngineType.PETROL, EngineTypeResponse.EngineType.PETROL, "Petrol"),
                Arguments.of(Vehicle.EngineType.DIESEL, EngineTypeResponse.EngineType.DIESEL, "Diesel"),
                Arguments.of(Vehicle.EngineType.CNG, EngineTypeResponse.EngineType.CNG, "Cng"),
                Arguments.of(Vehicle.EngineType.LPG, EngineTypeResponse.EngineType.LPG, "Lpg"),
                Arguments.of(Vehicle.EngineType.ELECTRIC, EngineTypeResponse.EngineType.ELECTRIC, "Electric"),
                Arguments.of(Vehicle.EngineType.OTHER, EngineTypeResponse.EngineType.OTHER, "Other"),
                Arguments.of(Vehicle.EngineType.PETROL_HYBRID, EngineTypeResponse.EngineType.PETROL_HYBRID, "Petrol Hybrid"),
                Arguments.of(Vehicle.EngineType.DIESEL_HYBRID, EngineTypeResponse.EngineType.DIESEL_HYBRID, "Diesel Hybrid"),
                Arguments.of(Vehicle.EngineType.PETROL_ELECTRIC_HYBRID, EngineTypeResponse.EngineType.PETROL_ELECTRIC_HYBRID, "Petrol Electric Hybrid"),
                Arguments.of(Vehicle.EngineType.DIESEL_ELECTRIC_HYBRID, EngineTypeResponse.EngineType.DIESEL_ELECTRIC_HYBRID, "Diesel Electric Hybrid"),
                Arguments.of(Vehicle.EngineType.PLUGIN_PETROL_HYBRID, EngineTypeResponse.EngineType.PLUGIN_PETROL_HYBRID, "Plugin Petrol Hybrid"),
                Arguments.of(Vehicle.EngineType.PLUGIN_DIESEL_HYBRID, EngineTypeResponse.EngineType.PLUGIN_DIESEL_HYBRID, "Plugin Diesel Hybrid"),
                Arguments.of(Vehicle.EngineType.ELECTRIC_PETROL_EXTENDED, EngineTypeResponse.EngineType.ELECTRIC_PETROL_EXTENDED, "Electric Petrol Extended"),
                Arguments.of(Vehicle.EngineType.ELECTRIC_DIESEL_EXTENDED, EngineTypeResponse.EngineType.ELECTRIC_DIESEL_EXTENDED, "Electric Diesel Extended"),
                Arguments.of(Vehicle.EngineType.ELECTRIC_FUEL_CELL_HYDROGEN, EngineTypeResponse.EngineType.ELECTRIC_FUEL_CELL_HYDROGEN, "Electric Fuel Cell Hydrogen"),
                Arguments.of(Vehicle.EngineType.ELECTRIC_FUEL_CELL_OTHER, EngineTypeResponse.EngineType.ELECTRIC_FUEL_CELL_OTHER, "Electric Fuel Cell Other"),
                Arguments.of(Vehicle.EngineType.UNKNOWN, EngineTypeResponse.EngineType.UNKNOWN, "")
        );
    }

}

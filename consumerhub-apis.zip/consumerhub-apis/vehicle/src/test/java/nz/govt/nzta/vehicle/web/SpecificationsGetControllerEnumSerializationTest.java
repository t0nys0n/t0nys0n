package nz.govt.nzta.vehicle.web;


import nz.govt.nzta.SignedJWTBuilder;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.Vehicle.BodyType;
import nz.govt.nzta.vehicle.Vehicle.Colour;
import nz.govt.nzta.vehicle.Vehicle.ColourType;
import nz.govt.nzta.vehicle.Vehicle.EngineType;
import nz.govt.nzta.vehicle.specifications.SpecificationsGetController;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SpecificationsGetController.class)
class SpecificationsGetControllerEnumSerializationTest {

    static final String ACCESS_TOKEN_WITH_ADDITIONAL_CLAIM = new SignedJWTBuilder().build();
    @MockBean
    VehicleService service;
    @Autowired
    private MockMvc mockMvc;

    @Test
    void mustReturnEnumTextInsteadOfName() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ACCESS_TOKEN_WITH_ADDITIONAL_CLAIM);

        Vehicle vehicle = Vehicle.builder().plateNumber("UN0000")
                .make("")
                .model("")
                .bodyStyle(BodyType.STATION_WAGON)
                .colour(new Colour(ColourType.GREY))
                .engineType(EngineType.ELECTRIC_PETROL_EXTENDED)
                .reportedStolen(false)
                .maxTowedBrakedMassKg(0)
                .grossVehicleMassKg(0)
                .wheelBaseMetres(0.0)
                .equipmentClass(new Vehicle.EquipmentClass("", ""))
                .subModel("")
                .build();

        Mockito.when(service.getVehicle("UN0000")).thenReturn(vehicle);


        var request = get(ResourcePath.VEHICLE_SPECIFICATIONS, "UN0000").headers(headers);
        String content = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();


        assertNotNull(content);
        assertTrue(content.indexOf("\"bodyType\":{\"value\":\"STATION_WAGON\",\"text\":\"Station Wagon\"}") >= 0);
        assertTrue(content.indexOf("\"colour\":{\"primary\":\"Grey\"}") >= 0);
        assertTrue(content.indexOf("\"engineType\":{\"value\":\"ELECTRIC_PETROL_EXTENDED\",\"text\":\"Electric Petrol Extended\"}") >= 0);
    }
}

package nz.govt.nzta.vss.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import nz.govt.nzta.clients.ApiClient4xxException;
import nz.govt.nzta.objectmapper.ObjectMapperFactory;
import org.generated.apis.vss.vehicle.client.VehiclesApi;
import org.generated.apis.vss.vehicle.model.NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.io.IOException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ApiGetVehicleTest {

    ObjectMapper objectMapper;

    @Mock
    VehiclesApi vehiclesApi;

    @Mock
    ApiProperties properties;

    @InjectMocks
    ApiGetVehicle apiGetVehicle;

    @BeforeAll
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(apiGetVehicle, "api", vehiclesApi);
        ReflectionTestUtils.setField(apiGetVehicle, "apiVersion", 0F);
        ReflectionTestUtils.setField(apiGetVehicle, "apiKey", null);

        objectMapper = ObjectMapperFactory.create(true);
    }

    @Test
    void shouldHaveVehicleIfConfidentialFalse() throws IOException {

        when(vehiclesApi.apiVehiclesPlateIdGet("UN9347", null, properties.getApiVersion(), properties.getApiKey(), apiGetVehicle.getRequestIdentifier(), apiGetVehicle.getCurrentTimestamp()))
                .thenReturn(buildApiResponse("/data/vss/UN9347.json"));

        var response = apiGetVehicle.get("UN9347");

        assertNotNull(response);
        assertNotNull(response.getVehicle());
        assertNotNull(response.getVehicle()
                              .getSpecialStatus());
        assertEquals(false, response.getVehicle()
                                    .getSpecialStatus()
                                    .getIsConfidential());
    }

    @Test
    void shouldNotHaveVehicleIfConfidentialTrue() throws IOException {

        when(vehiclesApi.apiVehiclesPlateIdGet("NFOUND", null, properties.getApiVersion(), properties.getApiKey(), apiGetVehicle.getRequestIdentifier(), apiGetVehicle.getCurrentTimestamp()))
                .thenReturn(buildApiResponse("/data/vss/NotFound.json"));

        assertThatExceptionOfType(ApiClient4xxException.class)
                .isThrownBy(() -> apiGetVehicle.get("NFOUND"))
                .withMessage("NOT_FOUND\"Not Found.\"");

    }

    private Mono<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience> buildApiResponse(String jsonFileName) throws IOException {
        var resource = new ClassPathResource(jsonFileName);
        return Mono.just(objectMapper.readValue(resource.getInputStream(), NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience.class));
    }

}
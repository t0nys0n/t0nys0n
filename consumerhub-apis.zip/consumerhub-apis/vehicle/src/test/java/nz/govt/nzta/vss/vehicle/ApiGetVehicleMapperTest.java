package nz.govt.nzta.vss.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import nz.govt.nzta.objectmapper.ObjectMapperFactory;
import nz.govt.nzta.vehicle.Vehicle;
import nz.govt.nzta.vehicle.compliance.Inspection;
import nz.govt.nzta.vehicle.compliance.VehicleLicence;
import org.generated.apis.vss.vehicle.model.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ApiGetVehicleMapperTest {

    private ApiGetVehicleMapper mapper;
    private ObjectMapper objectMapper;

    private static Stream<Arguments> mustMapAllInspectionTypes() {
        return Stream.of(
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsInspectionType.WOF, Inspection.Type.WOF),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsInspectionType.COF, Inspection.Type.COF),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsInspectionType.NOTSET, Inspection.Type.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsInspectionType.UNKNOWN, Inspection.Type.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllLicenceTypes() {
        return Stream.of(
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.VEHICLELICENCE, VehicleLicence.Type.VEHICLE_LICENCE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.TRADE, VehicleLicence.Type.TRADE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.RESTORATION, VehicleLicence.Type.RESTORATION),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.LICENCEEXEMPTION, VehicleLicence.Type.LICENCE_EXEMPTION),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.NOTSET, VehicleLicence.Type.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType.UNKNOWN, VehicleLicence.Type.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllBodyTypes() {
        return Stream.of(
                Arguments.of(null, Vehicle.BodyType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.NOTSET, Vehicle.BodyType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.ARTICULATEDTRUCK, Vehicle.BodyType.ARTICULATED_TRUCK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.CABCHASSIS, Vehicle.BodyType.CAB_CHASSIS),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.CONVERTIBLE, Vehicle.BodyType.CONVERTIBLE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.FLATDECKTRUCK, Vehicle.BodyType.FLATDECK_TRUCK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.HATCHBACK, Vehicle.BodyType.HATCHBACK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.HEAVYBUS, Vehicle.BodyType.HEAVY_BUS),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.HEAVYVAN, Vehicle.BodyType.HEAVY_VAN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.MINIBUS, Vehicle.BodyType.MINI_BUS),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.LIGHTVAN, Vehicle.BodyType.LIGHT_VAN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.MOTORCYCLE, Vehicle.BodyType.MOTORCYCLE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.MOBILEMACHINE, Vehicle.BodyType.MOBILE_MACHINE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.AGRICULTURALMACHINEOTHER, Vehicle.BodyType.AGRICULTURAL_MACHINE_OTHER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.OTHERTRUCK, Vehicle.BodyType.OTHER_TRUCK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.SELFPROPELLEDCARAVAN, Vehicle.BodyType.SELF_PROPELLED_CARAVAN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.SALOON, Vehicle.BodyType.SALOON),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.SPORTSCAR, Vehicle.BodyType.SPORTS_CAR),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.STATIONWAGON, Vehicle.BodyType.STATION_WAGON),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.TRACTOR, Vehicle.BodyType.TRACTOR),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.BOATTRAILER, Vehicle.BodyType.BOAT_TRAILER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.CARAVAN, Vehicle.BodyType.CARAVAN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.DOMESTICTRAILER, Vehicle.BodyType.DOMESTIC_TRAILER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.FLATDECKTRAILER, Vehicle.BodyType.FLATDECK_TRAILER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.OTHERCOMMERCIALTRAILER, Vehicle.BodyType.OTHER_COMMERCIAL_TRAILER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.UTILITY, Vehicle.BodyType.UTILITY),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType.UNKNOWN, Vehicle.BodyType.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllColours() {
        return Stream.of(
                Arguments.of(null, Vehicle.ColourType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.NOTSET, Vehicle.ColourType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.BLACK, Vehicle.ColourType.BLACK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.BLUE, Vehicle.ColourType.BLUE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.BROWN, Vehicle.ColourType.BROWN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.CREAM, Vehicle.ColourType.CREAM),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.GREEN, Vehicle.ColourType.GREEN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.GREY, Vehicle.ColourType.GREY),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.MULTI, Vehicle.ColourType.MULTI),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.ORANGE, Vehicle.ColourType.ORANGE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.PINK, Vehicle.ColourType.PINK),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.PURPLE, Vehicle.ColourType.PURPLE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.RED, Vehicle.ColourType.RED),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.SILVER, Vehicle.ColourType.SILVER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.WHITE, Vehicle.ColourType.WHITE),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.YELLOW, Vehicle.ColourType.YELLOW),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour.UNKNOWN, Vehicle.ColourType.UNKNOWN)
        );
    }

    private static Stream<Arguments> mustMapAllEngineTypes() {
        return Stream.of(
                Arguments.of(null, Vehicle.EngineType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.NOTSET, Vehicle.EngineType.NOTSET),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.PETROL, Vehicle.EngineType.PETROL),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.DIESEL, Vehicle.EngineType.DIESEL),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.CNG, Vehicle.EngineType.CNG),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.LPG, Vehicle.EngineType.LPG),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.ELECTRIC, Vehicle.EngineType.ELECTRIC),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.OTHER, Vehicle.EngineType.OTHER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.PETROLHYBRID, Vehicle.EngineType.PETROL_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.DIESELHYBRID, Vehicle.EngineType.DIESEL_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.PETROLELECTRICHYBRID, Vehicle.EngineType.PETROL_ELECTRIC_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.DIESELELECTRICHYBRID, Vehicle.EngineType.DIESEL_ELECTRIC_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.PLUGINPETROLHYBRID, Vehicle.EngineType.PLUGIN_PETROL_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.PLUGINDIESELHYBRID, Vehicle.EngineType.PLUGIN_DIESEL_HYBRID),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.ELECTRICPETROLEXTENDED, Vehicle.EngineType.ELECTRIC_PETROL_EXTENDED),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.ELECTRICDIESELEXTENDED, Vehicle.EngineType.ELECTRIC_DIESEL_EXTENDED),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.ELECTRICFUELCELLHYDROGEN, Vehicle.EngineType.ELECTRIC_FUEL_CELL_HYDROGEN),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.ELECTRICFUELCELLOTHER, Vehicle.EngineType.ELECTRIC_FUEL_CELL_OTHER),
                Arguments.of(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType.UNKNOWN, Vehicle.EngineType.UNKNOWN)
        );
    }

    @BeforeAll
    private void initialize() {
        mapper = Mappers.getMapper(ApiGetVehicleMapper.class);
        objectMapper = ObjectMapperFactory.create(true);
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllInspectionTypes(NZTAVSSAPIsExperienceTransferObjectsModelEnumsInspectionType input, Inspection.Type expected) {
        var sourceInspection = new NZTAVSSAPIsExperienceTransferObjectsModelComplianceLatestInspection();
        sourceInspection.setInspectionType(input);

        var result = mapper.map(sourceInspection);

        assertEquals(expected, result.getType());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllLicenceTypes(NZTAVSSAPIsExperienceTransferObjectsModelEnumsLicenceType input, VehicleLicence.Type expected) {
        var sourceVehicleLicence = new NZTAVSSAPIsExperienceTransferObjectsModelComplianceCurrentVehicleLicence();
        sourceVehicleLicence.setLicenceType(input);

        var result = mapper.map(sourceVehicleLicence);

        assertEquals(expected, result.getType());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllBodyTypes(NZTAVSSAPIsExperienceTransferObjectsModelEnumsBodyType input, Vehicle.BodyType expected) throws IOException {
        var response = buildApiResponse("/data/vss/UN9347.json");
        response.getVehicle()
                .getProfile()
                .setBodyType(input);

        var result = mapper.map(response);

        assertEquals(expected, result.getBodyStyle());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllColours(NZTAVSSAPIsExperienceTransferObjectsModelEnumsColour input, Vehicle.ColourType expected) throws IOException {
        var response = buildApiResponse("/data/vss/UN9347.json");
        response.getVehicle()
                .getAppearance()
                .getColour()
                .setPrimary(input);

        var result = mapper.map(response);

        assertEquals(expected, result.getColour().getPrimary());
    }

    @ParameterizedTest
    @MethodSource
    void mustMapAllEngineTypes(NZTAVSSAPIsExperienceTransferObjectsModelEnumsFuelType input, Vehicle.EngineType expected) throws IOException {
        var response = buildApiResponse("/data/vss/UN9347.json");
        response.getVehicle()
                .getProfile()
                .getEngineType()
                .setFuelType(input);

        var result = mapper.map(response);

        assertEquals(expected, result.getEngineType());
    }

    @Test
    void mustMapMaximumTowedBrakedMass() throws IOException {
        var response = buildApiResponse("/data/vss/UN9347.json");
        response.getVehicle()
                .getWeightLimits()
                .setMaxTowedBrakedMassKg(10000);

        var result = mapper.map(response);

        assertEquals(10000, result.getMaxTowedBrakedMassKg());
    }

    @Test
    void mustMapMaximumTowedUnBrakedMass() throws IOException {
        var response = buildApiResponse("/data/vss/UN9347.json");
        response.getVehicle()
                .getWeightLimits()
                .setMaxTowedUnBrakedMassKg(5000);

        var result = mapper.map(response);

        assertEquals(5000, result.getMaxTowedUnBrakedMassKg());

    }

    private NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience buildApiResponse(String jsonFileName) throws IOException {
        var resource = new ClassPathResource(jsonFileName);
        return objectMapper.readValue(resource.getInputStream(), NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience.class);
    }

}

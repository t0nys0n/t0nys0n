package nz.govt.nzta.vehicle;

import jakarta.validation.ConstraintViolationException;
import nz.govt.nzta.ValidationMessagesConfigs;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.server.configuration.OAuthResourceServerConfigs;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Clock;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;


@WebMvcTest
@ContextConfiguration(classes = VehicleGetController.class)
@Import({BuildProperties.class, OAuthResourceServerConfigs.class, ValidationMessagesConfigs.class})
@MockBean({VehicleService.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VehicleGetController400Test {

    @MockBean
    VehicleService vehicleService;

    @MockBean
    VehicleResponseMapper vehicleResponseMapper;

    @MockBean
    Clock clock;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void invalidPlateNumbersMustReturn400WithMessage() {

        assertThatThrownBy(
                () -> mockMvc.perform(get(ResourcePath.VEHICLE, "XX777777")
                        .with(jwt().jwt(jwt -> jwt.claim("accountNumber", "0"))
                                   .authorities(List.of(new SimpleGrantedAuthority("ROLE_VerifiedUser"))))))

                .hasCauseInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("get.plateNumber: length must be from 1 to 6 characters and an alphanumeric value is required");
    }
}

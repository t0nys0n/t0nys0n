package nz.govt.nzta.vss.vehicle;

import com.fasterxml.jackson.databind.ObjectMapper;
import nz.govt.nzta.VehicleRepositoryFactory;
import nz.govt.nzta.objectmapper.ObjectMapperFactory;
import org.generated.apis.vss.vehicle.model.NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience;
import org.mapstruct.factory.Mappers;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class VehicleRepositoryFactoryImp implements VehicleRepositoryFactory<VehicleRepositoryImp> {

    ObjectMapper mapper = ObjectMapperFactory.create(true);

    @Override
    public VehicleRepositoryImp build() throws IOException {
        ApiGetVehicle api = mock(ApiGetVehicle.class);
        ApiGetVehicleMapper mapper = Mappers.getMapper(ApiGetVehicleMapper.class);
        var vehicles = loadVehicles();
        mockThem(api, vehicles);
        return new VehicleRepositoryImp(api, mapper);
    }

    private List<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience> loadVehicles() throws IOException {
        List<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience> vehicles = new LinkedList<>();
        Resource[] resources = new PathMatchingResourcePatternResolver().getResources("/data/vss/**");
        for (Resource resource : resources) {
            var vehicle = mapper.readValue(resource.getInputStream(), NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience.class);
            vehicles.add(vehicle);
        }
        return vehicles;
    }

    private void mockThem(ApiGetVehicle api, List<NZTAVSSAPIsExperienceTransferObjectsGetVehicleResponseExperience> vehicles) {
        vehicles.stream()
                .forEach(v -> {
                    var platNumber = v.getVehicle()
                            .getPlate();
                    when(api.get(platNumber)).thenReturn(v);
                });
    }
}

package nz.govt.nzta.vehicle.web;


import nz.govt.nzta.SignedJWTBuilder;
import nz.govt.nzta.server.api.ResourcePath;
import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.VehicleGetController;
import nz.govt.nzta.vehicle.VehicleResponseMapper;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockBeans;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = VehicleGetController.class)
@MockBeans({
        @MockBean(VehicleService.class),
        @MockBean(VehicleResponseMapper.class)
})
class VehicleGetControllerValidationTest {

    static final String ACCESS_TOKEN_WITH_ADDITIONAL_CLAIM = new SignedJWTBuilder().build();

    @Autowired
    private MockMvc mockMvc;

    @ParameterizedTest(name = "{index} - {0} is not a valid plate number")
    @ValueSource(strings = {"Māori", "XX00000", "     ", "   XX000", "`X", "XX~", "  X!0", "Xx@0", "Xo$", "XX^0", "00&XX", "xX*xX", "0Xx(", ")00x", "x-x", "X_00", "Xx+", "X=0", "X|X", "X{X", "}X", "X[X", "0]0", "X:0", "Xx'", "000\"", "X<Y", "Y>0", "00,XX", "X.X"})
    void inValidPlateNumbers(String plateNumber) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ACCESS_TOKEN_WITH_ADDITIONAL_CLAIM);
        var request = get(ResourcePath.VEHICLE, plateNumber).headers(headers);
        mockMvc.perform(request)
                .andExpect(status().isBadRequest())
                .andExpect(result -> assertEquals("get.plateNumber: length must be from 1 to 6 characters and an alphanumeric value is required", result.getResolvedException().getMessage()));
    }

    @ParameterizedTest(name = "{index} - {0} is a valid plate number")
    @ValueSource(strings = {"000000", "XXXXXX", "aaaaa", "A", "z", "1", "X   00", "   XXX", "00   "})
    void validPlateNumbers(String plateNumber) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ACCESS_TOKEN_WITH_ADDITIONAL_CLAIM);
        var request = get(ResourcePath.VEHICLE, plateNumber).headers(headers);
        mockMvc.perform(request)
                .andExpect(status().isOk());
    }
}

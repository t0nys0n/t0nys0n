package nz.govt.nzta.vehicle.compliance;

import nz.govt.nzta.ClockConfigs;
import nz.govt.nzta.vehicle.VehicleService;
import nz.govt.nzta.vehicle.VehicleGetController;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Code;
import nz.govt.nzta.vehicle.VehicleResponse.ComplianceMessage.Level;
import nz.govt.nzta.vehicle.VehicleResponseMapper;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryImp;
import nz.govt.nzta.vss.vehicle.VehicleRepositoryFactoryImp;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class InspectionComplianceMessageTest {

    VehicleService service;
    VehicleResponseMapper mapper;
    Clock clock = Clock.system(ClockConfigs.NST);

    @BeforeAll
    void initializeService() throws IOException {
        VehicleRepositoryImp repository = new VehicleRepositoryFactoryImp().build();
        service = new VehicleService(repository);
    }

    @BeforeAll
    void initializeMapper(@Mock VehicleLicenceComplianceMapper vehicleLicenceComplianceMapper, @Mock RUCLicenceComplianceMapper rucComplianceMapper) {
        mapper = Mappers.getMapper(VehicleResponseMapper.class);
        var complianceMessagesMapper = Mappers.getMapper(ComplianceMessagesMapper.class);
        var inspectionComplianceMapper = Mappers.getMapper(InspectionComplianceMapper.class);
        var expiryComplianceMapper = Mappers.getMapper(ExpiryComplianceMapper.class);
        var defaultExpiryMessageTemplates = new ExpiryComplianceMessageTemplates.Default();

        inspectionComplianceMapper.setComplianceMessageMapper(expiryComplianceMapper);
        inspectionComplianceMapper.setMessageTemplates(defaultExpiryMessageTemplates);
        complianceMessagesMapper.setInspectionComplianceMapper(inspectionComplianceMapper);
        complianceMessagesMapper.setLicenceComplianceMapper(vehicleLicenceComplianceMapper);
        complianceMessagesMapper.setRUCLicenceComplianceMapper(rucComplianceMapper);
        ReflectionTestUtils.setField(mapper, "complianceMessagesMapper", complianceMessagesMapper);
    }


    @Test
    void whenInspectionHasExpired() {
        var today = Instant.parse("2019-01-17T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiredComplianceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 16-01-2019", Code.WOF);

        assertComplianceMessage("UN9347", clock, expiredComplianceMessage);
    }

    @Test
    void whenInspectionExpiresToday() {
        var today = Instant.parse("2019-01-16T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "Expires: 16-01-2019 (today)", Code.WOF);

        assertComplianceMessage("UN9347", clock, expiryComplianceMessage);
    }

    @Test
    void whenInspectionExpiresWithin42Days() {
        var today = Instant.parse("2019-01-16T00:00:00.00Z")
                .minus(42, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.WARN, "Expires: 16-01-2019 (in 42 days)", Code.WOF);

        assertComplianceMessage("UN9347", clock, expiryComplianceMessage);
    }

    @Test
    void whenInspectionHasSufficientExpiry() {
        var today = Instant.parse("2019-01-16T00:00:00.00Z")
                .minus(43, ChronoUnit.DAYS);
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiryComplianceMessage = new ComplianceMessage(Level.OK, "Expires: 16-01-2019", Code.WOF);

        assertComplianceMessage("UN9347", clock, expiryComplianceMessage);
    }

    @Test
    void whenInspectionTypeIsCoF() {
        var today = Instant.parse("2019-01-17T00:00:00.00Z");
        var clock = Clock.fixed(today, ClockConfigs.NST);
        var expiredComplianceMessage = new ComplianceMessage(Level.CRITICAL, "Expired: 16-01-2019", Code.COF);

        assertComplianceMessage("UN9348", clock, expiredComplianceMessage);
    }

    @Test
    void whenInspectionTypeHasNoValue() {
        assertNoComplianceMessage("100HF", "Compliance messages must be zero when inspection type is NotSet");
        assertNoComplianceMessage("100HG", "Compliance messages must be zero when inspection type is Unknown");
    }

    @Test
    void whenInspectionIsNull() {
        assertNoComplianceMessage("XX0000", "Compliance messages must be zero when inspection doesn't exist");
    }

    @Test
    void whenInspectionExpiryHasNoValue() {
        assertNoComplianceMessage("IM2041", "Compliance messages must be zero when inspection expiry is empty");
    }

    private void assertComplianceMessage(String plateNumber, Clock clock, ComplianceMessage expectedComplianceMessage) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        assertNotNull(response.getBody());
        var complianceMessages = response.getBody()
                .getComplianceMessages();
        var expectedComplianceMessages = List.of(expectedComplianceMessage);
        assertIterableEquals(expectedComplianceMessages, complianceMessages, String.format("Vehicle %s must have expected compliance message", plateNumber));
    }

    private void assertNoComplianceMessage(String plateNumber, String message) {
        var controller = new VehicleGetController(service, mapper, clock);
        var response = controller.get(plateNumber);

        assertNotNull(response);
        assertTrue(response.getStatusCode()
                .is2xxSuccessful());
        assertNotNull(response.getBody());
        var vehicle = response.getBody();
        var complianceMessages = vehicle.getComplianceMessages();
        assertEquals(plateNumber, vehicle.getPlateNumber());
        assertNotNull(complianceMessages, message);
        assertEquals(0, complianceMessages.size(), message);
    }
}
